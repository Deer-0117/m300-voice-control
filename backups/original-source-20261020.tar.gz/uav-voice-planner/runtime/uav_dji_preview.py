"""Local-only PSDK call renderer. No SDK binding, transport, or execution switch."""
from __future__ import annotations

import math
from uav_capabilities import validate_plan, canonical_balloon_color

MODE = {
    'horizontalControlMode': 'DJI_FLIGHT_CONTROLLER_HORIZONTAL_VELOCITY_CONTROL_MODE',
    'verticalControlMode': 'DJI_FLIGHT_CONTROLLER_VERTICAL_VELOCITY_CONTROL_MODE',
    'yawControlMode': 'DJI_FLIGHT_CONTROLLER_YAW_ANGLE_RATE_CONTROL_MODE',
    'horizontalCoordinate': 'DJI_FLIGHT_CONTROLLER_HORIZONTAL_BODY_COORDINATE',
    'stableControlMode': 'DJI_FLIGHT_CONTROLLER_STABLE_CONTROL_MODE_ENABLE',
}
# Illustrative controller OUTPUT samples, not computed from language or real perception.
SAMPLES = (
    ('search', (0.0, 0.0, 0.0, 5.0)),
    ('align', (0.0, 0.05, 0.0, 0.0)),
    ('approach', (0.2, 0.0, 0.0, 0.0)),
    ('hold', (0.0, 0.0, 0.0, 0.0)),
)


def joystick_arguments(values):
    if len(values) != 4:
        raise ValueError('expected x/y/z/yaw')
    limits = (30, 30, 5, 150)  # SDK bounds, not recommended flight settings
    result = {}
    for key, value, limit in zip(('x', 'y', 'z', 'yaw'), values, limits):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError('command values must be numeric')
        if not math.isfinite(value) or abs(value) > limit:
            raise ValueError('non-finite or out-of-range command')
        result[key] = float(value)
    return result


def render_preview(raw_plan):
    plan = validate_plan(raw_plan)
    # Conservative preview restriction: never carry the observed noisy 'any' guess forward.
    for action in plan['actions']:
        if action['capability'] == 'strike_balloon' and action['parameters']['color'] == 'any':
            raise ValueError('preview requires an explicit color; clarify any/unknown target first')
    events = []

    def record(api, arguments, **metadata):
        events.append(dict(api=api, arguments=arguments, transport='local_record_only',
                           sdk_called=False, sdk_return_code=None, **metadata))

    record('DjiFlightController_ObtainJoystickCtrlAuthority', {},
           precondition='hypothetical: SDK initialized, RC P-mode, human confirmation and authority granted')
    record('DjiFlightController_SetJoystickMode', dict(MODE))
    for index, action in enumerate(plan['actions'], 1):
        if action['capability'] == 'stop':
            record('DjiFlightController_ExecuteEmergencyBrakeAction', {}, action_index=index)
            continue
        color = canonical_balloon_color(action['parameters']['color'])
        for stage, sample in SAMPLES:
            record('DjiFlightController_ExecuteJoystickAction', joystick_arguments(sample),
                   action_index=index, target_color_group=color, stage=stage,
                   value_source='synthetic_controller_output_fixture',
                   sample_only=True)
    record('DjiFlightController_ReleaseJoystickCtrlAuthority', {})
    return {
        'kind': 'dji_psdk_hypothetical_call_preview', 'execution_allowed': False,
        'human_confirmation': 'pending', 'aircraft_access': False,
        'wire_protocol': False, 'plan': plan,
        'units': {'x': 'm/s forward', 'y': 'm/s right', 'z': 'm/s up', 'yaw': 'deg/s'},
        'limitations': [
            'Calls recorded locally only; not a DJI network/serial packet.',
            'Samples are not a flight trajectory or real controller replay.',
            'No duration, completion, perception, telemetry, or authority is simulated as verified.',
            'Real controller must update commands continuously from live feedback and check SDK results.',
        ],
        'events': events,
    }


def render_c(preview):
    # Keep every call commented out so the artifact cannot execute SDK operations.
    lines = ['/* PSDK FORMAT PREVIEW ONLY. Synthetic values. Pending human confirmation.',
             ' * SDK initialization / telemetry / feedback / return checks omitted.',
             ' * This is not a runnable flight program. */']
    for event in preview['events']:
        api, args = event['api'], event['arguments']
        if api.endswith('SetJoystickMode'):
            lines.append('// T_DjiFlightControllerJoystickMode mode = {')
            lines.extend(f'//     .{key} = {value},' for key, value in args.items())
            lines.extend(['// };', f'// {api}(mode);'])
        elif api.endswith('ExecuteJoystickAction'):
            lines.append(f"// action {event['action_index']}: {event['target_color_group']} / {event['stage']} (fixture)")
            fields = ', '.join(f'.{key} = {value:.3f}f' for key, value in args.items())
            lines.append(f'// {api}((T_DjiFlightControllerJoystickCommand){{{fields}}});')
        else:
            lines.append(f'// {api}();')
    return '\n'.join(lines) + '\n'
