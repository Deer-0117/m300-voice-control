"""Check model-authored statements against its own bbox; never reads detections."""
import math

def check_self_consistency(decision):
    if decision.get('mode')!='approach':return None
    box=decision.get('bbox');v=decision.get('velocity');a=decision.get('visual_assessment')
    if not isinstance(box,list) or len(box)!=4 or any(type(n) not in (int,float) or not math.isfinite(n) for n in box):return 'Your approach needs a valid bbox inferred from the current image.'
    if not isinstance(a,dict):return 'Include your own visual_assessment before choosing motion.'
    center=(box[0]+box[2])/2;claimed=a.get('center_x_from_own_bbox')
    if type(claimed) not in (int,float) or not math.isfinite(claimed) or abs(claimed-center)>.015:
        return 'Your reported center does not match YOUR OWN bbox. Recompute (left+right)/2 and reanalyze.'
    error=center-.5
    if abs(error)>.075 and a.get('alignment')=='center':
        return 'Your OWN bbox is off-center but your alignment says center. Reanalyze your current image and correct your assessment.'
    if abs(error)>.1 and v['x']>0 and v['y']*error<=0 and v['yaw']*error<=0:
        return 'Your motion advances without correcting toward the target in YOUR OWN bbox. Positive body y/yaw is right; negative is left. Reanalyze and choose your own correction, not the opposing direction.'
    return None
