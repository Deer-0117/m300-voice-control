"""Simulation mission authorization: revision-bound, explicit confirmation only."""
import hashlib
import json
import secrets
from uav_capabilities import validate_plan

class MissionRevision:
    def __init__(self,plan):
        self.plan=validate_plan(plan);self.revision=1;self.status='active'
        self.completed=[];self.token=None;self.plan_hash=None
    def interrupt(self,completed):
        self.revision+=1;self.status='interrupted';self.completed=list(completed)
        self.token=None;self.plan_hash=None
    def propose(self,plan):
        candidate=validate_plan(plan)
        colors=[a['parameters']['color'] for a in candidate['actions']]
        if self.completed!=['red'] or colors!=['pink','yellow']:
            raise ValueError('revision must preserve completed red and replace pending target with green')
        self.plan=candidate;self.status='awaiting_confirmation'
        self.token=secrets.token_urlsafe(24)
        self.plan_hash=hashlib.sha256(json.dumps(candidate,sort_keys=True).encode()).hexdigest()
        return dict(revision=self.revision,plan=self.plan,plan_hash=self.plan_hash,token=self.token,
                    completed=self.completed,remaining=['green'],simulation_only=True)
    def confirm(self,receipt):
        if self.status!='awaiting_confirmation':raise ValueError('no pending confirmation')
        if receipt.get('revision')!=self.revision or receipt.get('plan_hash')!=self.plan_hash or receipt.get('token')!=self.token or receipt.get('decision')!='confirm':
            raise ValueError('confirmation does not match pending plan')
        self.status='active';self.token=None
    def permits(self,revision):
        return self.status=='active' and revision==self.revision
