"""Revision-bound simulation plans supporting append, replace and pause."""
import hashlib,json,secrets
from uav_mission_revision import MissionRevision
from uav_capabilities import validate_plan,canonical_balloon_color

class ScenarioMission(MissionRevision):
    def propose(self,plan):
        if self.status!='interrupted':raise ValueError('interrupt before proposing')
        candidate=validate_plan(plan)
        colors=[a['parameters']['color'] for a in candidate['actions']]
        completed=[canonical_balloon_color(c) for c in self.completed]
        if colors[:len(completed)]!=completed:raise ValueError('completed prefix must remain unchanged')
        if len(colors)!=len(set(colors)):raise ValueError('duplicate target unsupported by fixed balloon scene')
        self.plan=candidate;self.status='awaiting_confirmation';self.token=secrets.token_urlsafe(24)
        self.plan_hash=hashlib.sha256(json.dumps(candidate,sort_keys=True).encode()).hexdigest()
        return dict(revision=self.revision,plan=self.plan,plan_hash=self.plan_hash,token=self.token,
                    completed=self.completed,remaining=colors[len(completed):],simulation_only=True)
    def pause(self):
        if self.status!='interrupted':raise ValueError('interrupt before pause')
        self.status='paused';self.token=None;self.plan_hash=None
