"""Ground support extension; unchanged reduced-order airborne dynamics, no SDK."""
import numpy as np
from PIL import Image, ImageDraw
from uav_static_world_sim import WIDTH, HEIGHT, FOCAL, BALLOONS, RGB
from uav_dynamic_world import DynamicWorld

class GroundWorld(DynamicWorld):
    def __init__(self):
        super().__init__()
        self.z=0.
        self.anchor=np.array([self.x,self.y,self.z])
        self.grounded=True

    def flight_state(self):
        return {**super().flight_state(), 'grounded':self.grounded,
                'altitude_agl_m':self.z,'heading_deg':float(np.degrees(self.yaw))}

    def integrate(self,command,dt):
        old=(self.x,self.y,self.yaw)
        hits=super().integrate(command,dt)
        if self.grounded and self.applied['z']<=0:
            self.x,self.y,self.yaw=old
            self.z=0.;self.v[:]=0.;self.yr=0.;self.accel[:]=0.
            self.anchor=np.array([self.x,self.y,0.]);self.integral[:]=0.
            self.path[-1]=(self.x,self.y)
        elif self.z>0:
            self.grounded=False
        if self.z<0:
            self.z=0.;self.v[2]=0.;self.grounded=True
        return hits

    def render(self):
        im = Image.new('RGB', (WIDTH, HEIGHT), '#324B60')
        d = ImageDraw.Draw(im)
        d.rectangle((0,HEIGHT/2,WIDTH,HEIGHT),fill='#243C40')
        # World-fixed floor grid at z=0, reprojected from the moving camera.
        for x in np.arange(-2, 17, 1):
            pts=[self.project(float(x), float(y), 0) for y in np.arange(-12,13,.3)]
            pts=[(p[0],p[1]) for p in pts if p and -1000<p[0]<1880 and -1000<p[1]<1480]
            if len(pts)>1:d.line(pts, fill='#3C5558',width=1)
        for y in np.arange(-10,11,1):
            pts=[self.project(float(x),float(y),0) for x in np.arange(-2,17,.3)]
            pts=[(p[0],p[1]) for p in pts if p and -1000<p[0]<1880 and -1000<p[1]<1480]
            if len(pts)>1:d.line(pts,fill='#3C5558',width=1)
        order=sorted(BALLOONS,key=lambda b:(b[1]-self.x)**2+(b[2]-self.y)**2,reverse=True)
        for color,x,y,z in order:
            if color in self.contacts:continue  # contacted targets disappear; world coordinates never change
            p=self.project(x,y,z)
            if not p:continue
            u,v,depth=p; r=min(1600,FOCAL*.25/depth)
            if u+r<0 or u-r>WIDTH or v+r<0 or v-r>HEIGHT:continue
            d.line((u,v+r*1.2,u,v+r*2),fill='#97A9AF',width=1)
            for rr in range(max(1,int(r)),0,-2):
                k=1-rr/r
                d.ellipse((u-rr,v-rr*1.15,u+rr,v+rr*1.15), fill=tuple(int(c*(.7+.3*k)) for c in RGB[color]))
            d.ellipse((u-r*.45,v-r*.65,u-r*.18,v-r*.3), fill=tuple(min(255,int(c*.5+110)) for c in RGB[color]))
        return im

