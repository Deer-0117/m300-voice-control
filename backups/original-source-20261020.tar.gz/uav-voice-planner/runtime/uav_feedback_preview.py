"""Replay vision + telemetry through existing C controller, with no aircraft transport."""
import ctypes
import math
from uav_capabilities import validate_plan, canonical_balloon_color, balloon_matches
from uav_dji_preview import MODE, joystick_arguments


def numbers(values, count):
    if not isinstance(values, list) or len(values) != count:
        raise ValueError('wrong vector size')
    if any(type(v) not in (int, float) or not math.isfinite(v) or abs(v) > 1e7 for v in values):
        raise ValueError('invalid numeric data')
    return values


def timestamp(value):
    if type(value) is not int or not 0 <= value < 2**63:
        raise ValueError('invalid timestamp')
    return value


def bounded_preview_command(values):
    """Enforce the core's default project envelope after SDK-format validation."""
    raw = joystick_arguments(values)
    bounded = dict(raw)
    horizontal = math.hypot(raw['x'], raw['y'])
    if horizontal > 2.0:
        bounded['x'] *= 2.0 / horizontal
        bounded['y'] *= 2.0 / horizontal
    bounded['z'] = max(-.3, min(.3, raw['z']))
    bounded['yaw'] = max(-10.0, min(10.0, raw['yaw']))
    return bounded, raw


class FeedbackPreview:
    def __init__(self, library, plan, camera, action_index=1):
        self.plan = validate_plan(plan)
        if type(action_index) is not int or not 1 <= action_index <= len(self.plan['actions']):
            raise ValueError('invalid action index')
        self.index = action_index
        action = self.plan['actions'][action_index - 1]
        if action['capability'] != 'strike_balloon' or action['parameters']['color'] == 'any':
            raise ValueError('explicit balloon color required')
        self.color = canonical_balloon_color(action['parameters']['color'])
        geometry = numbers([camera[k] for k in ('width', 'height', 'hfov_deg', 'vfov_deg')], 4)
        if not all(1 < v < 10000 for v in geometry[:2]) or not all(1 < v < 179 for v in geometry[2:]):
            raise ValueError('invalid camera geometry')
        self.camera = geometry
        self.lib = ctypes.CDLL(str(library))
        self.lib.Preview_Create.argtypes = [ctypes.c_float] * 4
        self.lib.Preview_Create.restype = ctypes.c_void_p
        self.lib.Preview_Destroy.argtypes = [ctypes.c_void_p]
        self.lib.Preview_Destroy.restype = None
        self.lib.Preview_Step.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float),
                                        ctypes.c_ulonglong, ctypes.c_ulonglong, ctypes.c_ulonglong,
                                        ctypes.POINTER(ctypes.c_float)]
        self.lib.Preview_Step.restype = ctypes.c_int
        self.pointer = None
        self.last_now = None
        self._reset()

    def _reset(self):
        self.close()
        self.pointer = self.lib.Preview_Create(*self.camera)
        if not self.pointer:
            raise MemoryError('controller allocation failed')

    def close(self):
        if self.pointer:
            self.lib.Preview_Destroy(self.pointer)
            self.pointer = None

    def reset_tracking(self):
        """Discard motion history after a model gate or input discontinuity."""
        if self.pointer is None:
            raise RuntimeError('controller is closed')
        self._reset()

    def step(self, frame):
        result = dict(action_index=self.index, target_color_group=self.color,
                      execution_allowed=False, human_confirmation='pending', sdk_called=False,
                      sdk_return_code=None, transport='local_record_only', completion=False,
                      value_source='existing_target_chase_controller', api=None, arguments=None)
        if self.pointer is None:
            return dict(result, decision='blocked', reason='controller_closed')
        reason = None
        try:
            now = timestamp(frame['now_ms'])
            if self.last_now is not None and now <= self.last_now:
                raise ValueError('non-monotonic replay clock')
            self.last_now = now
            state, vision = frame['aircraft'], frame['vision']
            st, vt = timestamp(state['timestamp_ms']), timestamp(vision['target_timestamp_ms'])
            bt = timestamp(frame.get('camera_boresight_timestamp_ms', st))
            result.update(now_ms=now, state_age_ms=now-st, vision_age_ms=now-vt)
            for field in ('in_air', 'velocity_healthy', 'has_authority'):
                if type(state[field]) is not bool:
                    raise ValueError('state flags must be bool')
            values = numbers([state['altitude_agl_m']], 1)
            for field in ('velocity_neu_mps', 'attitude_deg', 'angular_rate_radps'):
                values += numbers(state[field], 3)
            values += numbers(frame['camera_boresight_deg'], 2)
            if not 0 <= now-st <= 500:
                reason = 'stale_or_future_aircraft_state'
            elif not state['in_air']:
                reason = 'not_in_air'
            elif not state['has_authority']:
                reason = 'no_authority'
            elif not state['velocity_healthy']:
                reason = 'unhealthy_velocity'
            elif not 3 <= values[0] <= 80 or max(abs(v) for v in values[4:6]) > 20 or max(abs(v) for v in values[7:10]) > 1:
                reason = 'flight_state_outside_preview_envelope'
            elif not 0 <= now-vt <= 800:
                reason = 'stale_or_future_vision'
            elif abs(st-vt) > 200:
                reason = 'vision_state_unsynchronized'
            elif not 0 <= now-bt <= 500 or abs(bt-vt) > 200:
                reason = 'camera_boresight_unsynchronized'
            elif vision.get('ok') is not True:
                reason = 'vision_not_ok'
            elif vision['width'] != self.camera[0] or vision['height'] != self.camera[1]:
                reason = 'image_geometry_mismatch'
            else:
                candidates = []
                for item in vision['detections']:
                    if not isinstance(item, dict):
                        raise ValueError('invalid detection record')
                    if not balloon_matches(item, self.color):
                        continue
                    score = numbers([item['confidence']], 1)[0]
                    box = numbers(item['bbox_xyxy'], 4)
                    if not 0 <= score <= 1 or not (0 <= box[0] < box[2] <= self.camera[0] and 0 <= box[1] < box[3] <= self.camera[1]):
                        raise ValueError('invalid detection')
                    if score >= 0.6:
                        candidates.append(item)
                if len(candidates) != 1:
                    reason = 'no_matching_target' if not candidates else 'ambiguous_targets'
                else:
                    target = candidates[0]
                    result['selected_detection'] = target
                    data = (ctypes.c_float * 16)(*(values + target['bbox_xyxy']))
                    out = (ctypes.c_float * 4)()
                    if not self.lib.Preview_Step(self.pointer, data, now, st, vt, out):
                        reason = 'controller_has_no_command'
                    else:
                        bounded, raw = bounded_preview_command(list(out))
                        result.update(api='DjiFlightController_ExecuteJoystickAction',
                                      arguments=bounded, raw_controller_arguments=raw,
                                      output_limited=(bounded != raw),
                                      preview_limits={'horizontal_mps': 2.0, 'vertical_mps': .3, 'yaw_degps': 10.0},
                                      decision='controller_preview')
        except (KeyError, TypeError, ValueError, OverflowError, AttributeError):
            reason = 'invalid_feedback'
        if reason:
            # A disconnected/invalid state is not proof that a hover command can be issued.
            # Suppress call preview and reset prediction history; do not reuse last movement.
            self._reset()
            result.update(decision='blocked', reason=reason)
        return result
