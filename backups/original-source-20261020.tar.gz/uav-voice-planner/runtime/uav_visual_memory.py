"""Historical target sightings from camera pixels and vehicle odometry only."""
import math
from uav_action_feedback import target_measurement

def select_sightings(frames,target='green'):
    visible=[]
    for f in frames:
        m=target_measurement(f['vision'],target)
        if m.get('visible') and not m['clipped']:
            visible.append(dict(frame_index=f['frame_index'],time_s=f['sim_time_s'],pose=f['pose_before'],measurement=m))
    if not visible:return []
    indexes=sorted(set([0,len(visible)//2,len(visible)-1]))
    return [visible[i] for i in indexes]

def history_hint(sightings,pose):
    if not sightings:return dict(available=False,reason='no historical visual sighting')
    last=sightings[-1];m=last['measurement'];p=last['pose'];depth=m['estimated_depth_m']
    right=depth*math.tan(math.radians(m['bearing_right_deg']))
    # Estimate from image size and pose, never from simulator balloon coordinates.
    x=p['x']+depth*math.cos(p['yaw'])-right*math.sin(p['yaw'])
    y=p['y']+depth*math.sin(p['yaw'])+right*math.cos(p['yaw'])
    bearing=math.atan2(y-pose['y'],x-pose['x'])-pose['yaw']
    bearing=math.atan2(math.sin(bearing),math.cos(bearing))
    return dict(available=True,last_seen_frame=last['frame_index'],last_seen_time_s=last['time_s'],
                estimated_bearing_right_deg=math.degrees(bearing),
                estimated_position_xy_from_pixels_and_odometry=[x,y],
                provenance='historical image diameter/bearing plus vehicle pose; uncertain, not simulator target ground truth',
                use='orient search only; require fresh detection before approach')
