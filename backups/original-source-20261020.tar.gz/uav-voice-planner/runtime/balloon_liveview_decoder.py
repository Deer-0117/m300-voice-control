#!/usr/bin/env python3
"""Decode the DJI PSDK H.264 FIFO and publish low-latency frames in tmpfs."""

from __future__ import annotations

import argparse
import json
import os
import stat
import time
from collections import deque
from pathlib import Path

import cv2


DEFAULT_FIFO = Path("/tmp/balloon_liveview.h264")
DEFAULT_FRAME_DIR = Path("/dev/shm/balloon_liveview_frames")
DEFAULT_METADATA = Path("/dev/shm/balloon_liveview_latest.tsv")
DEFAULT_LOG = Path("/home/uav/offline_balloon_strike_test/liveview_decoder.jsonl")


def now_ms() -> int:
    return time.time_ns() // 1_000_000


def append_log(path: Path, event: str, **fields: object) -> None:
    payload = {"ts_ms": now_ms(), "event": event, **fields}
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, separators=(",", ":")) + "\n")


def ensure_fifo(path: Path) -> None:
    try:
        mode = path.stat().st_mode
        if stat.S_ISFIFO(mode):
            return
        path.unlink()
    except FileNotFoundError:
        pass
    os.mkfifo(path, 0o666)


def hardware_pipeline(fifo: Path) -> str:
    return (
        f"filesrc location={fifo} do-timestamp=true ! "
        "h264parse ! nvv4l2decoder disable-dpb=true enable-max-performance=true ! "
        "nvvidconv ! video/x-raw,format=BGRx ! videoconvert ! "
        "video/x-raw,format=BGR ! appsink drop=true max-buffers=1 sync=false"
    )


def software_pipeline(fifo: Path) -> str:
    return (
        f"filesrc location={fifo} do-timestamp=true ! "
        "h264parse ! avdec_h264 ! videoconvert ! video/x-raw,format=BGR ! "
        "appsink drop=true max-buffers=1 sync=false"
    )


def atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def resize_for_publish(frame: object, max_frame_side: int) -> object:
    height, width = frame.shape[:2]
    longest_side = max(int(width), int(height))
    if max_frame_side <= 0 or longest_side <= max_frame_side:
        return frame
    ratio = float(max_frame_side) / float(longest_side)
    target = (max(1, round(width * ratio)), max(1, round(height * ratio)))
    return cv2.resize(frame, target, interpolation=cv2.INTER_AREA)


def near_rate_hint_active(path: Path, max_age_ms: int) -> bool:
    try:
        hinted_ms = int(path.read_text(encoding="ascii").strip())
    except (FileNotFoundError, OSError, ValueError):
        return False
    current_ms = now_ms()
    return (
        hinted_ms > 0
        and current_ms >= hinted_ms
        and current_ms - hinted_ms <= max(100, max_age_ms)
    )


def publish_frame(frame_dir: Path, metadata: Path, frame_id: int, frame: object,
                  jpeg_quality: int, max_frame_side: int = 0,
                  frame_format: str = "jpg") -> tuple[Path, int, int, int]:
    encode_started = time.perf_counter_ns()
    published = resize_for_publish(frame, max_frame_side)
    normalized_format = frame_format.strip().lower()
    if normalized_format not in {"jpg", "bmp"}:
        raise ValueError(f"unsupported frame format: {frame_format}")
    extension = f".{normalized_format}"
    encode_options = [cv2.IMWRITE_JPEG_QUALITY, jpeg_quality] if normalized_format == "jpg" else []
    ok, encoded = cv2.imencode(extension, published, encode_options)
    if not ok:
        raise RuntimeError("cv2.imencode returned false")
    encoded_bytes = encoded.tobytes()
    frame_path = frame_dir / f"frame_{frame_id:012d}{extension}"
    atomic_write(frame_path, encoded_bytes)
    ready_ms = now_ms()
    encode_ms = (time.perf_counter_ns() - encode_started) // 1_000_000
    metadata_payload = f"{frame_id}\t{ready_ms}\t{encode_ms}\t{frame_path}\n".encode("utf-8")
    atomic_write(metadata, metadata_payload)
    height, width = published.shape[:2]
    return frame_path, int(encode_ms), int(width), int(height)


def decode_loop(args: argparse.Namespace) -> None:
    frame_dir: Path = args.frame_dir
    metadata: Path = args.metadata
    fifo: Path = args.fifo
    log_path: Path = args.log
    frame_dir.mkdir(parents=True, exist_ok=True)
    metadata.parent.mkdir(parents=True, exist_ok=True)
    ensure_fifo(fifo)

    for pattern in ("frame_*.jpg", "frame_*.bmp"):
        for old in frame_dir.glob(pattern):
            try:
                old.unlink()
            except OSError:
                pass
    try:
        metadata.unlink()
    except FileNotFoundError:
        pass

    normal_min_publish_ns = int(
        1_000_000_000 / max(1.0, args.publish_fps)
    )
    near_min_publish_ns = int(
        1_000_000_000 /
        max(args.publish_fps, args.near_publish_fps, 1.0)
    )
    last_publish_ns = 0
    frame_id = 0
    retained: deque[Path] = deque()
    # DJI M300/H20 streams may use GDR encoding. On this aircraft the hardware
    # decoder can block inside VideoCapture for the entire next stream after a
    # previous stream ends. Software-only mode avoids that cross-session stall.
    pipeline_options = {
        "software": [("software", software_pipeline(fifo))],
        "hardware": [("hardware", hardware_pipeline(fifo))],
        "auto": [
            ("software", software_pipeline(fifo)),
            ("hardware", hardware_pipeline(fifo)),
        ],
    }
    pipelines = pipeline_options[args.decoder]

    append_log(log_path, "decoder_start", fifo=str(fifo),
               publish_fps=args.publish_fps,
               near_publish_fps=args.near_publish_fps,
               near_rate_hint_max_age_ms=args.near_rate_hint_max_age_ms,
               opencv=cv2.__version__, decoder_mode=args.decoder,
               frame_format=args.frame_format, max_frame_side=args.max_frame_side)
    while True:
        for decoder_name, pipeline in pipelines:
            append_log(log_path, "pipeline_open", decoder=decoder_name, pipeline=pipeline)
            capture = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
            if not capture.isOpened():
                append_log(log_path, "pipeline_open_failed", decoder=decoder_name)
                capture.release()
                continue

            received = 0
            while True:
                ok, frame = capture.read()
                if not ok or frame is None:
                    append_log(log_path, "stream_read_ended", decoder=decoder_name,
                               received_frames=received)
                    break
                received += 1
                current_ns = time.monotonic_ns()
                min_publish_ns = (
                    near_min_publish_ns
                    if near_rate_hint_active(
                        args.near_rate_hint, args.near_rate_hint_max_age_ms
                    )
                    else normal_min_publish_ns
                )
                if last_publish_ns and current_ns - last_publish_ns < min_publish_ns:
                    continue

                frame_id += 1
                try:
                    frame_path, encode_ms, published_width, published_height = publish_frame(
                        frame_dir, metadata, frame_id, frame, args.jpeg_quality,
                        args.max_frame_side, args.frame_format,
                    )
                except Exception as exc:
                    append_log(log_path, "publish_failed", frame_id=frame_id, error=repr(exc))
                    continue
                last_publish_ns = current_ns
                retained.append(frame_path)
                while len(retained) > args.retain_frames:
                    stale = retained.popleft()
                    try:
                        stale.unlink()
                    except FileNotFoundError:
                        pass
                if frame_id == 1 or frame_id % 100 == 0:
                    append_log(log_path, "frame_published", decoder=decoder_name,
                               frame_id=frame_id, encode_ms=encode_ms,
                               source_width=int(frame.shape[1]), source_height=int(frame.shape[0]),
                               width=published_width, height=published_height,
                               frame_format=args.frame_format)

            capture.release()
            time.sleep(0.2)
        time.sleep(0.5)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fifo", type=Path, default=DEFAULT_FIFO)
    parser.add_argument("--frame-dir", type=Path, default=DEFAULT_FRAME_DIR)
    parser.add_argument("--metadata", type=Path, default=DEFAULT_METADATA)
    parser.add_argument("--log", type=Path, default=DEFAULT_LOG)
    parser.add_argument("--publish-fps", type=float, default=10.0)
    parser.add_argument("--near-publish-fps", type=float, default=18.0)
    parser.add_argument(
        "--near-rate-hint",
        type=Path,
        default=Path("/dev/shm/balloon_near_rate.hint"),
    )
    parser.add_argument("--near-rate-hint-max-age-ms", type=int, default=500)
    parser.add_argument("--jpeg-quality", type=int, default=90)
    parser.add_argument("--frame-format", choices=("jpg", "bmp"), default="jpg")
    parser.add_argument(
        "--max-frame-side",
        type=int,
        default=0,
        help="resize frames so the longest side is at most this value; 0 disables resizing",
    )
    parser.add_argument("--retain-frames", type=int, default=40)
    parser.add_argument("--decoder", choices=("software", "hardware", "auto"),
                        default="software")
    return parser


if __name__ == "__main__":
    decode_loop(build_parser().parse_args())
