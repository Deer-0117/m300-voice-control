"""Fresh end-to-end pure-visual simulation gate for any ordered balloon target."""
import math
from uav_model_velocity import ModelVelocityPreview,validate_segment
from uav_action_feedback import target_measurement
from uav_capabilities import canonical_balloon_color

class FullMissionPreview(ModelVelocityPreview):
    def __init__(self,plan,literal_plan,index):
        super().__init__(plan,index);self.literal_plan=literal_plan;self.target=literal_plan[index-1]
        self.gate.ttl_ms=3500;self.search=False;self.bad_frames=0;self.initial_error=0.
    def close(self):super().close();self.search=False
    def accept_model(self,d,v,**receipt):
        self.close()
        try:
            duration=d['duration_s'];mode=d['mode']
            if type(duration) not in (float,int) or not math.isfinite(duration) or not .1<=duration<=3:raise ValueError('duration outside .1..3')
            if d['plan']!=self.literal_plan or d['target']!=self.target:raise ValueError('plan or target differs from active mission')
            search=mode in ('search_left','search_right')
            command,_=validate_segment({**d,'duration_s':min(1.,duration),'mode':'approach' if search else mode})
            if search and (any(command[k] for k in ('x','y','z')) or (command['yaw']<=0 if mode=='search_right' else command['yaw']>=0)):raise ValueError('invalid pure rotation')
            if v['frame_id']!=receipt['frame_id'] or v['target_timestamp_ms']!=receipt['image_timestamp_ms']:raise ValueError('source frame mismatch')
            if not 0<=receipt['received_timestamp_ms']-receipt['image_timestamp_ms']<=2500:raise ValueError('stale source')
            if search:
                if receipt['sequence']<=self.gate.last_sequence:raise ValueError('stale sequence')
                self.gate.last_sequence=receipt['sequence']
            else:
                error=self.gate.accept(d,v,revision=2,plan=self.plan,action_index=self.action_index,**receipt)
                if error:return error
        except (KeyError,ValueError,TypeError) as exc:return str(exc)
        self.search=search;self.command=command;self.start=receipt['received_timestamp_ms']+50
        self.deadline=self.start+int(duration*20+1e-8)*50;self.bad_frames=0
        self.initial_error=abs(target_measurement(v,self.target).get('horizontal_error_normalized',0.))
        return None
    def step(self,f):
        if not self.search:
            r=super().step(f)
            if r['arguments'] is not None:
                m=target_measurement(f['vision'],self.target)
                bad=m.get('visible') and abs(m['horizontal_error_normalized'])>max(.25,self.initial_error+.15)
                self.bad_frames=self.bad_frames+1 if bad else 0
                if self.bad_frames>=3:self.close();r.update(arguments=None,reason='visual_error_increased')
            return r
        t=f['now_ms'];v=f['vision'];s=f['aircraft'];reason=None
        if not self.start<=t<self.deadline:reason='search_expired'
        elif not 0<=t-v['target_timestamp_ms']<=100 or not 0<=t-s['timestamp_ms']<=100:reason='stale_search_feedback'
        elif not s['in_air'] or not s['has_authority'] or not s['velocity_healthy'] or not 3<=s['altitude_agl_m']<=80:reason='invalid_flight_state'
        elif any(canonical_balloon_color(d['color_name'])==canonical_balloon_color(self.target) for d in v['detections']):reason='target_reacquired'
        if reason:self.close()
        return dict(arguments=None if reason else dict(self.command),reason=reason,execution_allowed=False,sdk_called=False,segment_deadline_ms=self.deadline)
