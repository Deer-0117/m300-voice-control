"""Kinematic image-feedback sandbox. No aircraft or DJI imports."""
import math
import numpy as np
from PIL import Image, ImageDraw

WIDTH, HEIGHT = 880, 480
FOCAL = WIDTH / (2 * math.tan(math.radians(73.7 / 2)))
BALLOONS = (('red', 4.0, -1.0, 10.0), ('green', 5.5, 2.0, 10.0), ('purple', 7.0, 0.0, 10.0))
RGB = {'red': (239, 65, 76), 'green': (45, 205, 108), 'purple': (174, 83, 235)}


class World:
    def __init__(self):
        self.x = self.y = self.yaw = 0.0
        self.z = 10.0
        self.contacts = []
        self.path = [(0., 0.)]

    def project(self, x, y, z):
        dx, dy = x-self.x, y-self.y
        depth = math.cos(self.yaw)*dx + math.sin(self.yaw)*dy
        right = -math.sin(self.yaw)*dx + math.cos(self.yaw)*dy
        if depth <= .08:
            return None
        return WIDTH/2 + FOCAL*right/depth, HEIGHT/2 - FOCAL*(z-self.z)/depth, depth

    def render(self):
        im = Image.new('RGB', (WIDTH, HEIGHT), '#324B60')
        d = ImageDraw.Draw(im)
        d.rectangle((0,HEIGHT/2,WIDTH,HEIGHT),fill='#243C40')
        # World-fixed floor grid at z=8, reprojected from the moving camera.
        for x in np.arange(-2, 17, 1):
            pts=[self.project(float(x), float(y), 8) for y in np.arange(-12,13,.3)]
            pts=[(p[0],p[1]) for p in pts if p and -1000<p[0]<1880 and -1000<p[1]<1480]
            if len(pts)>1:d.line(pts, fill='#3C5558',width=1)
        for y in np.arange(-10,11,1):
            pts=[self.project(float(x),float(y),8) for x in np.arange(-2,17,.3)]
            pts=[(p[0],p[1]) for p in pts if p and -1000<p[0]<1880 and -1000<p[1]<1480]
            if len(pts)>1:d.line(pts,fill='#3C5558',width=1)
        order=sorted(BALLOONS,key=lambda b:(b[1]-self.x)**2+(b[2]-self.y)**2,reverse=True)
        for color,x,y,z in order:
            if color in self.contacts:continue  # contacted targets disappear; world coordinates never change
            p=self.project(x,y,z)
            if not p:continue
            u,v,depth=p; r=min(1600,FOCAL*.25/depth)
            if u+r<0 or u-r>WIDTH or v+r<0 or v-r>HEIGHT:continue
            d.line((u,v+r*1.2,u,v+r*2),fill='#97A9AF',width=1)
            for rr in range(max(1,int(r)),0,-2):
                k=1-rr/r
                d.ellipse((u-rr,v-rr*1.15,u+rr,v+rr*1.15), fill=tuple(int(c*(.7+.3*k)) for c in RGB[color]))
            d.ellipse((u-r*.45,v-r*.65,u-r*.18,v-r*.3), fill=tuple(min(255,int(c*.5+110)) for c in RGB[color]))
        return im

    def integrate(self, command, dt):
        # Ideal velocity-following kinematics, not an M300 dynamics model.
        yaw_mid=self.yaw+math.radians(command['yaw'])*dt/2
        self.x += (command['x']*math.cos(yaw_mid)-command['y']*math.sin(yaw_mid))*dt
        self.y += (command['x']*math.sin(yaw_mid)+command['y']*math.cos(yaw_mid))*dt
        self.z += command['z']*dt
        self.yaw += math.radians(command['yaw'])*dt
        self.path.append((self.x,self.y))
        hits=[]
        for color,x,y,z in BALLOONS:
            if color not in self.contacts and math.sqrt((x-self.x)**2+(y-self.y)**2+(z-self.z)**2)<=.45:
                self.contacts.append(color);hits.append(color)
        return hits


def detect_pixels(image):
    """Color masks from actual RGB pixels, for this clean synthetic scene only."""
    a=np.asarray(image).astype(float)
    r,g,b=a[:,:,0],a[:,:,1],a[:,:,2]
    masks={'red':(r>100)&(r>g*1.7)&(r>b*1.5),
           'green':(g>95)&(g>r*1.5)&(g>b*1.3),
           'purple':(b>100)&(r>70)&(b>g*1.6)&(r>g*1.35)&(b>r*1.1)}
    result={}
    for color,mask in masks.items():
        yy,xx=np.nonzero(mask)
        if len(xx)>=25:
            result[color]=[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]
    return result


def image_servo(box):
    u=(box[0]+box[2])/2; v=(box[1]+box[3])/2
    bearing=math.degrees(math.atan((u-WIDTH/2)/FOCAL))
    elevation=math.atan((HEIGHT/2-v)/FOCAL)
    speed=.85 if abs(bearing)<8 else .12
    if (box[2]-box[0])/WIDTH>.45:speed=min(speed,.35)
    return {'x':speed,'y':0.,'z':max(-.2,min(.2,speed*math.tan(elevation))),
            'yaw':max(-22.,min(22.,1.8*bearing))}


def overlap(normalized_box, pixel_box):
    b=[normalized_box[0]*WIDTH,normalized_box[1]*HEIGHT,normalized_box[2]*WIDTH,normalized_box[3]*HEIGHT]
    inter=max(0,min(b[2],pixel_box[2])-max(b[0],pixel_box[0]))*max(0,min(b[3],pixel_box[3])-max(b[1],pixel_box[1]))
    union=(b[2]-b[0])*(b[3]-b[1])+(pixel_box[2]-pixel_box[0])*(pixel_box[3]-pixel_box[1])-inter
    return inter/union if union>0 else 0
