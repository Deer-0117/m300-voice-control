"""Conservative visual-only progress evidence for offline task replay.

Near-then-missing is provisional evidence, never proof of physical contact.
"""
from uav_capabilities import canonical_balloon_color


class VisualProgress:
    def __init__(self, colors, missing_frames=3, evidence_window_ms=1500):
        self.colors=list(colors)
        self.completed=[]
        self.near_timestamp=None
        self.missing=0
        self.last_timestamp=None
        self.required_missing=missing_frames
        self.window=evidence_window_ms

    @property
    def target(self):
        return self.colors[len(self.completed)] if len(self.completed)<len(self.colors) else None

    def update(self, vision):
        now=vision['target_timestamp_ms']
        if type(now) is not int or (self.last_timestamp is not None and now<=self.last_timestamp):
            raise ValueError('visual progress requires new, increasing frame timestamps')
        self.last_timestamp=now
        if self.target is None:return None
        if vision.get('ok') is not True:
            self.near_timestamp=None;self.missing=0;return None
        matches=[d for d in vision['detections'] if canonical_balloon_color(d['color_name'])==canonical_balloon_color(self.target)]
        if len(matches)>1:
            self.near_timestamp=None;self.missing=0;return None
        if matches:
            b=matches[0]['bbox_xyxy'];self.missing=0
            if (b[2]-b[0])/vision['width']>=.35:
                self.near_timestamp=now
            else:
                # Retreating to a small target is not completion evidence.
                self.near_timestamp=None
            return None
        if self.near_timestamp is None or not 0<=now-self.near_timestamp<=self.window:
            self.near_timestamp=None;self.missing=0;return None
        self.missing+=1
        if self.missing<self.required_missing:return None
        event={'color':self.target,'timestamp_ms':now,'evidence':'near_then_missing',
               'missing_frames':self.missing,'physical_contact_verified':False,
               'status':'provisional_visual_completion'}
        self.completed.append(self.target);self.near_timestamp=None;self.missing=0
        return event
