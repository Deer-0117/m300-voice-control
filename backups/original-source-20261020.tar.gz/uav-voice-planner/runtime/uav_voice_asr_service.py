#!/usr/bin/env python3
"""Authenticated Chinese speech-to-text service backed by whisper.cpp."""

from __future__ import annotations

import argparse
import hmac
import json
import os
import subprocess
import tempfile
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from uav_paths import project_path


MAX_AUDIO_BYTES = 20 * 1024 * 1024
ASR_LOCK = threading.Lock()


class AsrError(RuntimeError):
    pass


def transcribe_wav(audio: bytes) -> str:
    cli = project_path("UAV_WHISPER_CLI", "local-asr/whisper.cpp/build/bin/whisper-cli")
    model = project_path("UAV_WHISPER_MODEL", "local-asr/whisper.cpp/models/ggml-base.bin")
    state_dir = project_path("UAV_VOICE_ASR_STATE_DIR", "local-voice-test/asr-state")
    if not cli.is_file() or not model.is_file():
        raise AsrError("ASR model is not installed")
    state_dir.mkdir(parents=True, exist_ok=True)
    with ASR_LOCK, tempfile.TemporaryDirectory(prefix="request-", dir=state_dir) as temporary:
        root = Path(temporary)
        wav_path = root / "voice.wav"
        output_prefix = root / "transcript"
        wav_path.write_bytes(audio)
        command = [
            str(cli), "-m", str(model), "-f", str(wav_path),
            "-l", "zh", "-nt", "-np", "-otxt", "-of", str(output_prefix),
        ]
        try:
            completed = subprocess.run(command, capture_output=True, text=True, timeout=120, check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise AsrError(f"ASR execution failed: {exc}") from exc
        transcript_path = output_prefix.with_suffix(".txt")
        if completed.returncode != 0 or not transcript_path.is_file():
            detail = (completed.stderr or completed.stdout).strip()[-300:]
            raise AsrError(f"ASR returned {completed.returncode}: {detail}")
        transcript = "".join(transcript_path.read_text(encoding="utf-8").splitlines()).strip()
        if not transcript:
            raise AsrError("no speech recognized")
        return transcript


class AsrHandler(BaseHTTPRequestHandler):
    server_version = "UavVoiceAsr/1.0"

    def respond(self, status: HTTPStatus, payload: dict[str, object]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status.value)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authorized(self) -> bool:
        expected = os.environ.get("UAV_VOICE_ASR_TOKEN", "")
        supplied = self.headers.get("Authorization", "")
        return bool(expected) and hmac.compare_digest(supplied, f"Bearer {expected}")

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self.respond(HTTPStatus.OK, {"ok": True, "service": "uav-voice-asr"})
        else:
            self.respond(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/transcribe":
            self.respond(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not found"})
            return
        if not self.authorized():
            self.respond(HTTPStatus.UNAUTHORIZED, {"ok": False, "error": "unauthorized"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 44 or length > MAX_AUDIO_BYTES:
                raise AsrError("invalid audio size")
            if self.headers.get("Content-Type", "").split(";", 1)[0] != "audio/wav":
                raise AsrError("Content-Type must be audio/wav")
            transcript = transcribe_wav(self.rfile.read(length))
            self.respond(HTTPStatus.OK, {"ok": True, "transcript": transcript, "language": "zh"})
        except (AsrError, ValueError) as exc:
            self.respond(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(exc)})

    def log_message(self, format_string: str, *args: object) -> None:
        print(f"{self.client_address[0]} {format_string % args}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", default=os.environ.get("UAV_VOICE_ASR_BIND", "192.168.168.222"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("UAV_VOICE_ASR_PORT", "8780")))
    args = parser.parse_args()
    if not os.environ.get("UAV_VOICE_ASR_TOKEN", ""):
        raise SystemExit("UAV_VOICE_ASR_TOKEN is required")
    server = ThreadingHTTPServer((args.bind, args.port), AsrHandler)
    print(f"uav voice ASR listening on {args.bind}:{args.port}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
