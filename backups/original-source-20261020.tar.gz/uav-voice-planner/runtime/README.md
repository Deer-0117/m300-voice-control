# 设备端检测运行时

本目录保存设备上实际运行、但此前未纳入仓库的 Python 脚本：

- `balloon_yolo_worker.py`：常驻 YOLO 推理 worker；
- `balloon_tensorrt.py`：Jetson TensorRT FP16 推理运行层（静态 640×640 引擎）；
- `uav_capabilities.py`：能力注册表、目标描述和严格任务计划校验；
- `uav_natural_language.py`：本地规则命令入口与结构化 `/plan` 接口，并为“停下”生成本地停止标记；
- `balloon_liveview_decoder.py`：将 DJI Liveview H.264 解码并发布最新 JPEG 帧；
- `balloon_tracker_worker.py`：YOLO 间隔内短时续跟；先等待 450 ms 再接管输出，避免覆盖较新的 YOLO 框；MIL 输出使用实际跟踪帧时间戳，并由 1400 ms 的 YOLO 种子寿命限制总续跟时间；
- `detect_latest_photo.py`：单图检测兼容入口。

它们部署到 `/home/uav/offline_balloon_strike_test`。模型权重、Python 虚拟环境、日志、抓拍和设备身份配置不进入 Git；部署前设备上必须已有：

```text
yolo_env/
yolo_callable_module/
yolo_callable_module/weights/best.pt
```

默认仍使用 PyTorch 后端。TensorRT 引擎完成同图对照验证后，通过服务环境变量显式启用：

```text
BALLOON_YOLO_BACKEND=tensorrt
BALLOON_TRT_ENGINE=/home/uav/offline_balloon_strike_test/yolo_callable_module/weights/best_fp16.engine
BALLOON_JPEG_DECODE_DIVISOR=4
```

能力入口服务由 `uav-natural-language.service` 管理。设备私有配置放在 `/etc/uav-natural-language.env`，当前使用 `UAV_NL_BIND`、`UAV_NL_PORT` 和 `UAV_NL_AUTH_TOKEN`。命中判断由 `balloon-yolo-worker.service` 执行；该服务显式设置 `BALLOON_NL_HIT_ARM_AREA_RATIO=0.022`、`BALLOON_NL_HIT_ARM_CONFIRM_FRAMES=2`、`BALLOON_NL_HIT_MISSING_CONFIRM_MS=650`、`BALLOON_NL_ALLOW_TARGET_DEFER=0` 和 `BALLOON_NL_COLOR_OBSERVATION_CACHE_MS=1500`。多目标计划默认严格按提交顺序执行；非当前颜色只写入短期观测记忆，不会把旧坐标作为新目标发送给飞控。不能由本地规则解析的命令可交给受限 Agent，但 Agent 仍只能生成能力库计划。

`CapabilityTaskSequence` 在首个目标缺失以及有序撞击阶段切换后写入 `/tmp/balloon_target_search.request`。飞控循环消费该请求，立即清除上一阶段的目标与跟踪滤波状态，并从第一个扇区重新执行云台栅格扫描和机身分区转向搜索。发现当前阶段颜色后请求自动取消。大模型计划仍只需要按顺序给出 `strike_balloon(color)`；阶段间搜索由执行器自动插入，独立粉黄测试脚本同样生效。

不得把 API 密钥或命令服务令牌提交进仓库。非回环监听必须配置 `UAV_NL_AUTH_TOKEN`。当前首个业务能力为 `strike_balloon(color)`，颜色支持 red、orange、yellow、green、blue、purple、pink 和 `any`；`stop` 是独立本地安全能力。无显式计划的原气球撞击测试使用 `DEFAULT_TEST_ACTION=strike_balloon(color=any)`。`GET /capabilities` 返回能力目录，`POST /plan` 接收结构化计划。

`BALLOON_JPEG_DECODE_DIVISOR` 可取 `1/2/4/8`，表示 JPEG 解码阶段允许使用的最大 DCT 缩放倍数；YOLO 输入仍为 640×640。当前历史样本验证采用 `4`，兼顾小目标识别与延迟。

Liveview 解码器保留 `--max-frame-side` 与 `--frame-format` 供离线研究，但正式服务继续发布原尺寸 JPEG。2026-07-20 实机测试表明 JPEG 编码 P50/P95 仅 8/12 ms，采集到检测完成 P50/P95 为 56/66 ms；640 长边候选又会漏掉真实远距离小气球，因此缩放和 BMP 候选均不部署。详见 `docs/LIVEVIEW_RESIZE_VALIDATION.md`。

TensorRT 初始化失败时 worker 会记录 `worker_backend_fallback` 并回退到 PyTorch，避免检测链路直接中断。

切换前必须在同一批历史照片上运行 `scripts/benchmark_balloon_backends.py`。默认门槛为：检测有无一致率和相对召回率均不低于 98%，共同检出目标的中位框 IoU 不低于 0.95，P50 至少加速 2 倍，TensorRT 端到端 P95 不高于 250 ms。未通过时不得设置 `BALLOON_YOLO_BACKEND=tensorrt`。

在仓库根目录先查看计划，再执行部署：

```powershell
.\scripts\deploy-runtime.ps1
.\scripts\deploy-runtime.ps1 -Apply
```

首次安装或更新 systemd 单元时使用 `-InstallServices`。脚本只有在设备最终有效状态同时满足 `ActiveState=active` 与 `BALLOON_NO_FLIGHT=1` 时才会写入文件。
