"""Prompt and time-based frame selection; no detector data or generated controls."""
STRATEGY = '''
PURE-VISUAL ALIGNMENT AND PROGRESS STRATEGY:
1. Re-detect the target from the LAST current image on every turn. Use your OWN bbox to estimate its center: (left+right)/2. Compare it to image center 0.5. Do not say centered when its center is outside [0.44,0.56]. A large balloon is not necessarily centered. Never copy a prior box blindly.
2. Compare the time-ordered recent raw images BEFORE, DURING and AFTER the latest action. Decide whether your previous lateral/yaw action moved the target TOWARD image center or AWAY, and whether its apparent size increased. These are YOUR pixel estimates, not supplied local measurements. Account for camera rotation. A small or nearly unchanged image displacement despite commanded motion means insufficient actual progress, not contact.
3. If the target is right, correct right; if left, correct left. When substantially off-center prioritize alignment over forward speed. For large errors use yaw to bring it towards center and/or lateral motion with restrained forward motion. Do not keep advancing with almost-zero lateral correction while a near balloon drifts to an edge. Do not reduce lateral correction merely because the balloon looks large. When it is clipped at a side, prioritize turning towards that side and recentering before substantial advance. Infer direction from the visible portion and previous frames, never invent unseen size/depth.
4. Use actual mean velocity in recent_actions and the sequence of images to assess effectiveness. Input delay .15s and velocity tau .45s make repeated .4-.5s pulses with x around .05-.15m/s inefficient. If repeated actions produce little visual progress, choose a materially different duration or velocity, not the same tiny step again. Near contact reduce forward SPEED while retaining an effective duration, often .8-1.5s if alignment is stable; do not repeatedly shorten both speed and time. When far/aligned, use 1-3s within limits. These are guidelines: YOU decide all values, and may shorten when visual motion predicts overshoot.
5. Compensate observed lateral drift from your OWN before/after pixel observations and measured velocity. No wind or target-offset estimate is supplied. If the previous action made alignment worse, change correction direction/magnitude or turn to align; do not repeat it. Only contact telemetry proves completion. A missing target without a contact event requires search, not done.
In your JSON add visual_assessment with center_x_from_own_bbox (number or null), alignment (left/center/right/unseen), last_action_effect (brief words), and duration_choice (brief rationale). These fields are your visual judgments and are NOT substituted by local code. Keep reason short. All existing velocity limits and simulation-only restrictions remain.
'''

def select_action_frames(samples):
    """Select three causal frames bracketing latest motion, solely by time/phase."""
    samples=list(samples)
    if len(samples)<3:raise ValueError('need three historical frames')
    motion=[i for i,s in enumerate(samples) if s['phase']=='revised_motion']
    if motion:
        end=motion[-1];start=end
        while start>0 and samples[start-1]['phase']=='revised_motion':start-=1
        indices=sorted({max(0,start-1),end,len(samples)-1})
        if len(indices)==3:return [samples[i] for i in indices]
    return [samples[0],samples[len(samples)//2],samples[-1]]
