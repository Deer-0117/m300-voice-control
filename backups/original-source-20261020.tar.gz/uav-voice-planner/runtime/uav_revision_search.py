"""Confirmed simulation-only rotation to reacquire an unseen revised target."""
from uav_model_velocity import ModelVelocityPreview,validate_segment
from uav_capabilities import canonical_balloon_color

def validate_revised_decision(decision):
    if decision.get('mode') in ('search_left','search_right'):
        command,duration=validate_segment({**decision,'mode':'approach'})
        if any(command[k] for k in ('x','y','z')) or (command['yaw']<=0 if decision['mode']=='search_right' else command['yaw']>=0):
            raise ValueError('search must be pure rotation in declared direction')
        return command,duration
    return validate_segment(decision)

class RevisionSearchPreview(ModelVelocityPreview):
    def __init__(self,plan,action_index):
        super().__init__(plan,action_index);self.search=False
    def close(self):
        super().close();self.search=False
    def accept_model(self,decision,source_vision,**receipt):
        if decision.get('mode') not in ('search_left','search_right'):
            self.search=False;return super().accept_model(decision,source_vision,**receipt)
        self.close()
        try:
            command,duration=validate_revised_decision(decision)
            assert decision['plan']==['red','green'] and decision['target']=='green'
            assert source_vision['frame_id']==receipt['frame_id']
            assert source_vision['target_timestamp_ms']==receipt['image_timestamp_ms']
            assert 0<=receipt['received_timestamp_ms']-receipt['image_timestamp_ms']<=2500
            assert receipt['sequence']>self.gate.last_sequence
        except (KeyError,TypeError,ValueError,AssertionError):return 'invalid_search_response'
        self.gate.last_sequence=receipt['sequence'];self.search=True;self.command=command
        self.start=receipt['received_timestamp_ms']+50;self.deadline=self.start+int(duration*20+1e-8)*50
        self.search_receipt=dict(receipt)
        return None
    def step(self,frame):
        if not self.search:return super().step(frame)
        now=frame['now_ms'];state=frame['aircraft'];vision=frame['vision'];reason=None
        if not self.start<=now<self.deadline:reason='search_expired'
        elif not 0<=now-state['timestamp_ms']<=100 or not 0<=now-vision['target_timestamp_ms']<=100:reason='stale_search_feedback'
        elif not state['in_air'] or not state['velocity_healthy'] or not state['has_authority'] or not 3<=state['altitude_agl_m']<=80:reason='invalid_search_state'
        elif any(canonical_balloon_color(d['color_name'])=='yellow' for d in vision['detections']):reason='target_reacquired_request_fresh_analysis'
        command=dict(self.command) if not reason else None
        if reason:self.close()
        return dict(arguments=command,decision='model_search_preview',reason=reason,
                    execution_allowed=False,sdk_called=False,human_confirmation='pending',segment_deadline_ms=self.deadline)
