"""Image-derived detections and timestamped model gate for offline feedback replay.

The color segmenter is deliberately restricted to the synthetic video domain.
It does not use simulator coordinates or the previously saved detection boxes.
"""
from __future__ import annotations

import math
import numpy as np
from uav_capabilities import canonical_balloon_color, validate_plan
from uav_feedback_preview import numbers, timestamp


def require_synchronized_pts(video_seconds, state_seconds):
    values = numbers([video_seconds, state_seconds], 2)
    if min(values) < 0 or abs(values[0]-values[1]) > .025:
        raise ValueError('video and telemetry PTS mismatch')


def component_boxes(mask, minimum_pixels=25):
    """4-connected components via row runs; retain separate same-color objects."""
    parent, runs, previous = [], [], []

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for y, row in enumerate(mask):
        edges = np.flatnonzero(np.diff(np.r_[False, row, False].astype(np.int8)))
        current = []
        j = 0
        for x1, x2 in zip(edges[::2], edges[1::2]):
            ident = len(parent)
            parent.append(ident)
            current.append((int(x1), int(x2), ident))
            runs.append((int(x1), y, int(x2), ident))
            while j < len(previous) and previous[j][1] <= x1:
                j += 1
            k = j
            while k < len(previous) and previous[k][0] < x2:
                parent[root(previous[k][2])] = root(ident)
                k += 1
        previous = current
    groups = {}
    for x1, y, x2, ident in runs:
        key = root(ident)
        if key not in groups:
            groups[key] = [x1, y, x2, y + 1, 0]
        b = groups[key]
        b[0], b[1], b[2], b[3] = min(b[0], x1), min(b[1], y), max(b[2], x2), max(b[3], y + 1)
        b[4] += x2 - x1
    return sorted((b for b in groups.values() if b[4] >= minimum_pixels), key=lambda b: (b[0], b[1]))


def detect_video_frame(image, timestamp_ms, frame_id):
    a = np.asarray(image.convert('RGB')).astype(np.float32)
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    masks = {'red': (r > 100) & (r > g * 1.7) & (r > b * 1.5),
             'green': (g > 95) & (g > r * 1.5) & (g > b * 1.3),
             'purple': (b > 100) & (r > 70) & (b > g * 1.6) & (r > g * 1.35) & (b > r * 1.1)}
    detections = []
    for color, mask in masks.items():
        for box in component_boxes(mask):
            detections.append({'class_name': 'balloon', 'color_name': color,
                               'bbox_xyxy': box[:4], 'pixel_area': box[4],
                               'confidence': 1.0, 'confidence_kind': 'synthetic_mask_acceptance_not_probability'})
    return {'ok': True, 'width': image.width, 'height': image.height,
            'target_timestamp_ms': timestamp(timestamp_ms), 'frame_id': frame_id,
            'detections': detections, 'source': 'decoded_video_color_components'}


def box_iou(a, b):
    inter = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0


def plan_colors(plan):
    actions = validate_plan(plan)['actions']
    if any(a['capability'] != 'strike_balloon' or a['parameters']['color'] == 'any' for a in actions):
        raise ValueError('explicit balloon color sequence required')
    return [canonical_balloon_color(a['parameters']['color']) for a in actions]


class ModelVisionGate:
    """Authorize a hypothetical preview only from a matched, fresh model image.

    This never grants real execution permission. A new revision invalidates the
    previous receipt; failed decisions cannot fall back to an old authorization.
    """
    def __init__(self, ttl_ms=2500):
        self.ttl_ms = timestamp(ttl_ms)
        self.receipt = None
        self.last_sequence = -1

    def clear(self):
        self.receipt = None

    def accept(self, decision, source_vision, *, frame_id, image_timestamp_ms,
               received_timestamp_ms, sequence, revision, plan, action_index):
        self.clear()
        try:
            if type(sequence) is not int or sequence <= self.last_sequence:
                return 'out_of_order_model_response'
            self.last_sequence = sequence
            sent, received = timestamp(image_timestamp_ms), timestamp(received_timestamp_ms)
            if not 0 <= received - sent <= self.ttl_ms:
                return 'stale_model_on_arrival'
            if source_vision['frame_id'] != frame_id or source_vision['target_timestamp_ms'] != sent:
                return 'model_source_frame_mismatch'
            expected = plan_colors(plan)
            if type(action_index) is not int or not 1 <= action_index <= len(expected):
                return 'invalid_action_index'
            if not isinstance(decision['plan'], list) or [canonical_balloon_color(c) for c in decision['plan']] != expected:
                return 'model_plan_mismatch'
            target = expected[action_index - 1]
            if canonical_balloon_color(decision['target']) != target:
                return 'model_target_out_of_order'
            if decision['mode'] != 'approach':
                return 'model_not_approaching'
            bbox = numbers(decision['bbox'], 4)
            if not all(0 <= n <= 1 for n in bbox) or not (bbox[0] < bbox[2] and bbox[1] < bbox[3]):
                return 'invalid_model_box'
            width, height = numbers([source_vision['width'], source_vision['height']], 2)
            box = [bbox[0] * width, bbox[1] * height, bbox[2] * width, bbox[3] * height]
            matches = [d for d in source_vision['detections'] if canonical_balloon_color(d['color_name']) == target]
            if len(matches) != 1 or box_iou(box, matches[0]['bbox_xyxy']) <= .2:
                return 'model_image_evidence_mismatch'
            self.receipt = dict(sequence=sequence, revision=revision, action_index=action_index,
                                target=target, image_timestamp_ms=sent, received_timestamp_ms=received,
                                frame_id=frame_id)
            return None
        except (KeyError, TypeError, ValueError, AttributeError):
            return 'invalid_model_response'

    def check(self, now_ms, revision, action_index, plan):
        if self.receipt is None:
            return 'no_valid_model_evidence'
        try:
            now = timestamp(now_ms)
            r = self.receipt
            if not 0 <= now - r['image_timestamp_ms'] <= self.ttl_ms or now < r['received_timestamp_ms']:
                return 'stale_model_evidence'
            if r['revision'] != revision or r['action_index'] != action_index:
                return 'model_revision_mismatch'
            if plan_colors(plan)[action_index - 1] != r['target']:
                return 'model_target_mismatch'
        except (TypeError, ValueError, IndexError):
            return 'invalid_model_context'
        return None


class GatedFeedbackPreview:
    """Reusable model-evidence gate + existing C feedback controller, offline only."""
    def __init__(self, library, plan, camera, revision, action_index=1):
        from uav_feedback_preview import FeedbackPreview
        self.plan, self.revision, self.action_index = plan, revision, action_index
        self.controller = FeedbackPreview(library, plan, camera, action_index)
        self.gate = ModelVisionGate()
        self.last_box = None

    def close(self):
        self.controller.close()
        self.gate.clear()

    def accept_model(self, decision, source_vision, **receipt):
        self.controller.reset_tracking()
        self.last_box = None
        return self.gate.accept(decision, source_vision, plan=self.plan,
                                revision=self.revision, action_index=self.action_index, **receipt)

    def step(self, frame):
        reason = self.gate.check(frame.get('now_ms'), self.revision, self.action_index, self.plan)
        if reason:
            self.controller.reset_tracking()
            return dict(decision='blocked', reason=reason, api=None, arguments=None,
                        execution_allowed=False, human_confirmation='pending', sdk_called=False,
                        completion=False, action_index=self.action_index)
        result = self.controller.step(frame)
        result['model_evidence'] = dict(self.gate.receipt)
        if result['decision'] == 'controller_preview':
            box = result['selected_detection']['bbox_xyxy']
            if self.last_box is not None:
                old = self.last_box
                width, height = self.controller.camera[:2]
                if (abs((box[0]+box[2]-old[0]-old[2])/2) > width*.25 or
                        abs((box[1]+box[3]-old[1]-old[3])/2) > height*.25):
                    result.update(decision='blocked', reason='target_discontinuity', api=None, arguments=None)
            self.last_box = list(box)
        if result['decision'] == 'blocked':
            self.controller.reset_tracking()
            self.gate.clear()
            self.last_box = None
        return result
