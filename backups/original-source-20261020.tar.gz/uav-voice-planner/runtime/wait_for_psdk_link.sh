#!/bin/sh
# Wait for the PSDK USB serial endpoint before starting dependent services.
# ttyACM creation precedes full USB enumeration, so a short settling delay is
# intentional and prevents intermittent startup failures after reconnects.
set -eu

device="${1:-/dev/ttyACM0}"
settle_seconds="${2:-2}"

while [ ! -c "$device" ]; do
    sleep 1
done

# Allow the remaining USB interfaces to finish enumeration after ttyACM appears.
sleep "$settle_seconds"
