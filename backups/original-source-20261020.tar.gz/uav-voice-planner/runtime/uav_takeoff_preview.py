"""API-authored takeoff/altitude search with local rejection only."""
import math
from uav_full_mission_preview import FullMissionPreview

class TakeoffPreview(FullMissionPreview):
    def __init__(self,*args):
        super().__init__(*args);self.vertical_search=False
    def close(self):
        super().close();self.vertical_search=False
    def accept_model(self,d,v,**receipt):
        if d.get('mode') not in ('takeoff','altitude_search'):
            return super().accept_model(d,v,**receipt)
        self.close()
        try:
            c=d['velocity'];duration=d['duration_s']
            if d['plan']!=self.literal_plan or d['target']!=self.target:raise ValueError('wrong active target')
            if set(c)!={'x','y','z','yaw'} or any(type(x) not in (int,float) or not math.isfinite(x) for x in c.values()):raise ValueError('invalid velocity')
            if c['x'] or c['y'] or abs(c['z'])>1 or abs(c['yaw'])>10:raise ValueError('vertical search bounds')
            if d['mode']=='takeoff' and (c['z']<=0 or c['yaw']):raise ValueError('takeoff requires positive vertical only')
            if type(duration) not in (int,float) or not math.isfinite(duration) or not .1<=duration<=3:raise ValueError('duration bounds')
            if v['frame_id']!=receipt['frame_id'] or v['target_timestamp_ms']!=receipt['image_timestamp_ms']:raise ValueError('source mismatch')
            if not 0<=receipt['received_timestamp_ms']-receipt['image_timestamp_ms']<=2500:raise ValueError('stale source')
            if receipt['sequence']<=self.gate.last_sequence:raise ValueError('stale sequence')
            self.gate.last_sequence=receipt['sequence']
        except (KeyError,TypeError,ValueError) as e:return str(e)
        self.vertical_search=True;self.command=dict(c);self.start=receipt['received_timestamp_ms']+50
        self.deadline=self.start+int(duration*20+1e-8)*50
        return None
    def step(self,f):
        s=f['aircraft'];v=f['vision'];t=f['now_ms'];c=self.command
        reason=None
        if c and (s['altitude_agl_m']>=11.5 and c['z']>0 or s['altitude_agl_m']<=3.5 and c['z']<0):reason='altitude_braking_margin'
        if not reason and not self.vertical_search:return super().step(f)
        if not reason:
            if not self.start<=t<self.deadline:reason='segment_expired'
            elif not 0<=t-s['timestamp_ms']<=100 or not 0<=t-v['target_timestamp_ms']<=100:reason='stale_feedback'
            elif not s['has_authority'] or not s['velocity_healthy']:reason='invalid_flight_state'
            elif s['altitude_agl_m']<3 and (c['z']<=0 or c['yaw']):reason='below_safe_search_height'
            elif not 0<=s['altitude_agl_m']<=12:reason='height_outside_envelope'
        if reason:self.close()
        return dict(arguments=None if reason else dict(c),reason=reason,execution_allowed=False,sdk_called=False,segment_deadline_ms=self.deadline)


def check_vertical_consistency(d):
    """Only model's own bbox is inspected; no local measurements or servo."""
    if d.get('mode')!='approach':return None
    box=d.get('bbox');c=d.get('velocity',{})
    if not isinstance(box,list) or len(box)!=4:return 'Approach requires your own valid bbox.'
    center=(box[1]+box[3])/2
    if abs(center-.5)>.18 and c.get('x',0)>0:
        return 'YOUR OWN bbox is vertically off-center. Do not advance. Choose altitude_search with x=y=0 and your own vertical speed/duration to center target first. Target above image center requires positive z; below requires negative z.'
    if abs(center-.5)>.08 and c.get('z',0)*(center-.5)>0:
        return 'Your vertical velocity moves away from YOUR OWN target bbox: above means climb, below means descend. Reanalyze.'
    return None
