"""Exact stationary-scene evidence for this synthetic hold-and-analyze loop.

This is intentionally stricter than a real camera matcher: any pixel or pose
change invalidates reuse. It does not alter normal model-evidence timeouts.
"""
import hashlib


class StationaryHoldEvidence:
    def __init__(self, image, pose, frame_id, timestamp_ms):
        self.original_hash=hashlib.sha256(image.tobytes()).hexdigest()
        self.original_pose=dict(pose)
        self.source_frame=frame_id
        self.source_timestamp=timestamp_ms
        self.latest_frame=frame_id
        self.latest_timestamp=timestamp_ms
        self.frames=0
        self.valid=True

    def observe(self,image,pose,frame_id,timestamp_ms,command):
        if frame_id<=self.latest_frame or timestamp_ms<=self.latest_timestamp:
            self.valid=False
        if dict(pose)!=self.original_pose or any(value!=0 for value in command.values()):
            self.valid=False
        if hashlib.sha256(image.tobytes()).hexdigest()!=self.original_hash:
            self.valid=False
        self.latest_frame=frame_id;self.latest_timestamp=timestamp_ms;self.frames+=1

    def receipt(self):
        if not self.valid or not self.frames:
            raise ValueError('stationary scene was not maintained; request fresh model analysis')
        return {'method':'exact_image_hash_and_pose_during_zero_command_hold',
                'original_model_source_frame':self.source_frame,
                'original_model_source_timestamp_ms':self.source_timestamp,
                'revalidated_frame':self.latest_frame,'revalidated_timestamp_ms':self.latest_timestamp,
                'new_camera_frames_during_hold':self.frames,'image_sha256':self.original_hash,
                'stationary_verified':True}
