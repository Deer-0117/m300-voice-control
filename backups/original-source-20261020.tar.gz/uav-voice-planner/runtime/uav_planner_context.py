"""Grounded plan previews and bounded, persistent conversation memory.

This module never sends flight commands or invokes a model.
"""
from __future__ import annotations

import contextlib
import fcntl
import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from uav_capabilities import (
    COLOR_GROUPS, PLAN_VERSION, CapabilityError, canonical_balloon_color, validate_plan,
)

MAX_TURNS = 6
SESSION_TTL_MS = 30 * 60 * 1000
GROUP_LABELS = {"pink": "粉组（粉/红/橙）", "yellow": "黄组（黄/绿）",
                "blue": "蓝组（蓝/紫）", "any": "任意颜色组"}


def normalize_model_plan(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict) or set(raw) - {"version", "actions"}:
        raise CapabilityError("model plan must contain only version and actions")
    if "version" in raw and (type(raw["version"]) is not int or raw["version"] != PLAN_VERSION):
        raise CapabilityError("unsupported plan version")
    plan = validate_plan(raw)
    for action in plan["actions"]:
        if action["capability"] != "strike_balloon":
            raise CapabilityError("model may only propose balloon strikes; stop remains local")
        action["parameters"]["color"] = canonical_balloon_color(action["parameters"]["color"])
    return plan


def plan_preview(plan: dict[str, Any]) -> dict[str, Any]:
    plan = normalize_model_plan(plan)
    steps = []
    for index, action in enumerate(plan["actions"], 1):
        label = GROUP_LABELS[action["parameters"]["color"]]
        steps.append({
            "index": index, "target": label,
            "executor_steps": [f"搜索{label}气球", "视觉确认并锁定目标", "跟踪并接近目标",
                               "由执行器依据视觉证据判定本阶段完成"],
        })
    return {
        "summary": " → ".join(step["target"] for step in steps),
        "steps": steps,
        "requires_operator_start": True,
        "note": "这是候选计划。确认后仍需 Prepare/Start；完成判定以执行器反馈为准。",
    }


def planner_instructions() -> str:
    knowledge = Path(__file__).with_name("uav_planner_knowledge.md").read_text(encoding="utf-8")
    return knowledge + "\n机器可读颜色映射：" + json.dumps(COLOR_GROUPS, ensure_ascii=False)


def model_input(command: str, history: list[dict[str, Any]], execution: dict[str, Any]) -> str:
    # User/history text is data inside a JSON envelope, never system instructions.
    return json.dumps({"command": command, "recent_turns": history[-MAX_TURNS:],
                       "execution_observation": execution}, ensure_ascii=False)


class ConversationStore:
    def __init__(self, root: Path):
        self.root = root

    @contextlib.contextmanager
    def lock(self):
        self.root.mkdir(parents=True, exist_ok=True)
        with (self.root / ".planner.lock").open("a") as stream:
            try:
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise CapabilityError("another planner request is in progress") from exc
            try:
                yield
            finally:
                fcntl.flock(stream, fcntl.LOCK_UN)

    def load(self, session_id: str | None, preview_only: bool) -> dict[str, Any]:
        now = time.time_ns() // 1_000_000
        if session_id is None:
            return {"session_id": uuid.uuid4().hex, "updated_ts_ms": now,
                    "preview_only": preview_only, "proposal_ids": []}
        if not isinstance(session_id, str) or not re.fullmatch(r"[0-9a-f]{32}", session_id):
            raise CapabilityError("invalid session_id")
        try:
            session = json.loads((self.root / "sessions" / f"{session_id}.json").read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise CapabilityError("session not found; start a new conversation") from exc
        if session.get("preview_only") is not preview_only:
            raise CapabilityError("offline and online sessions must not be mixed")
        if now - session["updated_ts_ms"] > SESSION_TTL_MS:
            raise CapabilityError("session expired; start a new conversation")
        return session

    def save(self, session: dict[str, Any]) -> None:
        session["updated_ts_ms"] = time.time_ns() // 1_000_000
        directory = self.root / "sessions"
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{session['session_id']}.json"
        temporary = path.with_suffix(f".{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_text(json.dumps(session, ensure_ascii=False, indent=2), encoding="utf-8")
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)
