"""Reduced-order M300-inspired plant, NOT manufacturer-calibrated dynamics.
Nominal parameters below are engineering assumptions, not DJI specifications.
"""
import math
from collections import deque
import numpy as np
from uav_static_world_sim import World, BALLOONS

PARAMETERS=dict(mass_kg=7.0,command_delay_s=.15,velocity_tau_s=.45,
                acceleration_limit_mps2=1.5,vertical_acceleration_limit_mps2=.8,
                yaw_tau_s=.3,yaw_acceleration_limit_deg_s2=30.,
                wind_mean_mps=[0.,3.,0.],wind_gust_mps=1.2,
                drag_coefficient_kg_per_m=.10,hold_position_gain=1.2,hold_integral_gain=.6)

class DynamicWorld(World):
    def __init__(self):
        super().__init__();self.t=0.;self.v=np.zeros(3);self.yr=0.
        self.queue=deque();self.applied=dict(x=0.,y=0.,z=0.,yaw=0.)
        self.anchor=np.array([self.x,self.y,self.z]);self.integral=np.zeros(3)
        self.holding=True;self.wind=np.zeros(3);self.accel=np.zeros(3)

    def flight_state(self):
        return dict(time_s=self.t,velocity_world_mps=self.v.tolist(),yaw_rate_deg_s=self.yr,
                    wind_world_mps=self.wind.tolist(),acceleration_world_mps2=self.accel.tolist(),
                    applied_delayed_command=dict(self.applied),hold_anchor=self.anchor.tolist(),
                    position_hold_active=self.holding)

    def integrate(self,command,dt):
        p=PARAMETERS
        self.queue.append((self.t+p['command_delay_s'],dict(command)))
        while self.queue and self.queue[0][0]<=self.t+1e-8:
            self.applied=self.queue.popleft()[1]
        c=self.applied;zero=not any(c.values())
        pos=np.array([self.x,self.y,self.z])
        if zero and not self.holding:
            self.anchor=pos.copy();self.integral=np.zeros(3)
        self.holding=zero
        self.wind=np.array([.5*math.sin(.7*self.t),3+1.2*math.sin(.9*self.t)+.4*math.sin(2.3*self.t),.15*math.sin(.5*self.t)])
        relative=self.wind-self.v
        wind_acc=p['drag_coefficient_kg_per_m']/p['mass_kg']*np.linalg.norm(relative)*relative
        if zero:
            error=self.anchor-pos
            self.integral=np.clip(self.integral+error*dt,-1.,1.)
            desired=p['hold_position_gain']*error
            feedback=(desired-self.v)/p['velocity_tau_s']+p['hold_integral_gain']*self.integral
        else:
            desired=np.array([c['x']*math.cos(self.yaw)-c['y']*math.sin(self.yaw),
                              c['x']*math.sin(self.yaw)+c['y']*math.cos(self.yaw),c['z']])
            feedback=(desired-self.v)/p['velocity_tau_s']
        horizontal=np.linalg.norm(feedback[:2])
        if horizontal>p['acceleration_limit_mps2']:feedback[:2]*=p['acceleration_limit_mps2']/horizontal
        feedback[2]=np.clip(feedback[2],-p['vertical_acceleration_limit_mps2'],p['vertical_acceleration_limit_mps2'])
        self.accel=feedback+wind_acc
        oldv=self.v.copy();self.v+=self.accel*dt
        pos+=(oldv+self.v)*dt/2
        oldyr=self.yr
        self.yr+=float(np.clip((c['yaw']-self.yr)/p['yaw_tau_s'],-30,30))*dt
        self.yaw+=math.radians((oldyr+self.yr)*dt/2)
        self.x,self.y,self.z=map(float,pos);self.t+=dt
        self.path.append((self.x,self.y));hits=[]
        for color,x,y,z in BALLOONS:
            if color not in self.contacts and math.dist((x,y,z),pos)<=.45:
                self.contacts.append(color);hits.append(color)
        return hits


class HoverEvidence:
    """Bounded drift evidence, not an exact pixel match or frozen simulation."""
    def __init__(self,image,pose,frame_id,timestamp_ms):
        self.pose=dict(pose);self.source_frame=frame_id;self.source_timestamp=timestamp_ms
        self.latest_frame=frame_id;self.latest_timestamp=timestamp_ms;self.frames=0
        self.valid=True;self.max_drift=0.;self.max_yaw=0.
    def observe(self,image,pose,frame_id,timestamp_ms,command):
        drift=math.dist([pose[k] for k in ('x','y','z')],[self.pose[k] for k in ('x','y','z')])
        yaw=abs(math.degrees(pose['yaw']-self.pose['yaw']))
        self.max_drift=max(self.max_drift,drift);self.max_yaw=max(self.max_yaw,yaw)
        if frame_id<=self.latest_frame or timestamp_ms<=self.latest_timestamp or any(command.values()) or drift>.12 or yaw>1.:
            self.valid=False
        self.latest_frame=frame_id;self.latest_timestamp=timestamp_ms;self.frames+=1
    def receipt(self):
        return dict(method='bounded_dynamic_hover_and_latest_visual_revalidation',
                    original_model_source_frame=self.source_frame,original_model_source_timestamp_ms=self.source_timestamp,
                    revalidated_frame=self.latest_frame,revalidated_timestamp_ms=self.latest_timestamp,
                    new_camera_frames_during_hold=self.frames,hover_verified=self.valid,
                    max_drift_m=self.max_drift,max_yaw_drift_deg=self.max_yaw)
