"""Portable locations for the local voice, planning and simulation workflow."""
from __future__ import annotations

import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def project_path(variable: str, default: str) -> Path:
    """Resolve relative configuration against the project, never the caller's cwd.

    Explicit absolute environment overrides remain supported for installations
    that intentionally keep models or state outside the checkout.
    """
    value = os.environ.get(variable, "").strip() or default
    path = Path(value).expanduser()
    return (path if path.is_absolute() else PROJECT_ROOT / path).resolve()


def chinese_font(size: int):
    """Use a project font or an installed font name without OS-specific paths."""
    from PIL import ImageFont

    configured = os.environ.get("UAV_FONT", "").strip()
    if configured:
        candidate = Path(configured).expanduser()
        if candidate.is_absolute() or len(candidate.parts) > 1:
            candidate = project_path("UAV_FONT", configured)
        return ImageFont.truetype(str(candidate), size)
    candidates = (
        PROJECT_ROOT / "assets/fonts/NotoSansCJK-Regular.ttc",
        "NotoSansCJK-Regular.ttc",
        "NotoSansSC-Regular.ttf",
        "STHeiti Medium.ttc",
        "Hiragino Sans GB.ttc",
        "msyh.ttc",
        "Arial Unicode.ttf",
    )
    for candidate in candidates:
        try:
            return ImageFont.truetype(str(candidate), size)
        except OSError:
            continue
    raise RuntimeError("未找到中文字体，请安装中文字体，或用 UAV_FONT 指定项目相对字体路径")
