"""Allowlisted nonvisual telemetry: never reads detections or target geometry."""
from uav_action_feedback import body_vector

def feedback(frames):
    groups=[]
    for f in frames:
        if f['preview'].get('arguments') is not None:
            if not groups or groups[-1][0]['model_call']!=f['model_call']:groups.append([])
            groups[-1].append(f)
    actions=[]
    for group in groups[-6:]:
        first=group[0];mean=[sum(f['plant_after']['velocity_world_mps'][i] for f in group)/len(group) for i in range(3)]
        actions.append(dict(sequence=first['model_call'],command=first['command'],executed_duration_s=len(group)*.05,
                            actual_mean_velocity_body_mps=body_vector(mean,first['pose_before']['yaw'])))
    f=frames[-1]
    return dict(actual_velocity_body_mps=body_vector(f['plant_after']['velocity_world_mps'],f['pose_after']['yaw']),
                actual_yaw_rate_deg_s=f['plant_after']['yaw_rate_deg_s'],recent_actions=actions)

def frame_metadata(sample):
    return {k:sample[k] for k in ('frame','sim_time_s','velocity')}
