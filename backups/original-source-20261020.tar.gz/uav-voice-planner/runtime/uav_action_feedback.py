"""Measured image/telemetry feedback for model decisions; never generates controls."""
import math


def body_vector(vector,yaw):
    x,y,z=vector
    return [math.cos(yaw)*x+math.sin(yaw)*y,-math.sin(yaw)*x+math.cos(yaw)*y,z]


def target_measurement(vision,target):
    found=[d for d in vision['detections'] if d['color_name']==target]
    if len(found)!=1:return {'target':target,'visible':False}
    x1,y1,x2,y2=found[0]['bbox_xyxy'];w,h=vision['width'],vision['height']
    u=(x1+x2)/2;v=(y1+y2)/2;focal=w/(2*math.tan(math.radians(73.7/2)))
    clipped=x1<=1 or y1<=1 or x2>=w-1 or y2>=h-1
    return dict(target=target,visible=True,center_normalized=[u/w,v/h],
                target_side='right' if u/w>.56 else ('left' if u/w<.44 else 'center'),
                horizontal_error_normalized=u/w-.5,vertical_error_normalized=.5-v/h,
                bearing_right_deg=math.degrees(math.atan((u-w/2)/focal)),
                bbox_xyxy=[x1,y1,x2,y2],clipped=clipped,
                estimated_depth_m=None if clipped else focal*.5/(x2-x1),
                depth_basis='known 0.5m balloon diameter, pinhole image width; estimate only')


def summarize_effects(frames,target,limit=6):
    """Recent commanded segments and subsequent braking/hover, in first-frame body axes."""
    groups=[]
    for i,f in enumerate(frames):
        if f['preview'].get('arguments') is not None:
            if not groups or groups[-1]['sequence']!=f['model_call']:
                groups.append(dict(sequence=f['model_call'],start=i,motion=[]))
            groups[-1]['motion'].append(i)
    result=[]
    for index,g in enumerate(groups):
        end=groups[index+1]['start']-1 if index+1<len(groups) else len(frames)-1
        first,last=frames[g['start']],frames[end]
        yaw=first['pose_before']['yaw']
        delta=[last['pose_after'][k]-first['pose_before'][k] for k in ('x','y','z')]
        motion=g['motion'];n=len(motion)
        means=[sum(frames[j]['plant_after']['velocity_world_mps'][axis] for j in motion)/n for axis in range(3)]
        command=first['command']
        segment_target='red' if not first['contacts_before'] else 'purple'
        result.append(dict(sequence=g['sequence'],target=segment_target,
            command=command,executed_duration_s=n*.05,total_observation_s=(end-g['start']+1)*.05,
            requested_displacement_body_m=[command[k]*n*.05 for k in ('x','y','z')],
            actual_mean_motion_velocity_body_mps=body_vector(means,yaw),
            actual_net_displacement_including_braking_hover_body_m=body_vector(delta,yaw),
            target_before=target_measurement(first['vision'],segment_target),
            target_after=target_measurement(last['vision'],segment_target),
            observation_frame_range=[g['start'],end],
            meaning='Requested displacement is velocity*time, not an expectation of instant tracking; net includes brake/hover drift.'))
    current=frames[-1]
    return dict(current_target=target_measurement(current['vision'],target) if target else None,
                actual_velocity_body_mps=body_vector(current['plant_after']['velocity_world_mps'],current['pose_after']['yaw']),
                wind_body_mps=body_vector(current['plant_after']['wind_world_mps'],current['pose_after']['yaw']),
                recent_action_effects=result[-limit:],
                provenance='image pixels and measured vehicle telemetry only; no world target coordinates')


FEEDBACK_PROMPT='''
Use measured_feedback as numeric visual/telemetry evidence, in addition to the current image. This contains ACTUAL velocity, recent model commands, executed duration, actual mean velocity while commanded, and net displacement INCLUDING the subsequent braking/hover. It is not a suggested command. You must choose all velocity and duration numbers.
The horizontal image error is center_x/width - 0.5. NEGATIVE means target LEFT, POSITIVE means target RIGHT. Use target_side to avoid reversing the sign. Do not call the target centered when abs(error)>0.06. Current target alignment takes priority over wind cancellation. Wind direction is NOT the direction of target error. If the target is RIGHT and measured net motion was LEFT and error increased, moving further left is WRONG: choose a motion toward the target, not blind wind compensation. Conversely left target with measured rightward drift requires leftward correction. A rightward wind can help reach a target on the right; it does NOT always require negative y. Compare target_before/target_after and actual net displacement to identify whether the previous correction helped. Use wind only as a secondary adjustment after establishing target direction. Do not repeat a correction that demonstrably increases target error.
Use history to recognize short pulses producing little net forward progress because of inertia and position-hold braking. When distant and reasonably aligned, choose longer segments (up to 1 second) and sufficient forward velocity within limits. Near target, reduce speed but avoid pulses so brief that the delayed plant barely responds. If bearing is large, prioritize lateral alignment over forward advance; as distance shrinks, correct error more assertively relative to forward speed. Depth is estimated from image diameter and invalid if clipped; never assume it is exact. Always inspect the new image rather than copying old boxes. Only contact telemetry proves success. Analyze briefly in reason: actual target error, last action effect, compensation change.
'''


def divergence_guard(decision,feedback):
    """Reject repeated observed divergence; never supplies replacement controls."""
    m=feedback.get('current_target')
    if not m or not m.get('visible'):return None
    error=m['horizontal_error_normalized']
    history=feedback['recent_action_effects']
    if abs(error)<=.08 or not history:return None
    last=history[-1];a,b=last['target_before'],last['target_after']
    if last['target']!=m['target'] or not a.get('visible') or not b.get('visible'):return None
    worsening=abs(b['horizontal_error_normalized'])-abs(a['horizontal_error_normalized'])>.015
    away=last['actual_net_displacement_including_braking_hover_body_m'][1]*error<0
    c=decision['velocity']
    if worsening and away and c['y']*error<0 and c['yaw']*error<=0:
        return 'observed_divergence: target is '+m['target_side']+'; previous net lateral motion increased error; proposed lateral direction repeats it. Reanalyze direction.'
    return None
