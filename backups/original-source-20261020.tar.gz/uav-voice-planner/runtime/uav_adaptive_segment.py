"""Simulation-only bounded adaptive segments with per-frame interruption."""
import math
from uav_revision_search import RevisionSearchPreview
from uav_model_velocity import validate_segment
from uav_action_feedback import target_measurement


def validate_adaptive(decision, maximum=3.):
    duration=decision['duration_s']
    if type(duration) not in (int,float) or not math.isfinite(duration) or not .1<=duration<=maximum<=3:
        raise ValueError('duration must be finite and within configured limit')
    mode=decision.get('mode')
    if decision.get('plan')!=['red','green'] or (mode!='done' and decision.get('target')!='green'):
        raise ValueError('target must remain green even during unseen search; null only for done')
    # Reuse numeric velocity validation, without changing the executed model duration.
    command,_=validate_segment({**decision,'duration_s':min(duration,1.),
                               'mode':'approach' if mode in ('search_left','search_right') else mode})
    if mode in ('search_left','search_right'):
        if any(command[k] for k in ('x','y','z')) or (command['yaw']<=0 if mode=='search_right' else command['yaw']>=0):
            raise ValueError('search requires pure rotation in declared direction')
    return command,duration


class AdaptiveSegmentPreview(RevisionSearchPreview):
    def __init__(self,plan,action_index,maximum=3.):
        super().__init__(plan,action_index);self.maximum=maximum
        self.gate.ttl_ms=3500;self.initial_error=0.;self.bad_frames=0

    def accept_model(self,decision,source_vision,**receipt):
        self.close()
        try:command,duration=validate_adaptive(decision,self.maximum)
        except (KeyError,ValueError,TypeError) as e:return str(e)
        # Source receipt is fresh on arrival even for longer motion segments.
        if not 0<=receipt['received_timestamp_ms']-receipt['image_timestamp_ms']<=2500:return 'stale_model_on_arrival'
        error=super().accept_model({**decision,'duration_s':min(duration,1.)},source_vision,**receipt)
        if error:return error
        self.command=command;self.deadline=self.start+int(math.floor(duration*20+1e-8))*50
        m=target_measurement(source_vision,'green');self.initial_error=abs(m.get('horizontal_error_normalized',0.));self.bad_frames=0
        return None

    def step(self,frame):
        if frame.get('voice_interrupt'):
            self.close()
            return dict(arguments=None,reason='voice_interrupt',execution_allowed=False,sdk_called=False)
        result=super().step(frame)
        if result['arguments'] is not None and not self.search:
            m=target_measurement(frame['vision'],'green')
            worse=m.get('visible') and abs(m['horizontal_error_normalized'])>max(.25,self.initial_error+.15)
            self.bad_frames=self.bad_frames+1 if worse else 0
            if self.bad_frames>=3:
                self.close();result.update(arguments=None,reason='visual_error_increased',decision='blocked')
        return result
