# 无人机气球搜索、跟踪与多阶段撞击控制

> 本工作分支新增：三组颜色语音规划、会话上下文和离线预览。在线模型调用默认关闭，使用方法与验证范围见 [语音规划说明](docs/VOICE_PLANNER_CONTEXT.md)。

> **最终交付口径（2026-07-30）：** 成品能力、最终参数、运行逻辑和恢复方法以 [`docs/FINAL_PROJECT_HANDOFF.md`](docs/FINAL_PROJECT_HANDOFF.md) 与 [`docs/CONFIGURATION_REFERENCE.md`](docs/CONFIGURATION_REFERENCE.md) 为准。本文后部保留的试飞和调参内容用于追溯，不能覆盖最终交付文档。

本仓库保存中国科大 2026 暑期 UAV 项目中已经修改并部署过的关键飞行控制源码，以及安全同步、构建和部署说明。当前版本的目标是：检测到气球后，无人机持续朝气球方向移动；不依赖气球的真实三维位置。

> **安全红线：** 静态调试、日志分析、桌面测试和首次部署前，必须确认 systemd 的最终有效环境中出现 `BALLOON_NO_FLIGHT=1`。不能只看源码变量或某一个配置文件。`no_flight=1` 会跳过真实控制权申请和真实摇杆指令。

> **云台提示：** `BALLOON_NO_FLIGHT=1` 只禁止飞控摇杆动作，不会禁止云台转动。启动识别前仍需确认云台周围无遮挡、线缆不会受拉扯。

## 最终交付状态

- 项目已完成最终飞行功能、回归测试、Git 归档和本地完整备份。
- 最终实飞链路已完成多阶段目标搜索、跟踪、撞击、阶段切换和任务结束验证。
- 独立“粉色后黄色”测试脚本与遥控器按钮保留，可不经过语音识别或大模型单独反复运行。
- 语音/自然语言入口仍保留，并与测试入口共享受限能力库和飞行执行器；测试按钮不会禁用语音功能。
- 颜色按三组执行：黄/绿归黄组，粉/红/橙归粉组，蓝/紫归蓝组。
- 远距检测使用全帧与六块高分辨率切片；搜索使用云台栅格与机身重叠扇区，循环覆盖 360°。
- 最终归档不把密码、API Key、模型权重和未脱敏日志提交 Git；这些材料只进入受控本地备份。

正式接手应先阅读：

1. [`docs/FINAL_PROJECT_HANDOFF.md`](docs/FINAL_PROJECT_HANDOFF.md)：完整成品说明、状态机、目录、操作、日志和恢复。
2. [`docs/CONFIGURATION_REFERENCE.md`](docs/CONFIGURATION_REFERENCE.md)：最终环境变量、覆盖规则和改参验证要求。
3. [`docs/DEVELOPMENT_AND_DEPLOYMENT.md`](docs/DEVELOPMENT_AND_DEPLOYMENT.md)：构建、部署和设备验收。

## 历史开发与验收记录

以下条目按开发过程保留，包含当时尚未实飞或使用旧参数的阶段性结论。它们用于追溯，不是最终部署清单；最终状态见本文开头和最终交付主文档。

- 已完成：根据检测结果的实时 `width/height` 更新相机几何参数。
- 已完成：目标新鲜时边转向边前进，前进速度随水平偏角余弦衰减，最低为设定速度的 35%。
- 已完成：视觉框使用 alpha-beta 运动估计和延迟预测；短时丢检窗口内按预测状态刷新命令，超时后悬停并扩大云台搜索范围。
- 已完成：云台采用高带宽视觉内环（误差反馈加角速度前馈），机身采用低带宽有限时域约束预测外环；外环同时惩罚画面误差、云台偏中、距离代理误差、加速度和偏航速度。
- 已完成：机身不再和云台同时追逐每个像素误差。云台偏航超过 12°才触发机身回中，回到 4°内才退出，使用滞回避免抢控制权和反复切换。
- 已完成：控制循环 20 Hz，并保留水平、垂直、偏航、加速度和云台机械软限位；检测框角尺寸作为距离代理，接近时自动减速。
- 已完成：搜索采用两行云台栅格；每轮完成后机身转向相邻重叠扇区，循环覆盖 360°。该功能已部署并纳入最终实飞链路，设计说明见 `docs/360_DEGREE_SEARCH.md`。
- 已完成：目标超时默认 400 ms；最后一次真实 YOLO 时间戳不会被跟踪帧刷新。
- 已完成：预测、回中滞回、安装偏角符号、接近加速度约束和多目标跳过/回访离线测试。
- 未完成：云台跟踪代码尚未在实际设备上验证角度符号、挂载位置和机械限位。
- 未完成：修改后的版本尚缺一次完整真实飞行闭环日志验证。
- 已完成：设备端 YOLO worker、实时解码脚本和三个 systemd 服务单元已同步并完成敏感信息检查。
- 已完成：控制入口目标最大可接受年龄默认收紧为 400 ms，并支持 200–10000 ms 的受限环境变量配置；800 ms 仅保留在首次实飞保守覆盖中。
- 已完成：原机首次实飞保守配置已设为 `BALLOON_APPROACH_SPEED_MPS=0.5`、`BALLOON_TARGET_TIMEOUT_MS=800`；独立 drop-in 见 `systemd/psdk-balloon-first-flight-slow.conf`。
- 已完成：空中目标垂直速度改为与前进速度按目标视线斜率耦合（`z/x=tan(垂直角)`），并在原机禁飞模式完成边界测试、全工程构建和部署；仍待真实飞行验证。
- 当前状态：2026-07-24 只读复核时，`code10` 最终 systemd 环境仍为 `BALLOON_NO_FLIGHT=0`，采用0.5 m/s前进上限、0.3 m/s垂直上限、400 ms目标超时和5分钟任务上限；服务当时停在 `activating/start-pre`、`MainPID=0`，因此没有运行进程环境可读。实飞结束后必须撤下实飞覆盖并同时核验 systemd 与运行进程恢复为 `BALLOON_NO_FLIGHT=1`。
- 已完成：垂直死区由 3°缩小为 1°；目标在视线下方超过 1°时产生负 `z_mps`，仍保持 `z/x=tan(垂直角)`、±0.3 m/s限速和起始高度±3 m边界。
- 已完成：停止请求不再从两个线程并发调用 DJI 释放控制权；控制线程在最多一个 50 ms 周期内统一发送零速度并释放。
- 已完成：任务结束时不注销 DJI Pilot Widget；八个 Widget 处理项在执行后恢复为松开状态，停止后界面可继续用于下一轮 `Prepare/Start/Stop`。新增主界面与配置界面的“联网”按钮，以异步 TCP 探测开发板 `192.168.168.222:22`，分别显示连接成功、连接失败或连接异常。
- 已完成：一号有云台无人机 `code10` 新增首个参数化能力 `strike_balloon(color)`，`color` 可为 red、orange、yellow、green、blue、purple、pink 或 `any`。本地安全停止仍独立保留。其他飞行动作尚未进入能力库，提交会被拒绝；计划不接受速度、高度、姿态或摇杆值。
- 已完成：原有气球撞击测试的目标选择已改为调用 `strike_balloon(color=any)`，不再绕过能力库直接选目标；具体颜色顺序、任意颜色选择和粉色合成图像已在禁飞模式测试。该结果不等于真实飞行验证。
- 已完成：`code12` 新增经中继服务器 `10.18.2.83` 的持久化 HTTP/HTTPS 出口。中继器 tinyproxy 只监听 `127.0.0.1:18888`，`code12` 通过受限SSH密钥转发到本地 `127.0.0.1:18080`；通用 HTTPS 返回 200，DeepSeek 返回未带密钥时预期的 401。
- 已完成：`code12` 启动时及每10分钟通过只能执行 `date` 的专用中继密钥校时，解决设备RTC错误导致的TLS证书验证失败。
- 已完成：`code12` 已在隔离虚拟环境中部署 Microsoft Agent Framework（`agent-framework-core 1.12.0`、`agent-framework-openai 1.10.2`）和 `uav-microsoft-agent.service`。Agent 只生成 `strike_balloon(color)` 声明式计划，不能提供速度、高度、姿态或摇杆值；解释与提交分成两个带令牌步骤。
- 已完成：同一限权 Agent 也已部署到一号有云台无人机 `code10`，监听 `192.168.168.155:8770`，默认国产模型端点为 DeepSeek `https://api.deepseek.com`、模型 `deepseek-v4-flash`。code10 通过两级受限 SSH 隧道使用 code12 的公网代理：`code10 127.0.0.1:18080 → code12 127.0.0.1:18080 → 中继器 tinyproxy`。
- 已完成：code10 使用第二把只能读取 code12 UTC 时间的密钥，在开机后和每10分钟校时；代理密钥只能转发到 code12 回环端口 18080，尝试转发到其他端口会被拒绝。设备离场时隧道等待重连属于预期状态。
- 已验证：Agent Framework 的本地模拟模型工具调用全链路通过；服务健康检查正常，未鉴权返回 401。code10 已配置 DeepSeek API Key，健康检查显示密钥已加载；经 code12 中继出口的最小真实请求通过鉴权，但供应商返回 HTTP 402 `Insufficient Balance`，充值或获得赠送余额前不能完成真实模型回复。code12 自身 Agent 仍未持久化该供应商 Key。
- 现场验收项：`code12 (192.168.168.222)` 与一号无人机 `code10 (192.168.168.155)` 只在试飞场地建立无线链路，当前异地不通属于正常状态。到场后验证 code10 代理隧道、自动校时和真实模型请求；不得据此判断中继公网链路故障。
- 台架临时路径：异地维护时可用 `scripts/pc-relay-http-proxy.py` 在维护电脑 `192.168.55.2:18889` 暴露受限中继代理，并通过 `uav-microsoft-agent-pc-relay.conf` 与 `psdk-balloon-pc-asr.conf` 分别接通 Agent 和 code12 ASR。该路径仅用于 USB 台架，到试飞场地前必须移除相应 drop-in，恢复 code12 正常链路。

## 一号有云台无人机曝光策略

最终成品直接使用 DJI 相机/固件自身的自动曝光，不由本项目主动切换或维护曝光模式，也不对 YOLO 输入执行软件伽马补偿。

最终环境必须满足：

```text
BALLOON_AUTO_EXPOSURE=0
BALLOON_SOFTWARE_AUTO_EXPOSURE=0
```

`systemd/psdk-balloon-auto-exposure.conf` 和 `systemd/balloon-yolo-auto-exposure.conf` 现为显式关闭配置，用于覆盖历史设备中可能残留的启用值。相机自身的自动曝光不受这两个项目变量控制。

## 仓库内容

```text
src/target_chase/       方向控制算法和 DJI 飞控适配
src/balloon_widget/     检测结果、实时视频与控制循环衔接
runtime/                设备端 YOLO worker、实时解码器和单图检测入口
systemd/                三个设备服务的可复现 systemd 单元
network/                中继器回环代理配置
scripts/                安全检查和部署脚本
docs/                   架构、环境与交接说明
flight-data/            已脱敏的飞行日志、检测记录和 Git LFS 照片
说明/                   每个程序的 TXT 说明和总目录
```

`docs/FINAL_PROJECT_HANDOFF.md` 是最终交付主目录；`docs/CONFIGURATION_REFERENCE.md` 集中解释所有关键运行参数。`说明/` 保留按源文件逐项查阅的中文材料。

本仓库是 DJI PSDK 工程的“源码覆盖层”，不包含 DJI 官方 SDK、模型权重、账号密码或未脱敏运行数据。`flight-data/`只保存经过审查的脱敏飞行记录。完整 SDK、模型、虚拟环境和敏感配置保存在本地受控设备快照中。

## 快速开始

1. Windows 维护电脑安装 Git、PowerShell 7（Windows PowerShell 5.1 也可）和 OpenSSH 客户端。
2. 维护电脑与无人机接入同一网络，确认能够执行 `ssh uav@192.168.55.1`。
3. 在无人机上执行 `scripts/enable-no-flight.sh`，并确认输出同时包含 `ActiveState=active` 和 `BALLOON_NO_FLIGHT=1`。
4. 在仓库根目录执行 `scripts/deploy-runtime.ps1` 和 `scripts/deploy.ps1`，先不加 `-Apply` 查看两个计划。
5. 确认桨叶拆除或无人机处于空旷安全区后，先执行 `scripts/deploy-runtime.ps1 -Apply`，再执行 `scripts/deploy.ps1 -Apply`。首次安装服务单元时给前一条命令增加 `-InstallServices`。
6. 部署后再次读取 systemd 最终 Environment，并在 `no_flight=1` 下确认三个服务均为 active，再验证 dry-run 日志。

云台目标跟踪默认启用；如需暂时回退到固定相机行为，可通过 systemd 环境设置 `BALLOON_GIMBAL_TRACKING=0`。

能力库地面测试顺序：先在 DJI Pilot 按 `Prepare`，再执行 `scripts/send-natural-command.ps1 -Command '撞击任意颜色气球'`，确认返回 `strike_balloon` 且 `color=any` 后才按 `Start`。指定颜色可用“先撞粉色气球，再撞绿色气球”。“停下”可随时发送且完全在本地处理。当前一号机专用 SSH 别名为 `uav-one-gimbal`；脚本会同时核验远端主机名为 `code10` 和最终有效环境含 `BALLOON_NO_FLIGHT=1`。

完整环境、文件映射、构建步骤和验收项见 [docs/DEVELOPMENT_AND_DEPLOYMENT.md](docs/DEVELOPMENT_AND_DEPLOYMENT.md)。

同一台 Windows 维护电脑通过多个 USB 口并行连接多架地址均为 `192.168.55.1` 的无人机时，必须使用源地址绑定和设备专用 SSH 别名；操作步骤见 [docs/多无人机USB并行连接操作说明.md](docs/多无人机USB并行连接操作说明.md)。

## 协作规则

- 禁止提交设备密码、Git token、DJI 应用密钥、模型权重和未经脱敏的飞行日志。
- 修改飞控逻辑必须先在 `BALLOON_NO_FLIGHT=1` 下完成离线/静态验证。
- 每次修改使用独立分支，通过 Merge Request 合并；提交信息说明改动、测试方法和安全影响。
- 不要把“编译通过”写成“真实飞行验证通过”。两种状态必须分开记录。
