#!/usr/bin/env python3
"""Offline fixtures exercise plan/context plumbing, not model intelligence."""
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "runtime"))
import uav_microsoft_agent as planner


def fixture(*colors):
    return {"version": 2, "actions": [
        {"capability": "strike_balloon", "parameters": {"color": color}} for color in colors
    ]}


def main():
    with tempfile.TemporaryDirectory(prefix="uav-planner-demo-") as directory:
        planner.STATE_ROOT = Path(directory)
        planner.PLAN_DIR = planner.STATE_ROOT / "plans"
        planner.EVENT_LOG = planner.STATE_ROOT / "events.jsonl"
        first = planner.interpret_command("先撞红色气球，再撞绿色气球", offline_plan=fixture("red", "green"))
        second = planner.interpret_command("把第二个改成紫色", first["session_id"], fixture("pink", "purple"))
        try:
            planner.submit_proposal(second["proposal_id"])
        except planner.AgentError as exc:
            submission = str(exc)
        else:
            raise AssertionError("offline preview was allowed to submit")
        print(json.dumps({
            "mode": "离线固定响应演示：未调用模型、ASR 或无人机",
            "first_candidate": first["preview"],
            "second_candidate": second["preview"],
            "second_request_context": second["model_input"],
            "submission_blocked": submission,
        }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
