#!/usr/bin/env python3
"""Audit prefix replay, interruption, actual confirmation, and revised controls."""
import hashlib,json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
from uav_dynamic_world import DynamicWorld,PARAMETERS
from uav_static_world_sim import BALLOONS

def verify(path):
    r=json.loads(path.read_text());basepath=Path(r['prefix_record']);base=json.loads(basepath.read_text())
    assert hashlib.sha256(basepath.read_bytes()).hexdigest()==r['prefix_sha256']
    assert r['dynamics_parameters']==base['dynamics_parameters']==PARAMETERS
    assert r['world_balloons']==base['world_balloons']==[list(b) for b in BALLOONS]
    assert r['source_hashes']['runtime/uav_dynamic_world.py']==base['source_hashes']['runtime/uav_dynamic_world.py']
    assert r['live_visual_call_budget']==100
    memory=json.loads((path.parent/'visual-memory.json').read_text())
    assert memory and all(m['frame_index']<r['prefix_frames'] for m in memory)
    assert r['sdk_calls']==0 and not r['real_execution_allowed']
    events={e['kind']:e for e in r['events']}
    trigger=events['voice_interrupt']['frame'];stable=events['hover_stable']['frame']
    ready=events['candidate_ready']['frame'];confirm=events.get('human_confirmed')
    assert trigger==r['prefix_frames'] and events['voice_interrupt']['old_segment_remaining_ms']>0
    assert trigger<stable<=ready
    w=DynamicWorld();contacts=[];contact_events=[];revised=0;search=0;wait_frames=0;old_queue_last=None
    for i,f in enumerate(r['frames']):
        assert f['frame_index']==i and f['vision']['frame_id']==i and f['vision']['target_timestamp_ms']==10000+i*50
        assert w.flight_state()==f['plant_before']
        c=f['command']
        if i<trigger:assert c==base['frames'][i]['command']
        elif confirm is None or i<confirm['frame']:
            assert not any(c.values());wait_frames+=1
        if f['issued_revision'] is not None and f['issued_revision']!=f['mission_revision']:assert not any(c.values())
        if f['phase']=='revised_motion' and f['preview']['arguments'] is not None:
            assert confirm is not None and i>=confirm['frame'] and f['issued_revision']==2 and f['mission_status']=='active'
            call=r['calls'][f['model_call']-1]
            assert call['revision']==2 and call['response']['plan']==['red','green'] and call['response']['target']=='green'
            assert call['response_id'] and call['historical_images']
            assert c==call['response']['velocity']==f['preview']['arguments'];revised+=1
            if call['response']['mode'].startswith('search'):
                assert not any(c[k] for k in ('x','y','z'));search+=1
        assert math.hypot(c['x'],c['y'])<=2.000001 and abs(c['z'])<=.3 and abs(c['yaw'])<=10
        hits=w.integrate(c,.05);assert hits==f['contacts_this_frame'] and w.flight_state()==f['plant_after']
        assert all(abs(getattr(w,k)-v)<1e-10 for k,v in f['pose_after'].items())
        if trigger<=i<stable and any(w.applied.values()):old_queue_last=i
        if hits:contact_events.append({'time_s':(i+1)/20,'colors':hits})
    assert w.contacts==r['contacts'] and 'purple' not in w.contacts
    assert old_queue_last is None or old_queue_last-trigger<=3
    if confirm:
        receipt=json.loads((path.parent/'confirmation.json').read_text());request=json.loads((path.parent/'confirmation-request.json').read_text())
        assert receipt['decision']=='confirm' and all(receipt[k]==request[k] for k in ('revision','plan_hash','token'))
        assert events['late_old_response_rejected']['frame']>confirm['frame']
    root=Path(__file__).resolve().parents[1]
    assert all(hashlib.sha256((root/s).read_bytes()).hexdigest()==v for s,v in r['source_hashes'].items())
    result=dict(verified=True,completed=r['completed'],contacts=contact_events,interrupted_at_s=trigger/20,
        stable_at_s=stable/20,confirmation_frame=confirm['frame'] if confirm else None,
        new_visual_api_calls=len(r['calls']),preconfirmation_zero_command_frames=wait_frames,
        revised_model_motion_frames=revised,pure_rotation_search_frames=search,
        old_commands_invalidated=True,old_delay_preserved_s=PARAMETERS['command_delay_s'],
        same_dynamics=True,continuous_camera=True,sdk_calls=0)
    (path.parent/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':verify(Path(sys.argv[1]))
