#!/usr/bin/env python3
"""Render two saved real-DeepSeek candidates into local PSDK call previews."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'runtime'))
from uav_dji_preview import render_preview, render_c


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=ROOT / 'local-planner-test/two-turn-result.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'local-planner-test/dji-preview')
    args = parser.parse_args()
    source = json.loads(args.input.read_text())
    previews = []
    for key in ('first', 'second'):
        preview = render_preview(source[key]['plan'])
        preview.update(source_report=str(args.input.resolve()), source_turn=key,
                       command=source[key]['command'], historical_comparison_only=(key == 'first'))
        previews.append((key, preview))
    args.output.mkdir(parents=True, exist_ok=True)
    for key, preview in previews:
        (args.output / f'{key}.json').write_text(json.dumps(preview, ensure_ascii=False, indent=2) + '\n')
        (args.output / f'{key}.preview.c').write_text(render_c(preview))
        print(f"{key}: {preview['command']} | {len(preview['events'])} local records | pending confirmation | no SDK calls")
    print(args.output.resolve())


if __name__ == '__main__':
    main()
