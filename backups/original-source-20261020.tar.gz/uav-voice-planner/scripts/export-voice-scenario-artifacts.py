#!/usr/bin/env python3
"""Offline exports of recorded simulator video and saved API traffic. No API calls."""
import base64,hashlib,html,json,shutil,subprocess,sys,zipfile
from pathlib import Path

def export(path):
    r=json.loads((path/'result.json').read_text());ledger=r['api_calls'];out=path/'api-transcript'
    for folder in ('images','requests','responses'): (out/folder).mkdir(parents=True,exist_ok=True)
    images={hashlib.sha256(p.read_bytes()).hexdigest():p for pattern in ('input-*.png','temporal-*.png','memory-*.png') for p in path.glob(pattern)}
    sections=[]
    esc=lambda x:html.escape(str(x))
    for row in ledger:
        n=row['number'];messages=json.loads((path/f'outbound-api-{n:03d}.json').read_text());display=[]
        for m in messages:
            parts=m['content'] if isinstance(m['content'],list) else [{'type':'text','text':m['content']}];bits=[]
            for part in parts:
                if part['type']=='text':bits.append('<pre>'+esc(part['text'])+'</pre>')
                else:
                    sha=part['image_url']['sha256'];p=images[sha];dest=out/'images'/(sha+'.png')
                    if not dest.exists():shutil.copy2(p,dest)
                    bits.append(f'<img loading="lazy" src="images/{sha}.png" alt="API 实际输入画面"><small>{esc(p.name)}</small>')
                    part['image_url']={'url':'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()}
            display.append('<details><summary>'+esc(m['role'])+'</summary>'+''.join(bits)+'</details>')
        req=dict(model=row.get('model'),messages=messages,response_format={'type':'json_object'},max_tokens=1800,temperature=0,thinking={'type':'disabled'})
        (out/'requests'/f'{n:03d}.json').write_text(json.dumps(req,ensure_ascii=False,indent=2))
        rawpath=path/f'raw-api-{n:03d}.json'
        raw=json.loads(rawpath.read_text()) if rawpath.exists() else {'error':row.get('error_type')}
        (out/'responses'/f'{n:03d}.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2))
        envelope=path/f'api-response-envelope-{n:03d}.json'
        if envelope.exists():shutil.copy2(envelope,out/'responses'/f'{n:03d}-envelope.json')
        sections.append(f'<section><h2>#{n} · {esc(row["kind"])}</h2><p>{esc(row.get("response_id",""))}</p><a href="requests/{n:03d}.json">请求 JSON</a> · <a href="responses/{n:03d}.json">返回正文</a>'+''.join(display)+'<h3>API 返回</h3><pre>'+esc(raw.get('content',raw))+'</pre></section>')
    (out/'index.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>场景 '+r['scenario']+' API 明细</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:30px auto;padding:20px;background:#f3f6f9}section{background:white;padding:18px;margin:20px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere}img{display:block;max-width:680px;width:100%}summary{cursor:pointer}</style><h1>场景 '+r['scenario']+' · '+str(len(ledger))+' 次真实 API 调用</h1><p>请求体由运行时保存的消息和原始图片重建。返回正文和 SDK 响应对象原样保存，不含密钥、请求头和人工确认凭据。</p>'+''.join(sections)+'</html>')
    with zipfile.ZipFile(path/'api-transcript.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in out.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(path))
    duration=len(r['frames'])/20
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(path/'closed-loop.mp4'),'-i',str(path/'initial.wav')]
    interrupt=next((e for e in r['events'] if e['kind']=='voice_interrupt'),None)
    if interrupt and (path/'revision.wav').exists():
        cmd+=['-i',str(path/'revision.wav')];filters=f'[1:a]adelay=0:all=1[a0];[2:a]adelay={round(interrupt["time_s"]*1000)}:all=1[a1];[a0][a1]amix=inputs=2:normalize=0,apad[a]'
    else:filters='[1:a]apad[a]'
    cmd+=['-filter_complex',filters,'-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-t',str(duration),'-movflags','+faststart',str(path/'mission-with-speech.mp4')]
    subprocess.run(cmd,check=True)
    print(json.dumps(dict(scenario=r['scenario'],video=str(path/'mission-with-speech.mp4'),api_requests=len(ledger),completed=r['completed']),ensure_ascii=False))
if __name__=='__main__':export(Path(sys.argv[1]).resolve())
