#!/usr/bin/env python3
"""Re-render recorded vision/API simulation without any network request."""
import json
from pathlib import Path
import runpy
import subprocess
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
helpers=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'))
World,compose,OUT,FPS=(helpers[k] for k in ('World','compose','OUT','FPS'))
r=json.loads((OUT/'result.json').read_text())
w=World();shots=[]
p=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(FPS),'-i','-','-an','-c:v','libx264','-crf','20','-preset','fast','-pix_fmt','yuv420p','-movflags','+faststart',str(OUT/'closed-loop.mp4')],stdin=subprocess.PIPE)
try:
 for i,f in enumerate(r['frames']):
  for k,v in f['pose_before'].items():setattr(w,k,v)
  w.path.append((w.x,w.y))
  d=r['calls'][f['model_call']-1]['response']
  im=compose(w,w.render(),f['pixel_boxes'],d,f['command'],f['sim_time_s'],f['model_call'],f['gate'],f['sim_time_s']>=2)
  p.stdin.write(im.tobytes())
  w.contacts.extend(f['contacts_this_frame'])
  if i==100:im.save(OUT/'poster.png')
  if i in (0,40,100,150,200,280):shots.append(im.resize((640,360)))
finally:
 p.stdin.close()
 if p.wait()!=0:raise RuntimeError('encoding failed')
sheet=Image.new('RGB',(1280,1080),'#09131F')
for i,im in enumerate(shots):sheet.paste(im,((i%2)*640,(i//2)*360))
sheet.save(OUT/'contact-sheet.jpg')
print(OUT/'closed-loop.mp4')
