#!/usr/bin/env python3
"""Synthetic audio -> real local whisper.cpp HTTP ASR -> real DeepSeek proposals.

No confirmation, submission, aircraft status request, or flight action occurs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import secrets
import subprocess
import sys
import threading
import time
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
import uav_microsoft_agent as planner
import uav_voice_asr_service as asr
import uav_voice_command as voice

TEXTS = ("先撞红色气球，再撞绿色气球", "把第二个改成紫色")


class QuietAsrHandler(asr.AsrHandler):
    def log_message(self, *_args):
        pass


def synthesize(text: str, prefix: Path, tts_voice: str):
    subprocess.run(["say", "-v", tts_voice, "-r", "165", "-o", str(prefix.with_suffix(".aiff")), text],
                   check=True, capture_output=True, timeout=60)
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", str(prefix.with_suffix(".aiff")),
                    "-ar", "16000", "-ac", "1", "-f", "s16le", str(prefix.with_suffix(".pcm"))],
                   check=True, capture_output=True, timeout=30)
    prefix.with_suffix(".wav").write_bytes(voice.pcm_to_wav(prefix.with_suffix(".pcm")))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=ROOT / "local-asr/whisper.cpp/models/ggml-base.bin")
    parser.add_argument("--voice", default="Tingting")
    args = parser.parse_args()
    cli = ROOT / "local-asr/whisper.cpp/build/bin/whisper-cli"
    if not cli.is_file() or not args.model.is_file():
        raise ValueError("请先安装本地 whisper.cpp 与多语言模型")
    configuration = runpy.run_path(str(ROOT / "scripts/test-deepseek-candidates.py"))
    configuration["load_configuration"]()
    output = ROOT / "local-voice-test" / time.strftime("%Y%m%d-%H%M%S")
    output.mkdir(parents=True, exist_ok=False)
    planner.STATE_ROOT = output / "planner"
    planner.PLAN_DIR = planner.STATE_ROOT / "plans"
    planner.EVENT_LOG = planner.STATE_ROOT / "events.jsonl"
    server = ThreadingHTTPServer(("127.0.0.1", 0), QuietAsrHandler)
    endpoint = f"http://127.0.0.1:{server.server_port}/transcribe"
    environment = {
        "UAV_WHISPER_CLI": str(cli), "UAV_WHISPER_MODEL": str(args.model.resolve()),
        "UAV_VOICE_ASR_STATE_DIR": str(output / "asr-state"),
        "UAV_VOICE_ASR_ENDPOINT": endpoint, "UAV_VOICE_ASR_FALLBACK_ENDPOINT": endpoint,
        "UAV_VOICE_ASR_TOKEN": secrets.token_urlsafe(32),
        "NO_PROXY": os.environ.get("NO_PROXY", "") + ",127.0.0.1,localhost",
    }
    records = []
    session_id = None
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    with patch.dict(os.environ, environment), \
            patch.object(planner, "executor_observation", side_effect=AssertionError("aircraft access forbidden")), \
            patch.object(planner, "submit_proposal", side_effect=AssertionError("submission forbidden")), \
            patch.object(voice, "confirm", side_effect=AssertionError("human confirmation not performed")), \
            patch.object(voice, "store_plan", side_effect=AssertionError("execution plan writes forbidden")):
        thread.start()
        try:
            for index, text in enumerate(TEXTS, 1):
                prefix = output / f"turn-{index}"
                synthesize(text, prefix, args.voice)
                print(f"第 {index} 轮：语音已合成，正在进行本机识别。", flush=True)
                start = time.monotonic()
                transcript = voice.transcribe(prefix.with_suffix(".pcm"))
                asr_seconds = round(time.monotonic() - start, 2)
                normalized = voice.normalize_transcript(transcript)
                print(f"识别文本：{transcript}；正在调用 DeepSeek 生成候选。", flush=True)
                start = time.monotonic()
                proposal = planner.interpret_command(normalized, session_id, candidate_only=True)
                model_seconds = round(time.monotonic() - start, 2)
                session_id = proposal["session_id"]
                candidate = {
                    "turn": index, "synthesized_text": text,
                    "audio_file": str(prefix.with_suffix(".wav")),
                    "audio_sha256": hashlib.sha256(prefix.with_suffix(".wav").read_bytes()).hexdigest(),
                    "asr_transcript": transcript, "normalized_transcript": normalized,
                    "session_id": session_id, "proposal_id": proposal["proposal_id"],
                    "plan": proposal["plan"], "preview": proposal["preview"],
                    "human_confirmation": "pending", "execution_allowed": False,
                    "asr_seconds": asr_seconds, "model_seconds": model_seconds,
                }
                planner.atomic_write_json(output / f"turn-{index}-candidate.json", candidate)
                records.append(candidate)
                print(f"候选：{proposal['preview']['summary']}（待确认、禁止提交）", flush=True)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
    actual = [[action["parameters"]["color"] for action in record["plan"]["actions"]] for record in records]
    result = {"audio_source": "macOS synthetic speech", "tts_voice": args.voice,
              "asr_engine": "whisper.cpp", "asr_model": args.model.name,
              "real_asr": True, "real_deepseek": True, "deepseek_model": os.environ["OPENAI_CHAT_MODEL_ID"],
              "human_confirmation": "pending", "execution_allowed": False,
              "aircraft_access": False, "expected_sequences_match": actual == [["pink", "yellow"], ["pink", "blue"]],
              "turns": records}
    report = output / "result.json"
    planner.atomic_write_json(report, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"报告：{report}")
    return 0 if result["expected_sequences_match"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        # Avoid printing supplier exceptions that might contain credentials.
        print(f"语音候选测试未完成（{type(exc).__name__}），没有提交计划。", file=sys.stderr)
        raise SystemExit(1)
