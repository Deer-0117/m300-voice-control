#!/usr/bin/env python3
"""Audit recorded, actual API-driven trials; never invent success from imagery."""
import json,math,runpy,sys
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'))
from uav_dynamic_world import DynamicWorld
from uav_adaptive_segment import validate_adaptive
verify=runpy.run_path(str(ROOT/'scripts/verify-interrupt-mission-simulation.py'))['verify']

def audit(path):
    verify(path/'result.json')
    r=json.loads((path/'result.json').read_text());frames=r['frames'];start=r['comparison_checkpoint_frame']
    groups=Counter(f['model_call'] for f in frames[start:] if f['phase']=='revised_motion' and f['preview']['arguments'] is not None)
    for seq,c in enumerate(r['calls'],1):
        assert c['response_id'] and len(c['temporal_images'])==3
        assert [m['frame'] for m in c['temporal_images']]==sorted(set(m['frame'] for m in c['temporal_images']))
        for m in c['temporal_images']:
            assert m['sim_time_s']<=c['request']['sim_time_s']+.051 and (path/m['image']).is_file()
            assert m['pose']==frames[m['frame']]['pose_before']
            assert m['velocity']==frames[m['frame']]['plant_before']['velocity_world_mps']
        if seq in groups:
            validate_adaptive(c['response'],r['maximum_duration_s'])
            assert groups[seq]*.05<=c['response']['duration_s']+1e-8
            assert c['hover_evidence']['hover_verified']
    end=frames[-1]['pose_after'];minimum=min(math.dist([f['pose_after'][a] for a in ('x','y','z')],[5.5,2,10]) for f in frames[start:])
    result=dict(output=str(path),completed=r['completed'],contacts=r['contacts'],maximum_duration_s=r['maximum_duration_s'],
        real_visual_responses=len(r['calls']),motion_decisions=len(groups),
        rejected_responses=sum(bool(c.get('acceptance_error')) for c in r['calls']),
        model_durations_s=[c['response']['duration_s'] for c in r['calls']],
        green_min_distance_m=minimum,elapsed_after_checkpoint_s=(len(frames)-start)/20,
        analysis_hold_frames=sum(f['preview'].get('reason')=='analysis_hold' for f in frames[start:]),
        early_abort_counts=dict(Counter(f['preview'].get('reason') for f in frames[start:] if f['phase']=='revised_motion' and f['preview'].get('reason'))),
        sdk_calls=0)
    (path/'adaptive-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return r,result

if __name__=='__main__':
    paths=[Path(p).resolve() for p in sys.argv[1:]];results=[audit(p) for p in paths]
    if len(results)==2:
        a,b=results[0][0],results[1][0];cut=a['comparison_checkpoint_frame']
        assert cut==b['comparison_checkpoint_frame'] and a['frames'][:cut]==b['frames'][:cut]
        assert a['dynamics_parameters']==b['dynamics_parameters'] and a['world_balloons']==b['world_balloons']
    print(json.dumps({'same_checkpoint':len(results)==2,'trials':[v for r,v in results]},ensure_ascii=False,indent=2))
