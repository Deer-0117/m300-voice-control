#!/usr/bin/env python3
"""Summarize the most recent completed Liveview test from device JSONL logs."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import fmean
from typing import Any


def read_jsonl(path: Path) -> tuple[list[dict[str, Any]], int]:
    records: list[dict[str, Any]] = []
    skipped = 0
    with path.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            try:
                value = json.loads(line)
            except (json.JSONDecodeError, TypeError):
                skipped += 1
                continue
            if isinstance(value, dict):
                records.append(value)
            else:
                skipped += 1
    return records, skipped


def percentile(values: list[float], point: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * point / 100.0
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return round(ordered[lower], 3)
    weight = position - lower
    return round(ordered[lower] * (1.0 - weight) + ordered[upper] * weight, 3)


def stats(values: list[float]) -> dict[str, float | int | None]:
    return {
        "count": len(values),
        "min": round(min(values), 3) if values else None,
        "p50": percentile(values, 50),
        "p95": percentile(values, 95),
        "max": round(max(values), 3) if values else None,
        "mean": round(fmean(values), 3) if values else None,
    }


def event_time(record: dict[str, Any]) -> int:
    for key in ("ts_ms", "detection_started_ts_ms", "capture_ts_ms"):
        try:
            value = int(record.get(key) or 0)
        except (TypeError, ValueError):
            continue
        if value > 0:
            return value
    return 0


def int_value(record: dict[str, Any], key: str) -> int | None:
    try:
        value = int(record.get(key))
    except (TypeError, ValueError):
        return None
    return value


def match_current_detections(
    detections: list[dict[str, Any]], launched: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Match results to this task without trusting a reboot-unstable wall clock alone."""
    candidates: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for row in detections:
        seq = int_value(row, "seq")
        source = str(row.get("source") or row.get("detect_source") or "")
        if seq is not None and source:
            candidates[(seq, source)].append(row)

    matched: list[dict[str, Any]] = []
    for launch in launched:
        seq = int_value(launch, "seq")
        source = str(launch.get("path") or "")
        launch_ms = event_time(launch)
        if seq is None or not source or launch_ms <= 0:
            continue
        rows = candidates.get((seq, source), [])
        plausible: list[tuple[int, dict[str, Any]]] = []
        for row in rows:
            request_ms = int_value(row, "request_ts_ms")
            if request_ms is None:
                continue
            delta = abs(request_ms - launch_ms)
            if delta <= 100:
                plausible.append((delta, row))
        if plausible:
            matched.append(min(plausible, key=lambda item: item[0])[1])
    return matched


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/home/uav/offline_balloon_strike_test"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    captures, capture_skipped = read_jsonl(args.root / "capture_events.jsonl")
    starts = [index for index, row in enumerate(captures) if row.get("event") == "photo_task_started"]
    if not starts:
        raise SystemExit("no photo_task_started event found")
    start_index = starts[-1]
    task_capture = captures[start_index:]
    stop_offset = next(
        (index for index, row in enumerate(task_capture) if row.get("event") == "photo_task_stopped"),
        None,
    )
    if stop_offset is None:
        raise SystemExit("most recent Liveview task has not stopped")
    task_capture = task_capture[: stop_offset + 1]
    start_ms = event_time(task_capture[0])
    stop_ms = event_time(task_capture[-1])
    if start_ms <= 0 or stop_ms < start_ms:
        raise SystemExit(f"invalid task time range: {start_ms}..{stop_ms}")

    latency, latency_skipped = read_jsonl(args.root / "latency_events.jsonl")
    detections, detection_skipped = read_jsonl(args.root / "detection_results.jsonl")
    launched = [row for row in task_capture if row.get("event") == "liveview_detection_launched"]
    task_detections = match_current_detections(detections, launched)
    launch_sequences = {
        int(row["seq"])
        for row in launched
        if row.get("seq") is not None and str(row.get("seq")).isdigit()
    }
    task_latency = [
        row
        for row in latency
        if start_ms <= event_time(row) <= stop_ms
        and (int_value(row, "seq") is None or int_value(row, "seq") in launch_sequences)
    ]

    stages: dict[str, list[float]] = defaultdict(list)
    for row in task_latency:
        try:
            stages[str(row["stage"])].append(float(row["duration_ms"]))
        except (KeyError, TypeError, ValueError):
            continue

    detection_metrics: dict[str, list[float]] = defaultdict(list)
    metric_names = (
        "latency_ms",
        "wrapper_latency_ms",
        "capture_to_request_ms",
        "request_to_detection_finished_ms",
        "target_age_ms",
    )
    for row in task_detections:
        for name in metric_names:
            try:
                value = row.get(name)
                if value is not None:
                    detection_metrics[name].append(float(value))
            except (TypeError, ValueError):
                continue

    evaluated_sequences = {
        int(row["seq"])
        for row in task_detections
        if row.get("seq") is not None and str(row.get("seq")).isdigit()
    }
    duration_s = max(0.001, (stop_ms - start_ms) / 1000.0)
    report = {
        "task": {
            "start_ts_ms": start_ms,
            "stop_ts_ms": stop_ms,
            "duration_s": round(duration_s, 3),
            "requests_launched": len(launched),
            "detections_completed": len(task_detections),
            "unique_detection_sequences": len(evaluated_sequences),
            "request_rate_hz": round(len(launched) / duration_s, 3),
            "detection_rate_hz": round(len(task_detections) / duration_s, 3),
            "latest_request_overwrite_count": max(0, len(launched) - len(evaluated_sequences)),
            "request_completion_ratio": round(len(evaluated_sequences) / len(launched), 6)
            if launched else None,
        },
        "latency_stage_ms": {name: stats(values) for name, values in sorted(stages.items())},
        "detection_record_ms": {
            name: stats(values) for name, values in sorted(detection_metrics.items())
        },
        "invalid_jsonl_lines_skipped": {
            "capture_events": capture_skipped,
            "latency_events": latency_skipped,
            "detection_results": detection_skipped,
        },
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
