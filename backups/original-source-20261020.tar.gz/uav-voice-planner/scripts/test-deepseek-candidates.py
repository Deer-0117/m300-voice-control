#!/usr/bin/env python3
"""Real-model, candidate-only two-turn test. Never submit or query an aircraft."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
import uav_microsoft_agent as planner


def load_configuration():
    allowed = {"OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_CHAT_MODEL_ID"}
    path = ROOT / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            key, separator, value = line.partition("=")
            if not separator or key.strip() not in allowed:
                raise ValueError(".env contains an unsupported configuration key")
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            if value:
                os.environ[key.strip()] = value
    if not os.environ.get("OPENAI_API_KEY", "").strip():
        raise ValueError("请在项目根目录 .env 的 OPENAI_API_KEY= 后填写 DeepSeek Key。")
    endpoint = os.environ.get("OPENAI_BASE_URL", "https://api.deepseek.com").rstrip("/")
    if endpoint != "https://api.deepseek.com":
        raise ValueError("This test only permits the official https://api.deepseek.com endpoint")
    os.environ["OPENAI_BASE_URL"] = endpoint
    os.environ.setdefault("OPENAI_CHAT_MODEL_ID", "deepseek-flash")
    os.environ["UAV_AGENT_ENABLE_ONLINE"] = "1"
    # These credentials are unnecessary and must not be used by this process.
    os.environ.pop("UAV_PLAN_AUTH_TOKEN", None)


def main():
    load_configuration()
    planner.STATE_ROOT = ROOT / "local-planner-test"
    planner.PLAN_DIR = planner.STATE_ROOT / "plans"
    planner.EVENT_LOG = planner.STATE_ROOT / "events.jsonl"
    with patch.object(planner, "executor_observation", side_effect=AssertionError("aircraft access forbidden")), \
            patch.object(planner, "submit_proposal", side_effect=AssertionError("submission forbidden")):
        first = planner.interpret_command("先撞红色气球，再撞绿色气球", candidate_only=True)
        second = planner.interpret_command("把第二个改成紫色", first["session_id"], candidate_only=True)
    actual = [[step["parameters"]["color"] for step in result["plan"]["actions"]]
              for result in (first, second)]
    passed = actual == [["pink", "yellow"], ["pink", "blue"]]
    report = {
        "real_api": True, "model": os.environ["OPENAI_CHAT_MODEL_ID"],
        "session_id": first["session_id"], "execution_allowed": False,
        "first": {"command": first["command"], "plan": first["plan"], "preview": first["preview"]},
        "second": {"command": second["command"], "plan": second["plan"], "preview": second["preview"]},
        "expected_sequences_match": passed,
        "context": "Second request includes the first command and validated proposed plan in recent_turns.",
    }
    planner.atomic_write_json(planner.STATE_ROOT / "two-turn-result.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        # Supplier/SDK exceptions can contain headers or request bodies. Do not dump them.
        if isinstance(exc, ValueError):
            print(str(exc), file=sys.stderr)
        else:
            print(f"候选测试未完成（{type(exc).__name__}）；未提交飞行计划。", file=sys.stderr)
        raise SystemExit(1)
