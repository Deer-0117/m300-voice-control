#!/usr/bin/env python3
"""Decode the recorded MP4 and synchronized simulation log; preview through C.
No API requests, no aircraft transport; this is open-loop replay, not a new flight.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import runpy
import subprocess
import sys
from collections import Counter

from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'))
from uav_video_feedback import GatedFeedbackPreview, detect_video_frame, require_synchronized_pts


def decode(path):
    metadata=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height:frame=best_effort_timestamp_time','-of','json',str(path)]))
    width,height=metadata['streams'][0]['width'],metadata['streams'][0]['height']
    pts=[float(f['best_effort_timestamp_time']) for f in metadata['frames']]
    if any(b<=a for a,b in zip(pts,pts[1:])):raise ValueError('video PTS must increase')
    proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(path),'-map','0:v:0','-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
    try:
        for index,t in enumerate(pts):
            data=proc.stdout.read(width*height*3)
            if len(data)!=width*height*3:raise ValueError('truncated video frame')
            yield index,t,Image.frombytes('RGB',(width,height),data)
        if proc.stdout.read(1):raise ValueError('video frame count mismatch')
        if proc.wait()!=0:raise RuntimeError('video decode failed')
    finally:
        proc.stdout.close()
        if proc.poll() is None:proc.terminate();proc.wait()


def state_from_trace(frames,index,now):
    # Stored video has poses, not sensor velocity measurements. Derive synthetic
    # telemetry explicitly rather than claiming that this is flight recorder data.
    pose=frames[index]['pose_before']
    velocity=[0.,0.,0.];rate=0.
    if index:
        prior=frames[index-1]['pose_before']
        dt=frames[index]['sim_time_s']-frames[index-1]['sim_time_s']
        if dt<=0:raise ValueError('non-monotonic telemetry')
        velocity=[(pose[k]-prior[k])/dt for k in ('x','y','z')]
        delta=math.atan2(math.sin(pose['yaw']-prior['yaw']),math.cos(pose['yaw']-prior['yaw']))
        rate=delta/dt
    return dict(timestamp_ms=now,altitude_agl_m=pose['z'],velocity_neu_mps=velocity,
                attitude_deg=[0.,0.,math.degrees(pose['yaw'])],angular_rate_radps=[0.,0.,rate],
                in_air=True,velocity_healthy=True,has_authority=True,
                provenance='synthetic pose differences; permission/airborne flags are simulation assumptions')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    src=ROOT/'local-planner-test/static-world-vision'
    p.add_argument('--video',type=Path,default=src/'camera-input.mp4')
    p.add_argument('--recording',type=Path,default=src/'result.json')
    p.add_argument('--plans',type=Path,default=ROOT/'local-planner-test/two-turn-result.json')
    p.add_argument('--output',type=Path,default=ROOT/'local-planner-test/video-feedback-replay')
    args=p.parse_args()
    recording=json.loads(args.recording.read_text());plans=json.loads(args.plans.read_text())
    frames=recording['frames'];calls=recording['calls']
    if not recording.get('simulation_only'):raise ValueError('this adapter only accepts simulation recordings')
    library=runpy.run_path(str(ROOT/'scripts/demo-feedback-preview.py'))['build'](args.output)
    camera={'width':880,'height':480,'hfov_deg':73.7,
            'vfov_deg':math.degrees(2*math.atan(480/880*math.tan(math.radians(73.7/2))))}
    result={'source_video':str(args.video),'source_sha256':hashlib.sha256(args.video.read_bytes()).hexdigest(),
            'source_recording_sha256':hashlib.sha256(args.recording.read_bytes()).hexdigest(),
            'execution_allowed':False,'human_confirmation':'pending','api_calls':0,'camera':camera,
            'kind':'open_loop_recorded_video_replay_not_resimulated_trajectory','frames':[]}
    context=None;pipeline=None;contacts=[];last_call=0
    stream=decode(args.video)
    try:
        for index,pts,image in stream:
            if index>=len(frames):raise ValueError('missing telemetry for video frame')
            saved=frames[index]
            require_synchronized_pts(pts,saved['sim_time_s'])
            now=10000+round(pts*1000)
            vision=detect_video_frame(image,now,index)
            frame=dict(now_ms=now,vision=vision,aircraft=state_from_trace(frames,index,now),
                       camera_boresight_deg=[0.,0.],camera_boresight_timestamp_ms=now)
            revision=1 if pts<2 else 2
            plan=plans['first' if revision==1 else 'second']['plan']
            action_index=len(contacts)+1
            key=(revision,action_index)
            if key!=context:
                if pipeline:pipeline.close()
                pipeline=None
                if action_index<=len(plan['actions']):
                    pipeline=GatedFeedbackPreview(library,plan,camera,revision,action_index)
                context=key
            call_index=saved['model_call']
            acceptance=None
            if call_index!=last_call:
                if call_index!=last_call+1 or not 1<=call_index<=len(calls):raise ValueError('invalid model response ordering')
                call=calls[call_index-1]
                image_time=10000+round(call['request']['sim_time_s']*1000)
                if image_time!=now:raise ValueError('model image timestamp does not match current video frame')
                if pipeline:
                    acceptance=pipeline.accept_model(call['response'],vision,frame_id=index,
                        image_timestamp_ms=image_time,received_timestamp_ms=now,sequence=call_index)
                last_call=call_index
            if pipeline:
                preview=pipeline.step(frame)
            else:
                preview=dict(decision='blocked',reason='recorded_simulation_completed',api=None,arguments=None,
                             sdk_called=False,execution_allowed=False,human_confirmation='pending',completion=False)
            # Retain original hold during the instruction revision demonstration.
            if pts<2:
                preview.update(decision='blocked',reason='recorded_instruction_review',api=None,arguments=None)
            result['frames'].append(dict(frame_index=index,pts_s=pts,vision=vision,aircraft=frame['aircraft'],
                                         model_acceptance_error=acceptance,preview=preview))
            for color in saved['contacts_this_frame']:
                expected=['red','purple'] if revision==2 else ['red','green']
                if len(contacts)>=len(expected) or color!=expected[len(contacts)]:raise ValueError('out-of-order recorded contact')
                contacts.append(color)
        if len(result['frames'])!=len(frames):raise ValueError('video missing frames for telemetry')
    finally:
        stream.close()
        if pipeline:pipeline.close()
    counts=Counter(f['preview'].get('reason','controller_preview') for f in result['frames'])
    result.update(frame_count=len(result['frames']),decision_counts=dict(counts),recorded_simulation_contacts=contacts)
    (args.output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'frames':result['frame_count'],'decisions':counts,'output':str(args.output/'result.json')},ensure_ascii=False))


if __name__=='__main__':main()
