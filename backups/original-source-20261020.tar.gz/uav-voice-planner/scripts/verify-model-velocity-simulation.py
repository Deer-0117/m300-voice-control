#!/usr/bin/env python3
"""Independently audit geometry, holds, and model authorship of every motion tick."""
import hashlib
import json
import math
from pathlib import Path
import runpy
import sys
from PIL import Image


def verify(path):
    record=json.loads(path.read_text())
    result=runpy.run_path(str(Path(__file__).with_name('verify-enhanced-simulation.py')))['verify'](record)
    calls={i+1:c for i,c in enumerate(record['calls'])}
    counts={};durations={}
    for seq,call in calls.items():
        image=Image.open(path.parent/call['image']).convert('RGB')
        assert hashlib.sha256(image.tobytes()).hexdigest()==call['stationary_revalidation']['image_sha256']
        assert 'world_balloons' not in call['request']
    for frame in record['frames']:
        if frame['preview']['arguments'] is None:continue
        seq=frame['model_call'];call=calls[seq];response=call['response']
        assert call['acceptance_error'] is None
        assert frame['preview']['decision']=='model_velocity_preview'
        assert frame['command']==response['velocity'],'local code changed model velocity'
        assert frame['preview']['model_evidence']['sequence']==seq
        start=call['stationary_revalidation']['revalidated_timestamp_ms']+50
        ticks=math.floor(response['duration_s']*20+1e-8)
        assert start<=frame['vision']['target_timestamp_ms']<start+ticks*50
        counts[seq]=counts.get(seq,0)+1
        assert counts[seq]<=ticks
        durations[seq]=response['duration_s']
    root=Path(__file__).resolve().parents[1]
    assert all(hashlib.sha256((root/s).read_bytes()).hexdigest()==v for s,v in record['source_hashes'].items())
    result.update(model_generated_motion_frames=sum(counts.values()),model_velocity_segments=len(counts),
                  all_motion_numbers_equal_model_response=True,all_segment_durations_respected=True,
                  no_C_servo=True,model_images_match_stationary_evidence=True,source_hashes_match=True)
    (path.parent/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':verify(Path(sys.argv[1]))
