#!/usr/bin/env python3
"""Compare the existing PyTorch detector with a TensorRT engine on the same images."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np


def percentile(values: list[float], value: float) -> float | None:
    return round(float(np.percentile(values, value)), 3) if values else None


def best_detection(records: list[dict[str, Any]]) -> dict[str, Any] | None:
    return max(records, key=lambda item: float(item.get("confidence", 0.0))) if records else None


def box_iou(left: dict[str, Any], right: dict[str, Any]) -> float:
    a = [float(value) for value in left["bbox_xyxy"]]
    b = [float(value) for value in right["bbox_xyxy"]]
    intersection_width = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    intersection_height = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    intersection = intersection_width * intersection_height
    area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    return intersection / max(area_a + area_b - intersection, 1e-7)


def collect_images(root: Path, limit: int) -> list[Path]:
    extensions = {".jpg", ".jpeg", ".png", ".bmp"}
    images = sorted(path for path in root.rglob("*") if path.is_file() and path.suffix.lower() in extensions)
    return images[:limit] if limit > 0 else images


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-root", type=Path, default=Path("/home/uav/offline_balloon_strike_test"))
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--engine", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--minimum-agreement", type=float, default=0.98)
    parser.add_argument("--minimum-iou", type=float, default=0.95)
    parser.add_argument("--minimum-speedup", type=float, default=2.0)
    parser.add_argument("--maximum-p95-ms", type=float, default=250.0)
    parser.add_argument("--decode-divisor", type=int, choices=(1, 2, 4, 8), default=8)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    runtime_root = args.runtime_root.resolve()
    module_root = runtime_root / "yolo_callable_module"
    sys.path.insert(0, str(runtime_root))
    sys.path.insert(0, str(module_root))

    import yolo_infer  # type: ignore

    yolo_infer.add_local_ultralytics_to_path()
    from ultralytics import YOLO  # type: ignore
    from balloon_tensorrt import TensorRTBalloonDetector  # type: ignore

    config = yolo_infer.load_config()
    pytorch_model = YOLO(str(config["weights"].resolve()))
    tensorrt_model = TensorRTBalloonDetector(
        args.engine, int(config["imgsz"]), float(config["conf"]), args.decode_divisor
    )
    images = collect_images(args.images.resolve(), args.limit)
    if not images:
        raise SystemExit(f"no images found below {args.images}")

    pytorch_ms: list[float] = []
    tensorrt_ms: list[float] = []
    ious: list[float] = []
    confidence_deltas: list[float] = []
    agreements = 0
    baseline_positives = 0
    trt_true_positives = 0
    rows: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []

    with contextlib.redirect_stdout(io.StringIO()):
        pytorch_model.predict(source=str(images[0]), imgsz=config["imgsz"], conf=config["conf"],
                              device=config["device"], save=False, verbose=False)
    tensorrt_model.predict_records(images[0])

    for image in images:
        try:
            started = time.perf_counter()
            with contextlib.redirect_stdout(io.StringIO()):
                results = pytorch_model.predict(source=str(image), imgsz=config["imgsz"], conf=config["conf"],
                                                device=config["device"], save=False, verbose=False)
            current_pytorch_ms = (time.perf_counter() - started) * 1000
            pytorch_records = [record for result in results for record in yolo_infer.result_to_records(result)]

            started = time.perf_counter()
            tensorrt_records = tensorrt_model.predict_records(image)
            current_tensorrt_ms = (time.perf_counter() - started) * 1000
        except Exception as exc:
            skipped.append({"image": str(image), "error": repr(exc)})
            continue
        pytorch_ms.append(current_pytorch_ms)
        tensorrt_ms.append(current_tensorrt_ms)
        pytorch_best, tensorrt_best = best_detection(pytorch_records), best_detection(tensorrt_records)
        agreements += int(bool(pytorch_best) == bool(tensorrt_best))
        if pytorch_best:
            baseline_positives += 1
            trt_true_positives += int(tensorrt_best is not None)
        row: dict[str, Any] = {
            "image": str(image),
            "pytorch_detection": pytorch_best is not None,
            "tensorrt_detection": tensorrt_best is not None,
            "pytorch_ms": round(pytorch_ms[-1], 3),
            "tensorrt_ms": round(tensorrt_ms[-1], 3),
            "tensorrt_stages_ms": dict(tensorrt_model.last_timings_ms),
            "pytorch_confidence": round(float(pytorch_best["confidence"]), 6) if pytorch_best else None,
            "tensorrt_confidence": round(float(tensorrt_best["confidence"]), 6) if tensorrt_best else None,
            "pytorch_bbox": pytorch_best.get("bbox_xyxy") if pytorch_best else None,
            "tensorrt_bbox": tensorrt_best.get("bbox_xyxy") if tensorrt_best else None,
        }
        if pytorch_best and tensorrt_best:
            current_iou = box_iou(pytorch_best, tensorrt_best)
            confidence_delta = abs(float(pytorch_best["confidence"]) - float(tensorrt_best["confidence"]))
            ious.append(current_iou)
            confidence_deltas.append(confidence_delta)
            row.update({"best_iou": round(current_iou, 6), "confidence_delta": round(confidence_delta, 6)})
        rows.append(row)

    evaluated = len(rows)
    if not evaluated:
        raise SystemExit("no decodable images were evaluated")
    agreement = agreements / evaluated
    recall = trt_true_positives / baseline_positives if baseline_positives else 1.0
    pytorch_p50 = percentile(pytorch_ms, 50) or 0.0
    trt_p50 = percentile(tensorrt_ms, 50) or 0.0
    speedup = pytorch_p50 / max(trt_p50, 1e-7)
    median_iou = float(np.median(ious)) if ious else 1.0
    trt_p95 = percentile(tensorrt_ms, 95) or 0.0
    passed = (
        agreement >= args.minimum_agreement
        and recall >= args.minimum_agreement
        and median_iou >= args.minimum_iou
        and speedup >= args.minimum_speedup
        and trt_p95 <= args.maximum_p95_ms
    )
    report = {
        "pass": passed,
        "images_found": len(images),
        "images_evaluated": evaluated,
        "images_skipped": len(skipped),
        "baseline_positives": baseline_positives,
        "presence_agreement": round(agreement, 6),
        "tensorrt_recall_vs_pytorch": round(recall, 6),
        "median_best_box_iou": round(median_iou, 6),
        "confidence_delta_p95": percentile(confidence_deltas, 95),
        "pytorch_latency_ms": {"p50": pytorch_p50, "p95": percentile(pytorch_ms, 95)},
        "tensorrt_latency_ms": {"p50": trt_p50, "p95": trt_p95},
        "p50_speedup": round(speedup, 3),
        "thresholds": {
            "minimum_agreement": args.minimum_agreement,
            "minimum_iou": args.minimum_iou,
            "minimum_speedup": args.minimum_speedup,
            "maximum_p95_ms": args.maximum_p95_ms,
        },
        "decode_divisor": args.decode_divisor,
        "results": rows,
        "skipped": skipped,
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
