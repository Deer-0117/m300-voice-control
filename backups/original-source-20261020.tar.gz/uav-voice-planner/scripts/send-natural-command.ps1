<#
.SYNOPSIS
Submits one natural-language command to the constrained code10 planner.
.DESCRIPTION
The script verifies the remote hostname before sending anything. The planner
may emit only capability-library actions; it cannot accept raw flight-control
values. A local stop command remains independent of model availability.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Command,
    [string]$HostName = 'uav-one-gimbal',
    [string]$ExpectedRemoteHostName = 'code10'
)

$ErrorActionPreference = 'Stop'
$actual = ((ssh $HostName 'hostname') -join "`n").Trim()
if ($LASTEXITCODE -ne 0 -or $actual -ne $ExpectedRemoteHostName) {
    throw "Refusing command: connected host '$actual' is not '$ExpectedRemoteHostName'."
}
$show = ssh $HostName 'systemctl show psdk-balloon.service -p ActiveState -p Environment --no-pager'
$showText = $show -join "`n"
if ($LASTEXITCODE -ne 0 -or $showText -notmatch 'ActiveState=active' -or $showText -notmatch 'BALLOON_NO_FLIGHT=1') {
    throw 'Ground command testing requires psdk-balloon.service active with BALLOON_NO_FLIGHT=1.'
}
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Command))
ssh $HostName "sudo -n /home/uav/offline_balloon_strike_test/yolo_env/bin/python /home/uav/offline_balloon_strike_test/uav_natural_language.py --command-base64 '$encoded'"
if ($LASTEXITCODE -ne 0) { throw 'Natural-language command was rejected or failed.' }
