#!/usr/bin/env python3
"""Drive the static world using GatedFeedbackPreview and fresh DeepSeek vision.

Only World.integrate consumes commands. No DJI SDK or aircraft transport exists
in this runner. Human confirmation for real execution remains pending.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

from openai import OpenAI
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'))
from uav_static_world_sim import World, BALLOONS
from uav_video_feedback import GatedFeedbackPreview, detect_video_frame
FPS=20
ZERO={'x':0.,'y':0.,'z':0.,'yaw':0.}
PLAN={'version':2,'actions':[{'capability':'strike_balloon','parameters':{'color':c}} for c in ('red','purple')]}


def video_sink(path,width,height):
    return subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24',
        '-s',f'{width}x{height}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-crf','20','-preset','fast',
        '-pix_fmt','yuv420p','-movflags','+faststart',str(path)],stdin=subprocess.PIPE)


def telemetry(world,previous_pose,now):
    pose={k:getattr(world,k) for k in ('x','y','z','yaw')}
    velocity=[(pose[k]-previous_pose[k])*FPS for k in ('x','y','z')]
    yaw_rate=math.atan2(math.sin(pose['yaw']-previous_pose['yaw']),math.cos(pose['yaw']-previous_pose['yaw']))*FPS
    state=dict(timestamp_ms=now,altitude_agl_m=world.z,velocity_neu_mps=velocity,
        attitude_deg=[0.,0.,math.degrees(world.yaw)],angular_rate_radps=[0.,0.,yaw_rate],
        in_air=True,velocity_healthy=True,has_authority=True,
        provenance='kinematic simulator state; airborne and authority are virtual assumptions')
    return pose,state


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'local-planner-test'/('enhanced-closed-loop-'+time.strftime('%Y%m%d-%H%M%S')))
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    if os.environ['OPENAI_CHAT_MODEL_ID']!='deepseek-flash':raise ValueError('vision-capable model required')
    helpers=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'))
    # Reuse image-request and UI code, but never its old image_servo control loop.
    ask=helpers['ask'];ask.__globals__['OUT']=out
    compose,text=helpers['compose'],helpers['text']
    library=runpy.run_path(str(ROOT/'scripts/demo-feedback-preview.py'))['build'](out)
    camera={'width':880,'height':480,'hfov_deg':73.7,
        'vfov_deg':math.degrees(2*math.atan(480/880*math.tan(math.radians(73.7/2))))}
    world=World();fixed=tuple(BALLOONS);previous_pose={k:getattr(world,k) for k in ('x','y','z','yaw')}
    pipeline=None;action=0;last_call=-100.;seq=0;messages=[];calls=[];frames=[];shots=[];completed=False
    decision={};finish_frame=None;failure=None
    sources=['runtime/uav_video_feedback.py','runtime/uav_feedback_preview.py','src/target_chase/target_chase.c',
             'src/target_chase/preview_bridge.c','runtime/uav_static_world_sim.py']
    manifest={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sources}
    sink=video_sink(out/'closed-loop.mp4',1280,720);rawsink=video_sink(out/'camera-input.mp4',880,480)
    try:
        with OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
            for k in range(FPS*60):
                t=k/FPS;now=10000+k*50
                image=world.render();vision=detect_video_frame(image,now,k)
                pose,state=telemetry(world,previous_pose,now)
                next_action=len(world.contacts)+1
                if next_action!=action:
                    if pipeline:pipeline.close()
                    pipeline=GatedFeedbackPreview(library,PLAN,camera,1,next_action) if next_action<=2 else None
                    action=next_action;last_call=-100.
                receipt_error=None
                if (t-last_call>=2) and finish_frame is None:
                    seq+=1
                    if seq>34:raise RuntimeError('API request budget exceeded')
                    instruction='依次撞红色和紫色气球。始终根据新图像判断；只在仿真内运动，真实执行仍待人工确认。' if seq==1 else '继续红色、紫色的原定顺序，根据当前新图像和仿真接触事件判断。'
                    decision,call=ask(client,messages,world,image,instruction,seq,t)
                    calls.append(call);last_call=t
                    remaining=['red','purple'][len(world.contacts):]
                    if decision['plan']!=['red','purple'] or decision['target']!=(remaining[0] if remaining else None):
                        raise ValueError('model plan or action order mismatch')
                    if pipeline:
                        receipt_error=pipeline.accept_model(decision,vision,frame_id=k,image_timestamp_ms=now,
                            received_timestamp_ms=now,sequence=seq)
                    elif decision['mode']=='done':completed=True;finish_frame=k
                frame=dict(now_ms=now,vision=vision,aircraft=state,camera_boresight_deg=[0.,0.],camera_boresight_timestamp_ms=now)
                preview=pipeline.step(frame) if pipeline else dict(decision='blocked',reason='simulation_contacts_complete',
                    arguments=None,api=None,sdk_called=False,execution_allowed=False,human_confirmation='pending')
                command=dict(preview['arguments']) if preview['arguments'] is not None else dict(ZERO)
                # Only this validated output drives the virtual world. No fallback controller.
                assert not preview['sdk_called'] and not preview['execution_allowed']
                assert math.hypot(command['x'],command['y'])<=2.000001 and abs(command['z'])<=.3 and abs(command['yaw'])<=10
                label='C 控制器闭环 + 输出限幅' if preview['arguments'] is not None else '阻断 / 虚拟机保持'
                if completed:label='红、紫仿真接触完成 / 保持'
                boxes={d['color_name']:d['bbox_xyxy'] for d in vision['detections']}
                canvas=compose(world,image,boxes,decision,command,t,seq,label,True)
                draw=ImageDraw.Draw(canvas)
                draw.rectangle((20,15,1258,54),fill='#09131F')
                text(draw,(24,20),'改进控制代码驱动 · 固定气球 · 持续视觉闭环',28)
                draw.rectangle((25,607,1255,645),fill='#09131F')
                text(draw,(24,613),f"仿真控制  x {command['x']:+.2f} m/s   z {command['z']:+.2f} m/s   yaw {command['yaw']:+.1f} °/s  |  {label}",20)
                sink.stdin.write(canvas.tobytes());rawsink.stdin.write(image.tobytes())
                if k%FPS==0:shots.append(canvas.resize((640,360)))
                if k==5*FPS:canvas.save(out/'poster.png')
                before=list(world.contacts)
                hits=world.integrate(command,1/FPS) if finish_frame is None else []
                assert tuple(BALLOONS)==fixed
                if world.contacts!=['red','purple'][:len(world.contacts)]:raise RuntimeError('unexpected or out-of-order contact')
                frames.append(dict(frame_index=k,sim_time_s=t,pose_before=pose,pose_after={key:getattr(world,key) for key in pose},
                    aircraft=state,vision=vision,model_call=seq,model_acceptance_error=receipt_error,preview=preview,
                    command=command,contacts_before=before,contacts_this_frame=hits))
                previous_pose=pose
                if hits:print('SIM_CONTACT '+json.dumps({'time_s':round(t+1/FPS,2),'colors':hits}),flush=True)
                if finish_frame is not None and k-finish_frame>=2*FPS:break
            if not completed:failure='simulation_timeout_without_completion'
    except Exception as exc:
        failure=type(exc).__name__
        print('Simulation stopped: '+failure,flush=True)
    finally:
        if pipeline:pipeline.close()
        for p in (sink,rawsink):
            p.stdin.close()
            if p.wait()!=0:failure='video_encoding_failed'
        summary=dict(simulation_only=True,controller='GatedFeedbackPreview + existing C controller + bounded_preview_command',
            source_hashes=manifest,camera=camera,world_balloons=fixed,world_positions_fixed=tuple(BALLOONS)==fixed,
            model=os.environ.get('OPENAI_CHAT_MODEL_ID'),real_multimodal_api=True,completed=completed and failure is None,
            contacts=world.contacts,failure=failure,execution_allowed=False,human_confirmation='pending',sdk_calls=0,
            clock='simulation paused during API waits; receipt timestamps use simulation time',
            plan=PLAN,calls=calls,frames=frames,
            decision_counts=dict(Counter(f['preview'].get('reason','controller_preview') for f in frames)),
            limited_frames=sum(bool(f['preview'].get('output_limited')) for f in frames))
        (out/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    if shots:
        indexes=sorted(set([0,len(shots)//4,len(shots)//2,3*len(shots)//4,max(0,len(shots)-3),len(shots)-1]))
        sheet=Image.new('RGB',(1280,360*math.ceil(len(indexes)/2)),'#09131F')
        for i,j in enumerate(indexes):sheet.paste(shots[j],((i%2)*640,(i//2)*360))
        sheet.save(out/'contact-sheet.jpg')
    print(json.dumps({'completed':summary['completed'],'contacts':world.contacts,'calls':seq,'frames':len(frames),'limited_frames':summary['limited_frames'],'output':str(out)},ensure_ascii=False))
    return 0 if summary['completed'] else 1


if __name__=='__main__':sys.exit(main())
