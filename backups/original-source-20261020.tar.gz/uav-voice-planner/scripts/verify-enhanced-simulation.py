#!/usr/bin/env python3
"""Audit a recorded enhanced simulation's commands, motion, and contact order."""
import argparse
import json
import math
from pathlib import Path


def verify(record):
    assert record['completed'] and record['failure'] is None
    assert record['execution_allowed'] is False and record['human_confirmation']=='pending'
    assert record['sdk_calls']==0 and record['world_positions_fixed'] is True
    world=record['world_balloons'];contacts=[];contact_times=[];previous=None
    for i,frame in enumerate(record['frames']):
        assert frame['frame_index']==i and abs(frame['sim_time_s']-i/20)<1e-9
        before,after,cmd=frame['pose_before'],frame['pose_after'],frame['command']
        assert previous is None or before==previous
        assert all(math.isfinite(n) for n in [*before.values(),*after.values(),*cmd.values()])
        assert frame['contacts_before']==contacts
        p=frame['preview']
        assert p['execution_allowed'] is False and p['sdk_called'] is False
        assert p['human_confirmation']=='pending'
        assert cmd==(p['arguments'] if p['arguments'] is not None else {'x':0.,'y':0.,'z':0.,'yaw':0.})
        assert math.hypot(cmd['x'],cmd['y'])<=2.000001 and abs(cmd['z'])<=.3 and abs(cmd['yaw'])<=10
        # Independent reconstruction of one ideal-velocity kinematic step.
        dt=.05;mid=before['yaw']+math.radians(cmd['yaw'])*dt/2
        expected={'x':before['x']+(cmd['x']*math.cos(mid)-cmd['y']*math.sin(mid))*dt,
                  'y':before['y']+(cmd['x']*math.sin(mid)+cmd['y']*math.cos(mid))*dt,
                  'z':before['z']+cmd['z']*dt,'yaw':before['yaw']+math.radians(cmd['yaw'])*dt}
        assert all(abs(after[k]-expected[k])<1e-9 for k in expected), 'motion differs from controller output'
        hits=[c for c,x,y,z in world if c not in contacts and math.sqrt((after['x']-x)**2+(after['y']-y)**2+(after['z']-z)**2)<=.45]
        assert hits==frame['contacts_this_frame']
        contacts.extend(hits)
        assert contacts==['red','purple'][:len(contacts)]
        if hits:contact_times.append({'time_s':round((i+1)/20,2),'colors':hits})
        previous=after
    assert contacts==record['contacts']==['red','purple']
    assert all(call['response']['plan']==['red','purple'] for call in record['calls'])
    hold_checks=None
    if 'holds' in record:
        hold_frame_count=0
        for hold in record['holds']:
            assert hold['stationary_verified']
            assert all(v==0 for v in hold['command'].values())
            start,end=hold['start_frame'],hold['end_frame_exclusive']
            assert end>start and end-start==hold['new_camera_frames']
            source=record['frames'][hold['source_frame']]
            assert hold['source_frame']==start-1
            for j in range(start,end):
                frame=record['frames'][j]
                assert frame['phase']=='hold' and all(v==0 for v in frame['command'].values())
                assert frame['pose_before']==frame['pose_after']==source['pose_after']
                assert frame['vision']['frame_id']==j
                assert frame['vision']['target_timestamp_ms']==10000+j*50
            hold_frame_count+=end-start
        for call in record['calls']:
            evidence=call['stationary_revalidation']
            assert evidence['stationary_verified']
            a,b=evidence['original_model_source_frame'],evidence['revalidated_frame']
            assert b>a and b-a==evidence['new_camera_frames_during_hold']
            assert abs(record['frames'][a]['sim_time_s']-call['request']['sim_time_s'])<1e-8
            assert record['frames'][a]['pose_before']==record['frames'][b]['pose_before']
            assert call.get('acceptance_error') is None
        assert len(record['voice_turns'])==2
        assert record['voice_turns'][0]['session_id']==record['voice_turns'][1]['session_id']
        assert [a['parameters']['color'] for a in record['voice_turns'][-1]['plan']['actions']]==['pink','blue']
        hold_checks={'holds':len(record['holds']),'new_camera_frames_while_holding':hold_frame_count,
                     'all_hold_poses_fixed':True,'all_hold_commands_zero':True,
                     'clock_and_camera_advanced':True,'model_results_revalidated_against_unchanged_scene':True}
    return {'verified':True,'frames':len(record['frames']),'contact_events':contact_times,
            'real_vision_calls':len(record['calls']),'limited_frames':record['limited_frames'],
            'motion_driven_by_validated_controller':True,'sdk_calls':0,'hold_checks':hold_checks}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('recording',type=Path);args=p.parse_args()
    result=verify(json.loads(args.recording.read_text()))
    (args.recording.parent/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
