#!/usr/bin/env python3
"""Real ASR + real DeepSeek velocity control in responsive simulation, with active hover.
Clock and camera continue during inference; only virtual motion is authorized.
"""
import copy
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
import hashlib
from http.server import ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import runpy
import secrets
import sys
import threading
import time
from unittest.mock import patch

from openai import OpenAI
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'))
import uav_microsoft_agent as planner
import uav_voice_command as voice
from uav_static_world_sim import World,BALLOONS
from uav_video_feedback import detect_video_frame
from uav_model_velocity import ModelVelocityPreview, SYSTEM, validate_segment
from uav_stationary_hold import StationaryHoldEvidence
FPS=20
ZERO={'x':0.,'y':0.,'z':0.,'yaw':0.}


def main():
    out=ROOT/'local-voice-test'/('model-velocity-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir(parents=True,exist_ok=False)
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    eh=runpy.run_path(str(ROOT/'scripts/run-enhanced-control-simulation.py'))
    vh=runpy.run_path(str(ROOT/'scripts/test-voice-deepseek-candidates.py'))
    ui=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'))
    ask=ui['ask'];ask.__globals__['OUT']=out;ask.__globals__['SYSTEM']=SYSTEM
    compose,text=ui['compose'],ui['text']
    camera={'width':880,'height':480,'hfov_deg':73.7,'vfov_deg':math.degrees(2*math.atan(480/880*math.tan(math.radians(73.7/2))))}
    world=World();fixed=tuple(BALLOONS);previous_pose={k:getattr(world,k) for k in ('x','y','z','yaw')}
    frames=[];holds=[];turns=[];calls=[];messages=[];shots=[];decision={};seq=0;pipeline=None;completed=False;failure=None
    sink=eh['video_sink'](out/'closed-loop.mp4',1280,720);rawsink=eh['video_sink'](out/'camera-input.mp4',880,480)
    pool=ThreadPoolExecutor(max_workers=1)
    sources=['scripts/run-model-velocity-simulation.py','runtime/uav_model_velocity.py','runtime/uav_stationary_hold.py','runtime/uav_video_feedback.py','runtime/uav_feedback_preview.py',
             'runtime/uav_static_world_sim.py']
    manifest={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in sources}
    latest_image=None;latest_vision=None;latest_pose=None

    def tick(command,preview,phase,label,hold_evidence=None):
        nonlocal previous_pose,latest_image,latest_vision,latest_pose
        k=len(frames);t=k/FPS;now=10000+k*50
        image=world.render();vision=detect_video_frame(image,now,k)
        pose,state=eh['telemetry'](world,previous_pose,now)
        if hold_evidence:hold_evidence.observe(image,pose,k,now,command)
        latest_image,latest_vision,latest_pose=image,vision,pose
        boxes={d['color_name']:d['bbox_xyxy'] for d in vision['detections']}
        canvas=compose(world,image,boxes,decision,command,t,seq,label,True)
        d=ImageDraw.Draw(canvas)
        d.rectangle((20,15,1258,100),fill='#09131F')
        text(d,(24,20),'大模型直接生成速度与转向 · 闭环仿真',28)
        history=' / '.join(turn['transcript'] for turn in turns)
        text(d,(24,65),'语音：'+(history or '正在识别本地合成语音'),18,'#8ADFD2')
        if phase=='hold':
            d.rectangle((35,130,890,171),fill='#3A3020')
            text(d,(48,140),'HOVER  零速度指令 · 时钟继续 · 新相机帧持续输入',20,'#FFD095')
        if len(turns)<2:
            d.rectangle((938,127,1244,162),fill='#142235')
            text(d,(941,131),'等待语音任务解析',22)
        d.rectangle((20,607,1260,717),fill='#09131F')
        text(d,(24,613),f"{label} | x {command['x']:+.2f}  y {command['y']:+.2f} m/s   z {command['z']:+.2f} m/s   yaw {command['yaw']:+.1f} °/s",20)
        text(d,(24,653),'分析期间执行零速度并持续生成视觉帧；返回后校验画面与位姿未变化。',18,'#9FB5C7')
        text(d,(24,686),'气球固定 / 运动学仿真 / 接触由几何验证 / 人工确认待定 / 真实 SDK 调用 0',16,'#9FB5C7')
        sink.stdin.write(canvas.tobytes());rawsink.stdin.write(image.tobytes())
        if k%FPS==0:shots.append(canvas.resize((640,360)))
        if phase=='motion' and k%100==0:canvas.save(out/'poster.png')
        before=list(world.contacts)
        hits=world.integrate(command,1/FPS)
        assert tuple(BALLOONS)==fixed
        assert world.contacts==['red','purple'][:len(world.contacts)]
        assert not preview['execution_allowed'] and not preview['sdk_called']
        assert math.hypot(command['x'],command['y'])<=2.000001 and abs(command['z'])<=.3 and abs(command['yaw'])<=10
        frames.append(dict(frame_index=k,sim_time_s=t,phase=phase,pose_before=pose,
            pose_after={key:getattr(world,key) for key in pose},aircraft=state,vision=vision,
            model_call=seq,preview=preview,command=dict(command),contacts_before=before,contacts_this_frame=hits))
        previous_pose=pose
        if hits:print('SIM_CONTACT '+json.dumps({'time_s':round((k+1)/FPS,2),'colors':hits}),flush=True)
        return hits

    def hold_preview(reason):
        return {'arguments':None,'api':None,'decision':'blocked','reason':reason,
                'execution_allowed':False,'human_confirmation':'pending','sdk_called':False}

    def during_hold(label,fn,with_snapshot=False):
        # Bring the ideal velocity-following simulator to zero before snapshot/request.
        tick(dict(ZERO),hold_preview('pre_analysis_hold'),'hold',label)
        evidence=StationaryHoldEvidence(latest_image,latest_pose,latest_vision['frame_id'],latest_vision['target_timestamp_ms'])
        start_index=len(frames);started=time.monotonic()
        future=(pool.submit(fn,latest_image.copy(),latest_vision['target_timestamp_ms'])
                if with_snapshot else pool.submit(fn))
        try:
            while True:
                tick_start=time.monotonic()
                tick(dict(ZERO),hold_preview('analysis_hold'),'hold',label,evidence)
                timeout=max(.001,1/FPS-(time.monotonic()-tick_start))
                try:
                    result=future.result(timeout=timeout)
                    break
                except FutureTimeout:
                    if future.done():raise
            receipt=evidence.receipt()
            # The final tick captures the same scene after an actual zero-motion step.
            return result,receipt
        finally:
            holds.append({'label':label,'start_frame':start_index,'end_frame_exclusive':len(frames),
                'wall_seconds':round(time.monotonic()-started,3),'sim_seconds':(len(frames)-start_index)/FPS,
                'stationary_verified':evidence.valid,'command':dict(ZERO),'source_frame':evidence.source_frame,
                'image_sha256':evidence.original_hash,'new_camera_frames':evidence.frames})
            (out/'holds.json').write_text(json.dumps(holds,ensure_ascii=False,indent=2)+'\n')

    planner.STATE_ROOT=out/'planner';planner.PLAN_DIR=planner.STATE_ROOT/'plans';planner.EVENT_LOG=planner.STATE_ROOT/'events.jsonl'
    server=ThreadingHTTPServer(('127.0.0.1',0),vh['QuietAsrHandler']);endpoint=f'http://127.0.0.1:{server.server_port}/transcribe'
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    env={'UAV_WHISPER_CLI':str(ROOT/'local-asr/whisper.cpp/build/bin/whisper-cli'),
         'UAV_WHISPER_MODEL':str(ROOT/'local-asr/whisper.cpp/models/ggml-base.bin'),
         'UAV_VOICE_ASR_STATE_DIR':str(out/'asr-state'),'UAV_VOICE_ASR_ENDPOINT':endpoint,'UAV_VOICE_ASR_FALLBACK_ENDPOINT':endpoint,
         'UAV_VOICE_ASR_TOKEN':secrets.token_urlsafe(32),'NO_PROXY':os.environ.get('NO_PROXY','')+',127.0.0.1,localhost'}
    plan=None
    try:
        with patch.dict(os.environ,env), \
             patch.object(planner,'executor_observation',side_effect=AssertionError('aircraft forbidden')), \
             patch.object(planner,'submit_proposal',side_effect=AssertionError('submission forbidden')), \
             patch.object(voice,'confirm',side_effect=AssertionError('confirmation pending')), \
             patch.object(voice,'store_plan',side_effect=AssertionError('execution plan forbidden')):
            thread.start();session=None
            for i in (1,2):
                audio=ROOT/f'local-voice-test/20261018-150111/turn-{i}.pcm'
                transcript,_=during_hold('语音识别中 / 悬停',lambda:voice.transcribe(audio))
                normalized=voice.normalize_transcript(transcript)
                proposal,_=during_hold('语音任务分析中 / 悬停',lambda:planner.interpret_command(normalized,session,candidate_only=True))
                session=proposal['session_id'];plan=proposal['plan']
                turns.append({'transcript':transcript,'normalized':normalized,'plan':plan,'session_id':session,
                    'proposal_id':proposal['proposal_id'],'audio':str(audio),'audio_sha256':hashlib.sha256(audio.read_bytes()).hexdigest()})
                print('VOICE '+transcript+' -> '+json.dumps(plan,ensure_ascii=False),flush=True)
            if [a['parameters']['color'] for a in plan['actions']]!=['pink','blue']:raise ValueError('voice plan mismatch')
            action=0;last_received=-100000
            with OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
                for motion_tick in range(FPS*60):
                    next_action=len(world.contacts)+1
                    if next_action!=action:
                        if pipeline:pipeline.close()
                        pipeline=ModelVelocityPreview(plan,next_action) if next_action<=2 else None
                        action=next_action;last_received=-100000
                    now=10000+len(frames)*50
                    if last_received<0 or pipeline is None or pipeline.command is None or now>=pipeline.deadline:
                        seq+=1
                        if seq>60:raise RuntimeError('vision request budget exceeded')
                        instruction='实际语音识别历史：'+json.dumps([t['normalized'] for t in turns],ensure_ascii=False)+'。当前校验候选：'+json.dumps(plan,ensure_ascii=False)+'。请根据新画面执行最终顺序，只允许仿真。'
                        def infer(image_snapshot,image_timestamp):
                            # These are captured only after the pre-analysis zero-command step.
                            return ask(client,messages,world,image_snapshot,instruction,seq,image_timestamp/1000-10,max_tokens=1800)
                        (decision,call),receipt=during_hold('视觉模型分析中 / 悬停',infer,with_snapshot=True)
                        validate_segment(decision)
                        call['stationary_revalidation']=receipt
                        expected=['red','purple'][len(world.contacts):]
                        if decision.get('plan')!=['red','purple'] or decision.get('target')!=(expected[0] if expected else None):raise ValueError('vision plan mismatch')
                        if pipeline:
                            error=pipeline.accept_model(decision,latest_vision,frame_id=latest_vision['frame_id'],
                                image_timestamp_ms=latest_vision['target_timestamp_ms'],received_timestamp_ms=latest_vision['target_timestamp_ms'],sequence=seq)
                            call['acceptance_error']=error
                            if pipeline.gate.receipt is not None:pipeline.gate.receipt['stationary_revalidation']=receipt
                        elif decision.get('mode')=='done':completed=True
                        messages.append({'role':'user','content':json.dumps({'local_validation':call.get('acceptance_error'),'velocity_policy':'Rejected commands cause zero motion. Correct the next response.'})})
                        calls.append(copy.deepcopy(call))
                        (out/f'call-{seq:02d}-validated.json').write_text(json.dumps(call,ensure_ascii=False,indent=2)+'\n')
                        last_received=latest_vision['target_timestamp_ms']
                    if completed:
                        for _ in range(FPS*2):tick(dict(ZERO),hold_preview('task_complete'),'complete','红、紫几何接触完成 / 保持')
                        break
                    k=len(frames);now=10000+k*50
                    image=world.render();vision=detect_video_frame(image,now,k)
                    _,state=eh['telemetry'](world,previous_pose,now)
                    feedback={'now_ms':now,'vision':vision,'aircraft':state,'camera_boresight_deg':[0.,0.],'camera_boresight_timestamp_ms':now}
                    preview=pipeline.step(feedback) if pipeline else hold_preview('await_model_completion')
                    command=dict(preview['arguments']) if preview['arguments'] is not None else dict(ZERO)
                    tick(command,preview,'motion','大模型速度段驱动仿真' if preview['arguments'] is not None else '校验阻断 / 保持')
                if not completed:failure='simulation_timeout'
    except Exception as exc:
        failure=type(exc).__name__;print('Stopped: '+failure,flush=True)
    finally:
        if pipeline:pipeline.close()
        if thread.is_alive():server.shutdown();thread.join(timeout=2)
        server.server_close();pool.shutdown(wait=True)
        for p in (sink,rawsink):
            p.stdin.close()
            if p.wait()!=0:failure='video_encoding_failed'
        summary={'simulation_only':True,'completed':completed and failure is None,'failure':failure,
            'contacts':list(world.contacts),'world_balloons':fixed,'world_positions_fixed':tuple(BALLOONS)==fixed,
            'execution_allowed':False,'human_confirmation':'pending','sdk_calls':0,'source_hashes':manifest,'camera':camera,
            'controller':'voice plan -> real multimodal velocity + duration -> stationary revalidation -> validation only (no C servo) -> World.integrate',
            'clock':'advances at 20 Hz including zero-command inference holds; no frozen simulation clock',
            'plan':plan,'voice_turns':turns,'calls':calls,'holds':holds,'frames':frames,
            'limited_frames':sum(bool(f['preview'].get('output_limited')) for f in frames)}
        (out/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    if shots:
        indexes=sorted(set([0,len(shots)//4,len(shots)//2,3*len(shots)//4,max(0,len(shots)-3),len(shots)-1]))
        sheet=Image.new('RGB',(1280,360*math.ceil(len(indexes)/2)),'#09131F')
        for i,j in enumerate(indexes):sheet.paste(shots[j],((i%2)*640,(i//2)*360))
        sheet.save(out/'contact-sheet.jpg')
    print(json.dumps({'completed':summary['completed'],'contacts':world.contacts,'frames':len(frames),'vision_calls':len(calls),
        'holds':len(holds),'output':str(out)},ensure_ascii=False))
    return 0 if summary['completed'] else 1


if __name__=='__main__':sys.exit(main())
