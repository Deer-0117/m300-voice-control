#!/bin/sh
# Read UTC epoch time from the relay through a forced-command SSH key, validate
# its format, and set the embedded device clock for reliable TLS validation.
set -eu

relay_epoch="$(runuser -u uav -- /usr/bin/ssh \
    -o BatchMode=yes \
    -o ConnectTimeout=8 \
    -o StrictHostKeyChecking=yes \
    -o UserKnownHostsFile=/home/uav/.ssh/known_hosts_relay_proxy \
    -i /home/uav/.ssh/code12_relay_time_ed25519 \
    jxf_group@10.18.2.83)"

case "$relay_epoch" in
    ''|*[!0-9]*)
        echo "relay returned an invalid epoch" >&2
        exit 1
        ;;
esac

local_epoch="$(date -u +%s)"
delta=$((relay_epoch - local_epoch))
if [ "$delta" -lt 0 ]; then
    delta=$((-delta))
fi

if [ "$delta" -gt 2 ]; then
    date -u -s "@$relay_epoch" >/dev/null
fi

printf 'relay_epoch=%s local_epoch=%s delta_seconds=%s\n' \
    "$relay_epoch" "$(date -u +%s)" "$delta"
