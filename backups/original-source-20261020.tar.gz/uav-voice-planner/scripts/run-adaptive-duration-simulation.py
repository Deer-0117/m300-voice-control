#!/usr/bin/env python3
"""Continue an already confirmed simulation checkpoint; preserve actual human receipt."""
import base64,copy,hashlib,io,json,math,os,runpy,shutil,subprocess,sys,time
from collections import deque
from concurrent.futures import ThreadPoolExecutor,TimeoutError
from pathlib import Path
from PIL import Image,ImageDraw
from openai import OpenAI
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'runtime'))
from uav_dynamic_world import DynamicWorld,HoverEvidence
from uav_video_feedback import detect_video_frame
from uav_adaptive_segment import AdaptiveSegmentPreview,validate_adaptive
from uav_mission_revision import MissionRevision
from uav_action_feedback import summarize_effects,target_measurement,divergence_guard,FEEDBACK_PROMPT
from uav_visual_memory import history_hint
from uav_model_velocity import SYSTEM
ZERO=dict(x=0.,y=0.,z=0.,yaw=0.)

def main():
    maximum=float(sys.argv[1]) if len(sys.argv)>1 else 3.
    assert maximum in (1.,3.)
    source=ROOT/'local-voice-test/mission-interrupt-20261018-184916'
    record=json.loads((source/'result.json').read_text());frames=record['frames'];events=record['events'];calls=record['calls']
    assert record['contacts']==['red'] and any(e['kind']=='human_confirmed' for e in events)
    cut=next(e['frame'] for e in events if e['kind']=='late_old_response_rejected')+1
    frames=frames[:cut];events=[e for e in events if e['frame']<=cut];calls=[]
    out=ROOT/'local-voice-test'/('adaptive-duration-'+str(int(maximum))+'s-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir()
    print('OUTPUT '+str(out),flush=True)
    for name in ('confirmation.json','confirmation-request.json','visual-memory.json','revision-model-result.json'):
        shutil.copy2(source/name,out/name)
    for pattern in ('memory-*.png',):
        for f in source.glob(pattern):shutil.copy2(f,out/f.name)
    mission=MissionRevision(record['plan']);mission.revision=2;mission.completed=['red']
    req=json.loads((out/'confirmation-request.json').read_text());receipt=json.loads((out/'confirmation.json').read_text())
    mission.status='awaiting_confirmation';mission.token=req['token'];mission.plan_hash=req['plan_hash'];mission.confirm(receipt)
    world=DynamicWorld();recent=deque(maxlen=48)
    def remember(k,im,phase):
        buf=io.BytesIO();im.save(buf,format='PNG')
        recent.append(dict(frame=k,sim_time_s=k/20,phase=phase,png=buf.getvalue(),pose={a:getattr(world,a) for a in ('x','y','z','yaw')},velocity=world.flight_state()['velocity_world_mps']))
    for f in frames:
        if f['frame_index']>=len(frames)-120 and f['frame_index']%5==0:remember(f['frame_index'],world.render(),f['phase'])
        world.integrate(f['command'],.05)
        assert world.flight_state()==f['plant_after']
    start_frame=len(frames);old_contacts=list(world.contacts)
    events.append(dict(kind='adaptive_duration_comparison_start',frame=start_frame,time_s=start_frame/20,revision=2,
                       confirmation_reused_from=str(source/'confirmation.json')))
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    eh=runpy.run_path(str(ROOT/'scripts/run-enhanced-control-simulation.py'));ui=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'))
    ask=ui['ask'];ask.__globals__['OUT']=out
    prompt=SYSTEM.replace('["red","purple"]','["red","green"]').replace('"red" or "purple" or null','"green" or null').replace('"approach"|"hold"|"done"','"approach"|"search_right"|"search_left"|"hold"|"done"')
    prompt=prompt.replace('Prefer 0.5-1s segments when far, 0.1-0.5s near target.','Choose duration from image sequence and actual progress; reduce speed near contact.').replace('offline ideal velocity-following','offline inertial').replace('duration_s<=1.0','duration_s<='+str(maximum)).replace('0.1<=duration_s<=1.0','0.1<=duration_s<='+str(maximum))
    ask.__globals__['SYSTEM']=prompt+FEEDBACK_PROMPT.replace('up to 1 second','up to '+str(maximum)+' seconds')+'''
The human has ALREADY CONFIRMED revision 2 for SIMULATION. Red is completed; purple is canceled; now find and contact green. Do NOT ask for confirmation again. Real hardware is forbidden.
The target field means the intended mission target, NOT a visible detection. For search_right, search_left, hold and approach, target MUST be "green" even when invisible. Only mode done may use target null. When invisible use bbox null and visible [], but keep target "green".
Green may be outside the current image. Use historical images, their timestamps, vehicle poses and estimated bearing to decide the search direction. Historical images are NOT fresh detections. For unseen green, output mode search_right with positive yaw OR search_left with negative yaw, x=y=z=0, duration within configured maximum. NEVER label nonzero yaw as hold. Hold must have every velocity zero. When green is seen, return approach with its CURRENT bbox. Camera/pixels remain available throughout.
Inertia tau .45s, input delay .15s, acceleration1.5m/s2, crosswind unchanged. Use measured actual action effects. Short .1-.3s pulses may produce almost no net motion. When more than 1m away, prefer longer segments within configured maximum, adjust speed and lateral alignment rather than always shortening duration. Only contact telemetry proves completion. Full plan always [red,green].
'''
    ask.__globals__['SYSTEM']+='\nConfigured maximum duration_s='+str(maximum)+'''. You decide duration for EVERY action using the recent time-ordered images, actual measured velocity and previous action effects. When aligned and far, use longer effective segments within the configured limit. Near contact reduce velocity, but avoid repeatedly tiny pulses that do not overcome delay. A clipped image gives no reliable depth. Use recent size growth and executed displacement to reason about remaining approach. Search can rotate for longer until green appears: the local monitor ends it immediately upon reacquisition. The local monitor also aborts target loss, growing error, stale feedback or voice interrupt; it never substitutes velocities. The latest image attached LAST is the ONLY source for the current bbox.'''
    (out/'system-prompt.txt').write_text(ask.__globals__['SYSTEM'])
    sightings=json.loads((out/'visual-memory.json').read_text());memory=[{'type':'text','text':'HISTORICAL GREEN SIGHTINGS. Old images for search orientation only, not current visibility.'}]
    for s in sightings:
        memory.extend([{'type':'text','text':json.dumps(s,ensure_ascii=False)}, {'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode((out/s['image']).read_bytes()).decode()}}])
    memory_message={'role':'user','content':memory};messages=[]
    pipeline=AdaptiveSegmentPreview(mission.plan,2,maximum);seq=len(calls);decision={};prev=frames[-1]['pose_after'];latest=None;vision=None;pose=None
    sink=eh['video_sink'](out/'continuation.mp4',1280,720);raw=eh['video_sink'](out/'continuation-camera.mp4',880,480)
    pool=ThreadPoolExecutor(max_workers=1);completed=False;failure=None
    for name in ('scripts/run-adaptive-duration-simulation.py','runtime/uav_adaptive_segment.py','scripts/run-static-world-vision.py'):
        record['source_hashes'][name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    def tick(c,p,phase,label,evidence=None):
        nonlocal latest,vision,pose,prev
        k=len(frames);now=10000+k*50;latest=world.render();vision=detect_video_frame(latest,now,k);pose,state=eh['telemetry'](world,prev,now)
        if k%5==0:remember(k,latest,phase)
        if evidence:evidence.observe(latest,pose,k,now,c)
        assert mission.permits(2)
        canvas=ui['compose'](world,latest,{d['color_name']:d['bbox_xyxy'] for d in vision['detections']},decision,c,k/20,seq,label,False)
        d=ImageDraw.Draw(canvas);d.rectangle((20,15,1260,100),fill='#09131F');ui['text'](d,(24,20),f'连续画面 + 自适应时长（上限 {maximum:g} 秒）',28)
        ui['text'](d,(24,65),'红色已完成 / 紫色已取消 / 当前只执行绿色 / 仅仿真',18)
        d.rectangle((20,607,1260,717),fill='#09131F')
        ui['text'](d,(24,613),f"{label} | x {c['x']:+.2f} y {c['y']:+.2f} yaw {c['yaw']:+.1f}",20)
        ui['text'](d,(24,653),f'模型指定时长 {decision.get("duration_s",0):.2f} 秒 / 持续视觉监测 / 相同惯性和风场',18)
        ui['text'](d,(24,686),'人工确认已记录（仅仿真） / 新视觉决策预算 100 / 真实 SDK 调用 0',16)
        sink.stdin.write(canvas.tobytes());raw.stdin.write(latest.tobytes())
        if k%100==0:canvas.save(out/'poster.png')
        before=world.flight_state();contacts=list(world.contacts);hits=world.integrate(c,.05)
        assert world.contacts==['red','green'][:len(world.contacts)]
        frames.append(dict(frame_index=k,sim_time_s=k/20,phase=phase,mission_revision=2,mission_status='active',issued_revision=2,
            pose_before=pose,pose_after={key:getattr(world,key) for key in pose},aircraft=state,vision=vision,
            plant_before=before,plant_after=world.flight_state(),model_call=seq,preview=p,command=dict(c),contacts_before=contacts,contacts_this_frame=hits))
        prev=pose
        if hits:
            event=dict(kind='contact',frame=len(frames),time_s=len(frames)/20,revision=2,colors=hits);events.append(event);print('EVENT '+json.dumps(event),flush=True)
    def blocked(reason):return dict(arguments=None,execution_allowed=False,sdk_called=False,human_confirmation='pending',reason=reason)
    def settle():
        stable=0
        for _ in range(240):
            tick(dict(ZERO),blocked('braking'),'hold','制动稳定 / 位置保持')
            stable=stable+1 if float(sum(v*v for v in world.v))**.5<.06 and abs(world.yr)<.3 and not any(world.applied.values()) else 0
            if stable>=10:return
        raise RuntimeError('hover_not_stable')
    try:
        with OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
            for _ in range(2500):
                now=10000+len(frames)*50
                if pipeline.command is None or now>=pipeline.deadline or len(world.contacts)==2:
                    seq+=1
                    if seq>100:
                        settle();raise RuntimeError('visual_call_budget')
                    settle();e=HoverEvidence(latest,pose,vision['frame_id'],vision['target_timestamp_ms']);snap=copy.deepcopy(world)
                    measured=summarize_effects(frames,'green')
                    for effect in measured['recent_action_effects']:
                        a,b=effect['observation_frame_range']
                        if frames[a]['phase']=='revised_motion':
                            effect['target']='green';effect['target_before']=target_measurement(frames[a]['vision'],'green');effect['target_after']=target_measurement(frames[b]['vision'],'green')
                    measured['historical_green_search_hint']=history_hint(sightings,{k:getattr(snap,k) for k in ('x','y','z','yaw')})
                    instruction=json.dumps({'confirmed_plan':['red','green'],'revision':2,'completed':world.contacts,'human_confirmed':True,'simulation_only':True},ensure_ascii=False)
                    selected=list(recent)[::max(1,len(recent)//3)][-3:]
                    temporal=[{'type':'text','text':'RECENT TIME-ORDERED CAMERA FRAMES. Compare motion and target size over time. Latest current image follows separately.'}]
                    refs=[]
                    for sample in selected:
                        filename=f'temporal-{seq:03d}-{sample["frame"]}.png';(out/filename).write_bytes(sample['png'])
                        meta={k:v for k,v in sample.items() if k!='png'};meta['image']=filename;refs.append(meta)
                        temporal.extend([{'type':'text','text':json.dumps(meta)},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(sample['png']).decode()}}])
                    context=[memory_message,*messages[-4:],{'role':'user','content':temporal}]
                    future=pool.submit(ask,client,context,snap,latest.copy(),instruction,seq,len(frames)/20-.05,max_tokens=1800,thinking='disabled',measured_feedback=measured,confirmation='confirmed by human for simulation revision 2; real execution forbidden')
                    while True:
                        started=time.monotonic();tick(dict(ZERO),blocked('analysis_hold'),'hold','真实 API 分析 / 悬停',e)
                        try:decision,call=future.result(timeout=max(.001,.05-(time.monotonic()-started)));break
                        except TimeoutError:
                            if future.done():raise
                    messages.extend(context[-2:]);evidence=e.receipt();call.update(revision=2,hover_evidence=evidence,historical_images=[s['image'] for s in sightings],temporal_images=refs,maximum_duration_s=maximum);calls.append(copy.deepcopy(call))
                    try:validate_adaptive(decision,maximum)
                    except (ValueError,KeyError,TypeError) as exc:
                        pipeline.close();calls[-1]['acceptance_error']='invalid_velocity_mode_or_bounds'
                        messages.append({'role':'user','content':'Rejected: '+str(exc)+'. target MUST be green even when invisible. Only done may use null. Hold requires zero velocity; rotation uses search_right or search_left.'});continue
                    if decision['plan']!=['red','green'] or (len(world.contacts)<2 and decision['target']!='green'):
                        pipeline.close();calls[-1]['acceptance_error']='stale_plan';messages.append({'role':'user','content':'Rejected: target must be "green" even when invisible. For search_right/search_left use target="green", bbox=null, visible=[] and pure yaw. Null target is reserved for done after contact. Full plan is ["red","green"]. Purple canceled.'});continue
                    if world.contacts==['red','green']:
                        if decision['mode']!='done':continue
                        completed=True
                        for _ in range(40):tick(dict(ZERO),blocked('complete'),'complete','红色→绿色几何接触完成')
                        break
                    if not evidence['hover_verified']:
                        pipeline.close();calls[-1]['acceptance_error']='hover_drift';continue
                    error=divergence_guard(decision,measured)
                    if not error:error=pipeline.accept_model(decision,vision,frame_id=vision['frame_id'],image_timestamp_ms=vision['target_timestamp_ms'],received_timestamp_ms=vision['target_timestamp_ms'],sequence=seq)
                    calls[-1]['acceptance_error']=error;messages.append({'role':'user','content':json.dumps({'validation':error})})
                    if error:pipeline.close();continue
                now=10000+len(frames)*50;v=detect_video_frame(world.render(),now,len(frames));_,state=eh['telemetry'](world,prev,now)
                preview=pipeline.step({'now_ms':now,'vision':v,'aircraft':state});tick(preview['arguments'] or dict(ZERO),preview,'revised_motion','已确认 / 模型搜索或接近绿色')
            if not completed:failure='not_completed'
    except KeyboardInterrupt:failure='interrupted'
    except Exception as exc:failure=type(exc).__name__+': '+str(exc);print('ERROR '+failure,flush=True)
    finally:
        pipeline.close();pool.shutdown(wait=True)
        for p in (sink,raw):p.stdin.close();p.wait()
        record.update(maximum_duration_s=maximum,comparison_checkpoint_frame=start_frame,completed=completed,failure=failure,frames=frames,calls=calls,events=events,contacts=list(world.contacts),human_confirmation='active',continuation_source=str(source),continuation_start_frame=start_frame)
        (out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
        for name,old,new in [('closed-loop.mp4','closed-loop.mp4','continuation.mp4'),('camera-input.mp4','camera-input.mp4','continuation-camera.mp4')]:
            prefix=out/('prefix-'+name)
            subprocess.run(['ffmpeg','-v','error','-y','-i',str(source/old),'-frames:v',str(start_frame),'-an','-c:v','libx264','-preset','fast','-crf','20',str(prefix)],check=True)
            listing=out/(name+'.concat');listing.write_text("file '"+str(prefix)+"'\nfile '"+str(out/new)+"'\n")
            subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(out/name)],check=True)
        print('RESULT '+json.dumps({'output':str(out),'completed':completed,'contacts':world.contacts,'new_visual_calls':len(calls)}),flush=True)
if __name__=='__main__':main()
