#!/usr/bin/env python3
"""Continue an already confirmed simulation checkpoint; preserve actual human receipt."""
import base64,copy,hashlib,io,json,math,os,runpy,shutil,subprocess,sys,time
from collections import deque
from concurrent.futures import ThreadPoolExecutor,TimeoutError
from pathlib import Path
from PIL import Image,ImageDraw
from openai import OpenAI
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'runtime'))
from uav_dynamic_world import DynamicWorld,HoverEvidence
from uav_video_feedback import detect_video_frame
from uav_adaptive_segment import AdaptiveSegmentPreview,validate_adaptive
from uav_mission_revision import MissionRevision
from uav_pure_visual_input import feedback,frame_metadata
from uav_pure_visual_strategy import STRATEGY,select_action_frames
from uav_action_feedback import body_vector
from uav_model_velocity import SYSTEM
ZERO=dict(x=0.,y=0.,z=0.,yaw=0.)

def main():
    maximum=float(sys.argv[1]) if len(sys.argv)>1 else 3.
    assert maximum in (1.,3.)
    source=ROOT/'local-voice-test/mission-interrupt-20261018-184916'
    record=json.loads((source/'result.json').read_text());frames=record['frames'];events=record['events'];calls=record['calls']
    assert record['contacts']==['red'] and any(e['kind']=='human_confirmed' for e in events)
    cut=next(e['frame'] for e in events if e['kind']=='late_old_response_rejected')+1
    frames=frames[:cut];events=[e for e in events if e['frame']<=cut];calls=[]
    out=ROOT/'local-voice-test'/('pure-visual-improved-'+str(int(maximum))+'s-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir()
    print('OUTPUT '+str(out),flush=True)
    for name in ('confirmation.json','confirmation-request.json','visual-memory.json','revision-model-result.json'):
        shutil.copy2(source/name,out/name)
    for pattern in ('memory-*.png',):
        for f in source.glob(pattern):shutil.copy2(f,out/f.name)
    mission=MissionRevision(record['plan']);mission.revision=2;mission.completed=['red']
    req=json.loads((out/'confirmation-request.json').read_text());receipt=json.loads((out/'confirmation.json').read_text())
    mission.status='awaiting_confirmation';mission.token=req['token'];mission.plan_hash=req['plan_hash'];mission.confirm(receipt)
    world=DynamicWorld();recent=deque(maxlen=48)
    history=json.loads((out/'visual-memory.json').read_text())
    def remember(k,im,phase):
        buf=io.BytesIO();im.save(buf,format='PNG')
        recent.append(dict(frame=k,sim_time_s=k/20,phase=phase,png=buf.getvalue(),pose={a:getattr(world,a) for a in ('x','y','z','yaw')},velocity=world.flight_state()['velocity_world_mps']))
    for f in frames:
        if f['frame_index']>=len(frames)-120 and f['frame_index']%5==0:remember(f['frame_index'],world.render(),f['phase'])
        world.integrate(f['command'],.05)
        assert world.flight_state()==f['plant_after']
    start_frame=len(frames);old_contacts=list(world.contacts)
    events.append(dict(kind='adaptive_duration_comparison_start',frame=start_frame,time_s=start_frame/20,revision=2,
                       confirmation_reused_from=str(source/'confirmation.json')))
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    eh=runpy.run_path(str(ROOT/'scripts/run-enhanced-control-simulation.py'));ui=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'))
    ask=ui['ask'];ask.__globals__['OUT']=out
    prompt=SYSTEM.replace('["red","purple"]','["red","green"]').replace('"red" or "purple" or null','"green" or null').replace('"approach"|"hold"|"done"','"approach"|"search_right"|"search_left"|"hold"|"done"')
    prompt=prompt.replace('Prefer 0.5-1s segments when far, 0.1-0.5s near target.','Choose duration from image sequence and actual progress; reduce speed near contact.').replace('offline ideal velocity-following','offline inertial').replace('duration_s<=1.0','duration_s<='+str(maximum)).replace('0.1<=duration_s<=1.0','0.1<=duration_s<='+str(maximum))
    pure_system=prompt+"""
The human already confirmed revision 2 for simulation only: red completed, purple canceled, now green. Keep full plan [red,green]. target MUST be green in approach/search/hold even when invisible; null is only for done. No hardware connected.
You receive raw camera images, measured velocity and past executed actions. No local detections, boxes, visual range, target bearing, target coordinates, wind estimate or vehicle position are supplied. Infer all visual information yourself from pixels. Historical images are labeled as earlier green sightings at the user's request. No local boxes, bearing, range or pose accompanies them. Remember what YOU see in these images. Historical images cannot serve as a current bbox.
For unseen target, choose pure rotation search_right (positive yaw) or search_left (negative yaw), x=y=z=0. When seen, approach using a bbox you identify from the LAST current image. Never use nonzero velocity in hold/done.
The same inertial dynamics apply: velocity tau .45s, input delay .15s, acceleration limit1.5m/s2. You choose duration using image sequence, actual measured velocity and previous actions. Prefer effective longer actions within configured maximum when aligned and distant. Reduce speed near contact rather than repeatedly using tiny pulses. Only contact telemetry proves contact. Local monitors may stop an unsafe action but never supply replacement velocity. During model analysis the simulator brakes and holds while camera continues.
"""+'\nMaximum duration_s='+str(maximum)
    pure_system+=STRATEGY
    (out/'system-prompt.txt').write_text(pure_system)
    sightings=history;memory=[{'type':'text','text':'HISTORICAL GREEN SIGHTINGS / 历史绿色画面. These are earlier images, not evidence of current visibility. No local boxes, bearing, distance or pose supplied.'}]
    for item in history:
        memory.extend([{'type':'text','text':json.dumps({'frame':item['frame_index'],'sim_time_s':item['frame_index']/20})},
                       {'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode((out/item['image']).read_bytes()).decode()}}])
    memory_message={'role':'user','content':memory};messages=[]
    def ask(client,context,snap,image,instruction,seq,simtime,**options):
        image.save(out/f'input-{seq:02d}.png');buf=io.BytesIO();image.save(buf,format='PNG')
        payload=dict(instruction=json.loads(instruction),sim_time_s=round(simtime,2),
                     simulator_contact_events=list(snap.contacts),measured_feedback=options['measured_feedback'])
        user={'role':'user','content':[{'type':'text','text':json.dumps(payload,ensure_ascii=False)},
              {'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()}}]}
        outbound=[{'role':'system','content':pure_system},*context,user]
        audit=copy.deepcopy(outbound)
        for msg in audit:
            if isinstance(msg['content'],list):
                for part in msg['content']:
                    if part['type']=='image_url':
                        data=base64.b64decode(part['image_url']['url'].split(',',1)[1]);part['image_url']={'sha256':hashlib.sha256(data).hexdigest()}
        (out/f'outbound-{seq:02d}.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
        started=time.monotonic()
        response=client.chat.completions.create(model=os.environ['OPENAI_CHAT_MODEL_ID'],messages=outbound,response_format={'type':'json_object'},max_tokens=1800,temperature=0,extra_body={'thinking':{'type':'disabled'}})
        raw=response.choices[0].message.content;decision=json.loads(raw)
        call=dict(request=payload,image=f'input-{seq:02d}.png',response=decision,response_id=response.id,returned_model=response.model,wall_seconds=round(time.monotonic()-started,2))
        (out/f'raw-{seq:02d}.json').write_text(json.dumps({'content':raw,'finish_reason':response.choices[0].finish_reason},ensure_ascii=False))
        (out/f'call-{seq:02d}.json').write_text(json.dumps(call,ensure_ascii=False,indent=2))
        context.extend([user,{'role':'assistant','content':raw}]);print(json.dumps({'call':seq,'sim_s':simtime,**decision},ensure_ascii=False),flush=True)
        return decision,call
    pipeline=AdaptiveSegmentPreview(mission.plan,2,maximum);seq=len(calls);decision={};prev=frames[-1]['pose_after'];latest=None;vision=None;pose=None
    sink=eh['video_sink'](out/'continuation.mp4',1280,720);raw=eh['video_sink'](out/'continuation-camera.mp4',880,480)
    pool=ThreadPoolExecutor(max_workers=1);completed=False;failure=None
    for name in ('scripts/run-improved-pure-visual-simulation.py','runtime/uav_pure_visual_strategy.py','runtime/uav_pure_visual_input.py','runtime/uav_adaptive_segment.py','scripts/run-static-world-vision.py'):
        record['source_hashes'][name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    def tick(c,p,phase,label,evidence=None):
        nonlocal latest,vision,pose,prev
        k=len(frames);now=10000+k*50;latest=world.render();vision=detect_video_frame(latest,now,k);pose,state=eh['telemetry'](world,prev,now)
        if k%5==0:remember(k,latest,phase)
        if evidence:evidence.observe(latest,pose,k,now,c)
        assert mission.permits(2)
        canvas=ui['compose'](world,latest,{d['color_name']:d['bbox_xyxy'] for d in vision['detections']},decision,c,k/20,seq,label,False)
        d=ImageDraw.Draw(canvas);d.rectangle((20,15,1260,100),fill='#09131F');ui['text'](d,(24,20),f'改进纯视觉 · 偏移补偿与动作时长（上限 {maximum:g} 秒）',28)
        ui['text'](d,(24,65),'红色已完成 / 紫色已取消 / 当前只执行绿色 / 仅仿真',18)
        d.rectangle((20,607,1260,717),fill='#09131F')
        ui['text'](d,(24,613),f"{label} | x {c['x']:+.2f} y {c['y']:+.2f} yaw {c['yaw']:+.1f}",20)
        ui['text'](d,(24,653),f'模型指定 {decision.get("duration_s",0):.2f} 秒 / 未提供本地检测框、颜色、方位',18)
        ui['text'](d,(24,686),'人工确认已记录（仅仿真） / 新视觉决策预算 100 / 真实 SDK 调用 0',16)
        sink.stdin.write(canvas.tobytes());raw.stdin.write(latest.tobytes())
        if k%100==0:canvas.save(out/'poster.png')
        before=world.flight_state();contacts=list(world.contacts);hits=world.integrate(c,.05)
        assert world.contacts==['red','green'][:len(world.contacts)]
        frames.append(dict(frame_index=k,sim_time_s=k/20,phase=phase,mission_revision=2,mission_status='active',issued_revision=2,
            pose_before=pose,pose_after={key:getattr(world,key) for key in pose},aircraft=state,vision=vision,
            plant_before=before,plant_after=world.flight_state(),model_call=seq,preview=p,command=dict(c),contacts_before=contacts,contacts_this_frame=hits))
        prev=pose
        if hits:
            event=dict(kind='contact',frame=len(frames),time_s=len(frames)/20,revision=2,colors=hits);events.append(event);print('EVENT '+json.dumps(event),flush=True)
    def blocked(reason):return dict(arguments=None,execution_allowed=False,sdk_called=False,human_confirmation='pending',reason=reason)
    def settle():
        stable=0
        for _ in range(240):
            tick(dict(ZERO),blocked('braking'),'hold','制动稳定 / 位置保持')
            stable=stable+1 if float(sum(v*v for v in world.v))**.5<.06 and abs(world.yr)<.3 and not any(world.applied.values()) else 0
            if stable>=10:return
        raise RuntimeError('hover_not_stable')
    try:
        with OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
            for _ in range(2500):
                now=10000+len(frames)*50
                if pipeline.command is None or now>=pipeline.deadline or len(world.contacts)==2:
                    seq+=1
                    if seq>100:
                        settle();raise RuntimeError('visual_call_budget')
                    settle();e=HoverEvidence(latest,pose,vision['frame_id'],vision['target_timestamp_ms']);snap=copy.deepcopy(world)
                    measured=feedback(frames)
                    instruction=json.dumps({'confirmed_plan':['red','green'],'revision':2,'completed':world.contacts,'human_confirmed':True,'simulation_only':True},ensure_ascii=False)
                    selected=select_action_frames(recent)
                    temporal=[{'type':'text','text':'RECENT TIME-ORDERED CAMERA FRAMES. Compare motion and target size over time. Latest current image follows separately.'}]
                    refs=[]
                    for sample in selected:
                        filename=f'temporal-{seq:03d}-{sample["frame"]}.png';(out/filename).write_bytes(sample['png'])
                        meta={k:v for k,v in sample.items() if k!='png'};meta['image']=filename;refs.append(meta)
                        temporal.extend([{'type':'text','text':json.dumps(frame_metadata(meta))},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(sample['png']).decode()}}])
                    context=[memory_message,*messages[-4:],{'role':'user','content':temporal}]
                    future=pool.submit(ask,client,context,snap,latest.copy(),instruction,seq,len(frames)/20-.05,max_tokens=1800,thinking='disabled',measured_feedback=measured,confirmation='confirmed by human for simulation revision 2; real execution forbidden')
                    while True:
                        started=time.monotonic();tick(dict(ZERO),blocked('analysis_hold'),'hold','真实 API 分析 / 悬停',e)
                        try:decision,call=future.result(timeout=max(.001,.05-(time.monotonic()-started)));break
                        except TimeoutError:
                            if future.done():raise
                    messages.extend(context[-2:]);evidence=e.receipt();call.update(revision=2,hover_evidence=evidence,historical_images=[s['image'] for s in sightings],temporal_images=refs,maximum_duration_s=maximum);calls.append(copy.deepcopy(call))
                    try:validate_adaptive(decision,maximum)
                    except (ValueError,KeyError,TypeError) as exc:
                        pipeline.close();calls[-1]['acceptance_error']='invalid_velocity_mode_or_bounds'
                        messages.append({'role':'user','content':'Rejected: '+str(exc)+'. target MUST be green even when invisible. Only done may use null. Hold requires zero velocity; rotation uses search_right or search_left.'});continue
                    if decision['plan']!=['red','green'] or (len(world.contacts)<2 and decision['target']!='green'):
                        pipeline.close();calls[-1]['acceptance_error']='stale_plan';messages.append({'role':'user','content':'Rejected: target must be "green" even when invisible. For search_right/search_left use target="green", bbox=null, visible=[] and pure yaw. Null target is reserved for done after contact. Full plan is ["red","green"]. Purple canceled.'});continue
                    if world.contacts==['red','green']:
                        if decision['mode']!='done':continue
                        completed=True
                        for _ in range(40):tick(dict(ZERO),blocked('complete'),'complete','红色→绿色几何接触完成')
                        break
                    if not evidence['hover_verified']:
                        pipeline.close();calls[-1]['acceptance_error']='hover_drift';continue
                    error=pipeline.accept_model(decision,vision,frame_id=vision['frame_id'],image_timestamp_ms=vision['target_timestamp_ms'],received_timestamp_ms=vision['target_timestamp_ms'],sequence=seq)
                    calls[-1]['acceptance_error']=error;messages.append({'role':'user','content':json.dumps({'action_executed':error is None})})
                    if error:pipeline.close();continue
                now=10000+len(frames)*50;v=detect_video_frame(world.render(),now,len(frames));_,state=eh['telemetry'](world,prev,now)
                preview=pipeline.step({'now_ms':now,'vision':v,'aircraft':state});tick(preview['arguments'] or dict(ZERO),preview,'revised_motion','已确认 / 模型搜索或接近绿色')
            if not completed:failure='not_completed'
    except KeyboardInterrupt:failure='interrupted'
    except Exception as exc:failure=type(exc).__name__+': '+str(exc);print('ERROR '+failure,flush=True)
    finally:
        pipeline.close();pool.shutdown(wait=True)
        for p in (sink,raw):p.stdin.close();p.wait()
        record.update(strategy='self_visual_alignment_and_action_bracketing',input_mode='raw_images_velocity_actions_only',historical_sampling='retained_green_sightings_label_as_user_requested',maximum_duration_s=maximum,comparison_checkpoint_frame=start_frame,completed=completed,failure=failure,frames=frames,calls=calls,events=events,contacts=list(world.contacts),human_confirmation='active',continuation_source=str(source),continuation_start_frame=start_frame)
        (out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');(out/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
        for name,old,new in [('closed-loop.mp4','closed-loop.mp4','continuation.mp4'),('camera-input.mp4','camera-input.mp4','continuation-camera.mp4')]:
            prefix=out/('prefix-'+name)
            subprocess.run(['ffmpeg','-v','error','-y','-i',str(source/old),'-frames:v',str(start_frame),'-an','-c:v','libx264','-preset','fast','-crf','20',str(prefix)],check=True)
            listing=out/(name+'.concat');listing.write_text("file '"+str(prefix)+"'\nfile '"+str(out/new)+"'\n")
            subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(out/name)],check=True)
        print('RESULT '+json.dumps({'output':str(out),'completed':completed,'contacts':world.contacts,'new_visual_calls':len(calls)}),flush=True)
if __name__=='__main__':main()
