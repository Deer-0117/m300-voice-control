#!/usr/bin/env python3
"""Offline vision/telemetry replay. Builds core C code only; never links DJI SDK."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'runtime'))
from uav_feedback_preview import FeedbackPreview
from uav_dji_preview import MODE


def build(output):
    output.mkdir(parents=True, exist_ok=True)
    library = output / 'libfeedback_preview.so'
    subprocess.run(['cc', '-shared', '-fPIC', '-O2', '-std=c99',
                    str(ROOT / 'src/target_chase/target_chase.c'),
                    str(ROOT / 'src/target_chase/preview_bridge.c'), '-lm', '-o', str(library)], check=True)
    return library.resolve()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--feedback', type=Path, default=ROOT / 'tests/fixtures/feedback-preview.json')
    p.add_argument('--plans', type=Path, default=ROOT / 'local-planner-test/two-turn-result.json')
    p.add_argument('--output', type=Path, default=ROOT / 'local-planner-test/feedback-preview')
    args = p.parse_args()
    library = build(args.output)
    fixture = json.loads(args.feedback.read_text())
    plans = json.loads(args.plans.read_text())
    report = dict(execution_allowed=False, human_confirmation='pending', aircraft_access=False,
                  input_provenance=fixture['provenance'], camera=fixture['camera'], joystick_mode=MODE,
                  caveat='Independent action replays; no automatic mission progression or hit verification.', runs=[])
    for turn in ('first', 'second'):
        for index in (1, 2):
            preview = FeedbackPreview(library, plans[turn]['plan'], fixture['camera'], index)
            try:
                events = [dict(label=f['label'], **preview.step(f)) for f in fixture['frames']]
            finally:
                preview.close()
            report['runs'].append(dict(turn=turn, action_index=index, events=events))
            for e in events:
                print(turn, index, e['label'], e.get('reason', e.get('arguments')))
    (args.output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(args.output / 'result.json')


if __name__ == '__main__':
    main()
