#!/usr/bin/env python3
"""Render an offline, scripted UAV vision demo and controller-feedback trace."""
import json
import math
from pathlib import Path
import runpy
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'runtime'))
from uav_feedback_preview import FeedbackPreview

OUT = ROOT / 'local-planner-test/vision-video'
W, H, FPS, SECONDS = 1280, 720, 24, 24
from uav_paths import chinese_font
fonts = {n: chinese_font(n) for n in (16,18,20,22,26,32)}
COLORS = {'red':(239,78,89), 'green':(62,209,145), 'purple':(178,117,249)}


def text(draw, xy, value, size=20, fill='#EAF3FA'):
    draw.text(xy, value, font=fonts[size], fill=fill)


def balloon(draw, x, y, radius, color):
    for r in range(int(radius), 0, -2):
        k=1-r/radius
        rgb=tuple(int(v*(0.68+0.32*k)) for v in COLORS[color])
        draw.ellipse((x-r,y-r*1.2,x+r,y+r*1.2), fill=rgb)
    draw.ellipse((x-radius*.40,y-radius*.65,x-radius*.08,y-radius*.22),fill=tuple(min(255,int(c*.6+102)) for c in COLORS[color]))
    draw.polygon([(x-5,y+radius*1.18),(x+5,y+radius*1.18),(x,y+radius*1.32)],fill=COLORS[color])
    points=[(x+math.sin(i*.6)*4,y+radius*1.32+i*6) for i in range(12)]
    draw.line(points, fill='#9EABB8', width=1)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    lib=runpy.run_path(str(ROOT/'scripts/demo-feedback-preview.py'))['build'](OUT)
    plan=json.loads((ROOT/'local-planner-test/two-turn-result.json').read_text())['second']['plan']
    camera={'width':880,'height':480,'hfov_deg':73.7,'vfov_deg':45.7}
    controllers={i:FeedbackPreview(lib,plan,camera,i) for i in (1,2)}
    trace=[]; thumbs=[]
    output=OUT/'uav-vision-simulation.mp4'
    proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(output)],stdin=subprocess.PIPE)
    try:
        for frame_id in range(FPS*SECONDS):
            t=frame_id/FPS; now=10000+round(t*1000)
            index=1 if t<15 else 2
            color='red' if index==1 else 'purple'
            phase=0 if t<5 else 1 if t<9 else 2 if t<15 else 3 if t<20 else 4
            phase_titles=['01  识别目标与任务顺序','02  保留上下文，修改第二步','03  红色目标 · 跟踪参数预览','04  紫色目标 · 独立动作预览','05  视觉过期 · 阻断控制预览']
            local=(t-9)/6 if phase==2 else ((t-15)/5 if phase>=3 else t/9)
            progress=max(0,min(1,local))
            x=625-185*progress; y=235-15*progress
            radius=28+26*progress if phase in (2,3,4) else 30
            positions={'red':(180,180,32),'green':(280,310,30),'purple':(740,150,30)}
            positions[color]=(x,y,radius)
            stale=phase==4
            detections=[{'class_name':'balloon','color_name':c,'confidence':.94,'bbox_xyxy':[px-r,py-r*1.2,px+r,py+r*1.2]} for c,(px,py,r) in positions.items()]
            feedback={'now_ms':now,'camera_boresight_deg':[0,0],
                      'aircraft':{'timestamp_ms':now,'altitude_agl_m':10,'velocity_neu_mps':[0,0,0],'attitude_deg':[0,0,0],'angular_rate_radps':[0,0,0],'in_air':True,'velocity_healthy':True,'has_authority':True},
                      'vision':{'ok':True,'width':880,'height':480,'target_timestamp_ms':now-100 if not stale else 29000,'detections':detections}}
            result=controllers[index].step(feedback)
            trace.append({'video_time_s':round(t,3),'scripted_action_index':index,'feedback':feedback,'preview':result})
            im=Image.new('RGB',(W,H),'#09111D'); d=ImageDraw.Draw(im)
            text(d,(28,21),'无人机视觉与控制预览',32)
            d.rounded_rectangle((915,18,1252,58),radius=8,fill='#2B2436')
            text(d,(932,27),'SIMULATION  /  未连接无人机',18, '#F1C28F')
            text(d,(28,78),phase_titles[phase],22,'#83DBED')
            # Schematic camera image. It is scripted animation, not a physics simulation.
            scene=Image.new('RGB',(880,480)); sd=ImageDraw.Draw(scene)
            for row in range(480):
                if row<270: rgb=(int(25+row*.045),int(44+row*.065),int(67+row*.085))
                else: rgb=(27+int((row-270)*.035),43+int((row-270)*.025),49+int((row-270)*.025))
                sd.line((0,row,879,row),fill=rgb)
            sd.line((0,270,880,270),fill='#4A6578')
            for bx in range(-600,1600,100): sd.line((440,270,bx,480),fill='#30444F')
            for gy in (287,311,347,399,466): sd.line((0,gy,880,gy),fill='#30444F')
            for c,(px,py,r) in positions.items():
                balloon(sd,px,py,r,c)
                b=(px-r-7,py-r*1.2-7,px+r+7,py+r*1.2+7)
                active=c==color
                outline='#FFB663' if stale and active else ('#72E6DA' if active else '#657B8E')
                sd.rectangle(b,outline=outline,width=3 if active else 1)
                label=f'{c.upper()}  0.94' + ('  TARGET' if active else '')
                sd.rectangle((b[0],b[1]-25,b[0]+185,b[1]),fill='#122536')
                text(sd,(b[0]+4,b[1]-23),label,16,outline)
            sd.line((420,240,460,240),fill='#C8DFEB',width=1);sd.line((440,220,440,260),fill='#C8DFEB',width=1)
            sd.ellipse((431,231,449,249),outline='#C8DFEB')
            if not stale: sd.line((440,240,x,y),fill='#72E6DA',width=1)
            text(sd,(16,15),'合成相机画面  |  合成检测框',18,'#DBE8EF')
            text(sd,(16,447),'帧龄 '+('> 800 ms · 已过期' if stale else '100 ms')+'   /   880 × 480',18,'#FFB663' if stale else '#C0D4DE')
            im.paste(scene,(24,120)); d=ImageDraw.Draw(im)
            d.rounded_rectangle((924,120,1256,600),radius=12,fill='#121F30')
            text(d,(944,138),'任务候选 · 待人工确认',22)
            text(d,(944,181),'1  红色 → 粉组',22,'#FA9FA6')
            text(d,(944,218),'2  '+('绿色 → 黄组' if t<5 else '紫色 → 蓝组'),22,'#80E4B4' if t<5 else '#CAA5FF')
            d.line((944,257,1234,257),fill='#344356')
            text(d,(944,274),'飞行状态（合成）',20,'#9CB4C9')
            text(d,(944,310),'高度 10.0 m    姿态 0°',18)
            text(d,(944,342),'空中 / 有控制权（假设）',18)
            text(d,(944,383),'PSDK 参数预览',20,'#9CB4C9')
            cmd=result['arguments']
            if cmd:
                text(d,(944,420),f"x {cmd['x']:+.3f}   y {cmd['y']:+.3f} m/s",18,'#80E7D8')
                text(d,(944,452),f"z {cmd['z']:+.3f} m/s",18,'#80E7D8')
                text(d,(944,484),f"yaw {cmd['yaw']:+.2f} deg/s",18,'#80E7D8')
            else:
                text(d,(944,425),'BLOCKED · 视觉数据过期',18,'#FFB663')
                text(d,(944,461),'不生成控制调用',20,'#FFB663')
            text(d,(944,548),'实际发送：0    SDK 调用：0',18,'#B9C9D7')
            subtitles=['语音：先撞红色气球，再撞绿色气球','语音：把第二个改成紫色 → 保留第一步红色','框位置与大小 → 已有 C 跟踪控制器 → 参数预览','切换到第二动作的独立演示；不代表第一步已撞击完成','目标数据过期，清除预测历史，阻断后续控制预览']
            text(d,(28,620),subtitles[phase],22)
            text(d,(28,660),'脚本动画 / 非物理仿真 · 未运行图像识别模型 · 未执行人工确认或真实飞控',18,'#94AABE')
            d.rectangle((24,704,1256,709),fill='#26374B');d.rectangle((24,704,24+1232*t/SECONDS,709),fill='#65D9D0')
            proc.stdin.write(im.tobytes())
            if frame_id in (48,168,288,408,528):
                thumbs.append(im.resize((640,360)))
            if frame_id==288: im.save(OUT/'poster.png')
        proc.stdin.close()
        if proc.wait()!=0: raise RuntimeError('ffmpeg encoding failed')
    finally:
        for c in controllers.values(): c.close()
        if proc.poll() is None: proc.kill(); proc.wait()
    (OUT/'frame-trace.json').write_text(json.dumps({'provenance':'scripted synthetic visual/telemetry inputs; C controller output; no physics or inference','execution_allowed':False,'frames':trace},ensure_ascii=False))
    contact=Image.new('RGB',(1280,1080),'#09111D')
    for i,thumb in enumerate(thumbs):contact.paste(thumb,((i%2)*640,(i//2)*360))
    contact.save(OUT/'contact-sheet.jpg')
    print(output)


if __name__=='__main__':main()
