#!/usr/bin/env python3
import json,hashlib,runpy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'runtime'))
from uav_pure_visual_input import feedback

def verify(path):
    runpy.run_path(str(ROOT/'scripts/compare-adaptive-duration.py'))['audit'](path)
    r=json.loads((path/'result.json').read_text());assert r['historical_sampling']=='retained_green_sightings_label_as_user_requested'
    image_hashes={hashlib.sha256(p.read_bytes()).hexdigest() for pattern in ('memory-*.png','input-*.png','temporal-*.png') for p in path.glob(pattern)}
    forbidden={'bbox','bbox_xyxy','measurement','target_side','historical_green_search_hint','current_target','target_before','target_after','bearing_right_deg','estimated_depth_m','pose','wind_body_mps','dynamic_flight_state','aircraft_state','detections'}
    def payload_check(value):
        if isinstance(value,dict):
            assert not (set(value)&forbidden),set(value)&forbidden
            for item in value.values():payload_check(item)
        elif isinstance(value,list):
            for item in value:payload_check(item)
    texts=images=0
    for seq,c in enumerate(r['calls'],1):
        assert set(c['request'])=={'instruction','sim_time_s','simulator_contact_events','measured_feedback'}
        idx=round(c['request']['sim_time_s']*20)
        assert c['request']['measured_feedback']==feedback(r['frames'][:idx+1])
        outbound=json.loads((path/f'outbound-{seq:02d}.json').read_text())
        assert outbound[0]['content']==(path/'system-prompt.txt').read_text()
        assert any('HISTORICAL GREEN SIGHTINGS' in str(m['content']) for m in outbound)
        for msg in outbound:
            if msg['role']!='user':continue # model's own inferred boxes are permitted history
            parts=msg['content'] if isinstance(msg['content'],list) else [{'type':'text','text':msg['content']}]
            for part in parts:
                if part['type']=='image_url':
                    assert part['image_url']['sha256'] in image_hashes;images+=1
                else:
                    texts+=1;t=part['text']
                    if t.startswith('{'):
                        obj=json.loads(t);payload_check(obj)
                        assert set(obj) in ({'frame','sim_time_s'},{'frame','sim_time_s','velocity'},{'instruction','sim_time_s','simulator_contact_events','measured_feedback'},{'action_executed'})
                    else:
                        assert t.startswith(('HISTORICAL GREEN SIGHTINGS','RECENT TIME-ORDERED CAMERA FRAMES','Rejected:'))
    result={'verified':True,'requests':len(r['calls']),'user_text_blocks_checked':texts,'image_blocks_checked':images,'historical_green_label_retained':True,'local_detection_boxes_bearings_ranges_sent':False,'nonvisual_task_confirmation_contact_events_retained':True,'model_own_prior_visual_predictions_retained':True,'local_monitors_still_active':True}
    (path/'input-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':verify(Path(sys.argv[1]).resolve())
