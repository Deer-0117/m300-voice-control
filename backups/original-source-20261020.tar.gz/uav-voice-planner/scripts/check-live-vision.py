#!/usr/bin/env python3
"""Isolated image-only capability probe. No drone or simulation controls."""
import base64,io,json,os,random,runpy,secrets,time
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from openai import OpenAI
ROOT=Path(__file__).resolve().parents[1]

def main():
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    out=ROOT/'local-voice-test'/('vision-capability-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir()
    rng=random.SystemRandom();items=[('red','circle'),('green','square'),('blue','triangle')];rng.shuffle(items)
    prompt='Inspect this image. Return JSON only: {"objects_left_to_right":[{"color":"English color name","shape":"circle/square/triangle"}],"code":"digits shown in image"}. Read actual pixels; do not guess from prior context.'
    report={'base_url':os.environ['OPENAI_BASE_URL'],'requested_model':os.environ['OPENAI_CHAT_MODEL_ID'],'test':'same text prompt, two different image-only inputs; no telemetry, detector, expected answer or conversation history supplied','cases':[],'sdk_calls':0}
    with OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
        for i,order in enumerate((items,list(reversed(items))),1):
            code=''.join(secrets.choice('0123456789') for _ in range(6));im=Image.new('RGB',(720,320),'white');d=ImageDraw.Draw(im)
            for j,(color,shape) in enumerate(order):
                x=40+j*240
                if shape=='circle':d.ellipse((x,35,x+150,185),fill=color)
                elif shape=='square':d.rectangle((x,35,x+150,185),fill=color)
                else:d.polygon([(x+75,35),(x,185),(x+150,185)],fill=color)
            d.text((180,240),code,font=ImageFont.load_default(size=48),fill='black')
            imagepath=out/f'probe-{i}.png';im.save(imagepath)
            response=client.chat.completions.create(model=report['requested_model'],messages=[{'role':'user','content':[{'type':'text','text':prompt},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(imagepath.read_bytes()).decode()}}]}],response_format={'type':'json_object'},max_tokens=500,temperature=0,extra_body={'thinking':{'type':'disabled'}})
            answer=json.loads(response.choices[0].message.content)
            expected={'objects_left_to_right':[{'color':c,'shape':s} for c,s in order],'code':code}
            row={'image':imagepath.name,'expected':expected,'response':answer,'matches':answer==expected,'response_id':response.id,'returned_model':response.model,'usage':response.usage.model_dump() if response.usage else None}
            report['cases'].append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
    report['all_passed']=all(c['matches'] for c in report['cases']);(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('RESULT '+str(out/'result.json'),flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:print('Probe failed: '+type(e).__name__);raise SystemExit(1)
