#!/bin/sh
# Rotate runtime JSONL files above 20 MiB and PSDK logs above 50 MiB.
# Writers reopen JSONL files for each event, while the active PSDK log is
# copied and truncated in place so its open file descriptor remains valid.
set -eu

DATA_DIR=/home/uav/offline_balloon_strike_test
LOG_DIR=/home/uav/yanshou_uav/uavs_psdk/psdk_dji_3.9.2_cpp_json/samples/sample_c++/platform/linux/manifold2/build_cpp_json_minimal_c_linux/bin/Logs
JSON_LIMIT_BYTES=20971520
PSDK_LIMIT_BYTES=52428800
stamp=$(date +%Y%m%d_%H%M%S)

for file in "$DATA_DIR"/*.jsonl; do
    [ -f "$file" ] || continue
    size=$(stat -c %s "$file")
    [ "$size" -gt "$JSON_LIMIT_BYTES" ] || continue
    rotated="${file%.jsonl}.${stamp}.jsonl"
    mv "$file" "$rotated"
    # A writer may recreate the active path immediately after mv. touch keeps
    # any event written in that window, whereas truncation would lose it.
    touch "$file"
    chown --reference="$rotated" "$file"
    chmod --reference="$rotated" "$file"
    gzip -f "$rotated"
done

current=$(readlink -f "$LOG_DIR/latest.log" 2>/dev/null || true)
if [ -n "$current" ] && [ -f "$current" ]; then
    size=$(stat -c %s "$current")
    if [ "$size" -gt "$PSDK_LIMIT_BYTES" ]; then
        rotated="${current}.rotated_${stamp}"
        cp -p "$current" "$rotated"
        truncate -s 0 "$current"
        gzip -f "$rotated"
    fi
fi

for file in "$LOG_DIR"/DJI_*.log; do
    [ -f "$file" ] || continue
    [ "$file" != "$current" ] || continue
    size=$(stat -c %s "$file")
    [ "$size" -gt "$PSDK_LIMIT_BYTES" ] || continue
    gzip -f "$file"
done
