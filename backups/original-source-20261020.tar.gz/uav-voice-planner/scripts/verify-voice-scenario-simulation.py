#!/usr/bin/env python3
import json,sys,hashlib,math
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'runtime'))
from uav_dynamic_world import DynamicWorld,PARAMETERS
from uav_static_world_sim import BALLOONS
from uav_ground_world import GroundWorld
from uav_takeoff_preview import check_vertical_consistency
from uav_pure_visual_input import feedback
from uav_model_visual_consistency import check_self_consistency

def audit(path):
    r=json.loads((path/'result.json').read_text());assert r['replay_frames']==0 and r['fresh_initial_state']
    assert r['dynamics_parameters']==PARAMETERS and r['world_balloons']==[list(b) for b in BALLOONS]
    assert r['sdk_calls']==0 and not r['real_execution_allowed']
    assert all(hashlib.sha256((ROOT/s).read_bytes()).hexdigest()==h for s,h in r['source_hashes'].items())
    assert r['ground_start'] and r['frames'][0]['pose_before']['z']==0
    events={e['kind']:e for e in r['events']};interrupt=events.get('voice_interrupt');confirm=events.get('human_confirmed')
    w=GroundWorld();movement=Counter();motion_calls=set();contacts=[];zero_wait=0
    for i,f in enumerate(r['frames']):
        assert f['frame_index']==i and f['vision']['frame_id']==i and f['vision']['target_timestamp_ms']==10000+i*50
        assert w.flight_state()==f['plant_before'];c=f['command']
        if f['preview'].get('arguments') is not None:
            assert f['phase']=='revised_motion' and f['mission_status']=='active' and f['issued_revision']==f['mission_revision']
            call=r['calls'][f['model_call']-1];d=call['response'];assert c==d['velocity']==f['preview']['arguments']
            assert call['revision']==f['mission_revision'] and call['response_id'] and call['hover_evidence']['hover_verified']
            assert check_self_consistency(d) is None and check_vertical_consistency(d) is None
            movement[d['target']]+=1;motion_calls.add(f['model_call'])
        else:assert not any(c.values())
        if interrupt and i>=interrupt['frame'] and (not confirm or i<confirm['frame']):assert not any(c.values());zero_wait+=1
        if f['mission_status']=='paused':assert not any(c.values())
        hits=w.integrate(c,.05);assert hits==f['contacts_this_frame'] and w.flight_state()==f['plant_after']
        if hits:contacts.append({'time_s':(i+1)/20,'colors':hits})
    assert w.contacts==r['contacts'] 
    if interrupt:
        assert events['hover_stable']['frame']>interrupt['frame']
        if r['scenario'] in ('3','5'):assert interrupt['speed_mps']>0 and interrupt['old_segment_remaining_ms']>0 and movement['red']
    if confirm:
        request=json.loads((path/'confirmation-request.json').read_text());receipt=json.loads((path/'confirmation.json').read_text())
        assert receipt['decision']=='confirm' and all(request[k]==receipt[k] for k in ('revision','token','plan_hash'))
        assert events['late_old_response_rejected']['frame']>confirm['frame']
    for i,c in enumerate(r['calls'],1):
        ledger=r['api_calls'][c['api_number']-1]
        raw=json.loads((path/f'raw-api-{c["api_number"]:03d}.json').read_text())
        assert ledger['kind']=='visual_motion' and ledger['response_id']==c['response_id']==raw['response_id']
        assert json.loads(raw['content'])==c['response']
        req=c['request'];index=round(req['sim_time_s']*20)
        assert req['measured_feedback']==feedback(r['frames'][:index+1])
        assert all(m['frame']<=index for m in c['temporal_images']+c['historical_images'])
        frames=[f for f in r['frames'] if f['model_call']==i and f['preview'].get('arguments') is not None]
        assert len(frames)*.05<=c['response']['duration_s']+1e-8
    forbidden={'bbox','bbox_xyxy','pose','detections','measurement','bearing_right_deg','estimated_depth_m','current_target_measurement','wind_body_mps','dynamic_flight_state','aircraft_state','target_before','target_after'}
    def check(x):
        if isinstance(x,dict):
            assert not set(x)&forbidden
            for v in x.values():check(v)
        elif isinstance(x,list):
            for v in x:check(v)
    hashes={hashlib.sha256(p.read_bytes()).hexdigest() for glob in ('memory-*.png','input-*.png','temporal-*.png') for p in path.glob(glob)}
    visual=0
    for a in r['api_calls']:
        if a['kind']!='visual_motion':continue
        visual+=1;msgs=json.loads((path/f'outbound-api-{a["number"]:03d}.json').read_text())
        for m in msgs:
            if m['role']!='user':continue
            parts=m['content'] if isinstance(m['content'],list) else [{'type':'text','text':m['content']}]
            for p in parts:
                if p['type']=='image_url':assert p['image_url']['sha256'] in hashes
                elif p['text'].startswith('{'):check(json.loads(p['text']))
    assert visual==len(r['calls'])
    kinds=Counter(a['kind'] for a in r['api_calls']);phase=Counter(c['response']['target'] or 'done' for c in r['calls'])
    result=dict(verified=True,completed=r['completed'],contacts=contacts,real_api_requests=len(r['api_calls']),api_by_kind=dict(kinds),visual_responses_by_target=dict(phase),
        successful_api_responses=sum(a['status']=='success' for a in r['api_calls']),model_motion_frames=dict(movement),executed_motion_decisions=len(motion_calls),
        rejected_visual_responses=sum(bool(c.get('acceptance_error')) for c in r['calls']),replay_frames=0,continuous_camera=True,preconfirmation_zero_frames=zero_wait,
        human_confirmation_received=bool(confirm),raw_api_outputs_match_all_motion_commands=True,local_motion_replacements=0,local_zero_command_frames=sum(not any(f['command'].values()) for f in r['frames']),pure_visual_input_audit=True,same_dynamics=True,sdk_calls=0)
    result.update(ground_start=True,maximum_altitude_m=max(f['pose_after']['z'] for f in r['frames']),vertical_motion_frames=sum(bool(f['command']['z']) for f in r['frames']),yaw_motion_frames=sum(bool(f['command']['yaw']) for f in r['frames']),ground_support_verified=True)
    assert len(r['voice_turns'])==(2 if r['scenario_spec']['revision'] else 1)
    initial=r['voice_turns'][0];assert initial['intent']=='execute'
    for turn in r['voice_turns']:
        raw=json.loads((path/f"raw-api-{turn['api_number']:03d}.json").read_text())
        answer=json.loads(raw['content']);assert answer['intent']==turn['intent'] and answer['plan']==turn['plan']
    if r['completed']:
        assert w.contacts==r['scenario_spec']['expected']
        if r['scenario']=='5':
            assert r['pause_verified'] and r['mission_status']=='paused' and not r['mission_completed']
            assert r['voice_turns'][-1]['intent']=='pause' and r['voice_turns'][-1]['plan']==initial['plan']
            assert events['pause_test_passed']['frame']-events['paused']['frame']>=100
            assert all(not any(f['command'].values()) for f in r['frames'][events['voice_interrupt']['frame']:])
        if r['scenario'] in ('3','4'):assert confirm and r['voice_turns'][-1]['intent']=='revise'
    result.update(scenario=r['scenario'],pause_verified=r['pause_verified'],mission_completed=r['mission_completed'],expected_contacts=r['scenario_spec']['expected'])
    (path/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':audit(Path(sys.argv[1]).resolve())
