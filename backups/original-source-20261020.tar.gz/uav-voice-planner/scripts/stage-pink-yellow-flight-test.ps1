<#
.SYNOPSIS
Stages the repeatable pink-then-yellow flight test without ASR or an LLM.
.DESCRIPTION
The same constrained mission-plan interface used by natural-language commands
is reused here. By default the script refuses a real-flight environment;
-AllowFlightMode is an explicit operator acknowledgement, not a safety check.
#>
[CmdletBinding()]
param(
    [string]$HostName = 'uav-one-gimbal',
    [string]$ExpectedRemoteHostName = 'code10',
    [string]$RuntimeRoot = '/home/uav/offline_balloon_strike_test',
    [switch]$AllowFlightMode
)

$ErrorActionPreference = 'Stop'

function Invoke-CheckedSsh {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,
        [Parameter(Mandatory = $true)]
        [string]$FailureMessage
    )

    $output = ssh $HostName $Command
    if ($LASTEXITCODE -ne 0) {
        throw $FailureMessage
    }
    return $output
}

$actualRemoteHostName = ((Invoke-CheckedSsh `
    -Command 'hostname' `
    -FailureMessage 'Unable to read the remote hostname.') -join "`n").Trim()
if ($actualRemoteHostName -ne $ExpectedRemoteHostName) {
    throw "Refusing test plan: connected host '$actualRemoteHostName' is not '$ExpectedRemoteHostName'."
}

$show = Invoke-CheckedSsh `
    -Command 'systemctl show psdk-balloon.service -p ActiveState -p MainPID -p Environment --no-pager' `
    -FailureMessage 'Unable to read the PSDK service state.'
$showText = $show -join "`n"
if ($showText -notmatch 'ActiveState=active') {
    throw 'Refusing test plan: psdk-balloon.service is not active.'
}

$isNoFlight = $showText -match '(?:^|\s)BALLOON_NO_FLIGHT=1(?:\s|$)'
$isFlight = $showText -match '(?:^|\s)BALLOON_NO_FLIGHT=0(?:\s|$)'
if (-not $isNoFlight -and -not $isFlight) {
    throw 'Refusing test plan: BALLOON_NO_FLIGHT is missing from the effective PSDK environment.'
}
if ($isFlight -and -not $AllowFlightMode) {
    throw 'The aircraft is in FLIGHT mode. Re-run with -AllowFlightMode only after the operator has explicitly authorized this flight.'
}

$mainPidMatch = [regex]::Match($showText, '(?m)^MainPID=(\d+)$')
if (-not $mainPidMatch.Success -or [int64]$mainPidMatch.Groups[1].Value -le 0) {
    throw 'Refusing test plan: the PSDK service has no running MainPID.'
}
$mainPid = $mainPidMatch.Groups[1].Value
$processEnvironment = Invoke-CheckedSsh `
    -Command "sudo -n sh -c 'tr \"\\000\" \"\\n\" < /proc/$mainPid/environ'" `
    -FailureMessage 'Unable to verify the running PSDK process environment.'
$processEnvironmentText = $processEnvironment -join "`n"
$expectedNoFlightValue = if ($isNoFlight) { '1' } else { '0' }
if ($processEnvironmentText -notmatch "(?m)^BALLOON_NO_FLIGHT=$expectedNoFlightValue$") {
    throw 'Refusing test plan: the running process environment does not match the effective systemd safety state.'
}

$stopExists = Invoke-CheckedSsh `
    -Command "if test -e /tmp/balloon_nl_stop.request; then echo present; else echo absent; fi" `
    -FailureMessage 'Unable to check the local stop marker.'
if (($stopExists -join "`n").Trim() -ne 'absent') {
    throw 'A stop marker is still present. Press Prepare in DJI Pilot, then run this script again.'
}

$remoteCommand = "sudo -n '$RuntimeRoot/yolo_env/bin/python' '$RuntimeRoot/stage_pink_yellow_test.py'"
$result = Invoke-CheckedSsh `
    -Command $remoteCommand `
    -FailureMessage 'The structured pink/yellow plan was rejected or could not be stored.'
$resultText = $result -join "`n"

try {
    $accepted = $resultText | ConvertFrom-Json
} catch {
    throw "The remote plan command returned invalid JSON: $resultText"
}

$actions = @($accepted.actions)
if ($actions.Count -ne 2 -or
    $actions[0].capability -ne 'strike_balloon' -or
    $actions[0].parameters.color -ne 'pink' -or
    $actions[1].capability -ne 'strike_balloon' -or
    $actions[1].parameters.color -ne 'yellow') {
    throw "Remote verification returned an unexpected plan: $resultText"
}

$mode = if ($isNoFlight) { 'NO_FLIGHT dry-run' } else { 'FLIGHT' }
Write-Host "Plan staged on $actualRemoteHostName in $mode mode."
Write-Host "Plan ID: $($accepted.plan_id)"
Write-Host 'Order: pink -> yellow'
Write-Host 'The script did not press Start or change BALLOON_NO_FLIGHT.'
Write-Host 'Voice, Agent, code12, and public network availability were not used or changed.'
Write-Host 'Verify the two actions in DJI Pilot/logs, then let the operator press Start.'
