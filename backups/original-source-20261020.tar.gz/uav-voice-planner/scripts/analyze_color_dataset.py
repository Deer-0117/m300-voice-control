#!/usr/bin/env python3
"""Measure camera-space HSV distributions for labelled balloon images."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import cv2
import numpy as np


def percentile(values: np.ndarray, value: float) -> float:
    return round(float(np.percentile(values, value)), 2)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--dataset-root", type=Path, required=True)
    parser.add_argument(
        "--colors",
        nargs="+",
        default=["purple", "blue", "red", "orange"],
    )
    parser.add_argument("--max-images-per-color", type=int, default=0)
    args = parser.parse_args()

    sys.path.insert(0, str(args.runtime_root))
    import balloon_yolo_worker as worker  # noqa: PLC0415

    detector, _, _ = worker.load_detector()
    rows: list[dict[str, object]] = []
    for expected in args.colors:
        image_paths = sorted(
            (args.dataset_root / expected / "raw").glob("*.jpg")
        )
        if args.max_images_per_color > 0:
            image_paths = image_paths[: args.max_images_per_color]
        for image_path in image_paths:
            image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
            if image is None:
                continue
            records = detector.predict_records(image_path)
            balloons = [
                record
                for record in records
                if "balloon" in str(record.get("class_name", "")).lower()
            ]
            if not balloons:
                rows.append(
                    {
                        "expected": expected,
                        "name": image_path.name,
                        "detected": False,
                    }
                )
                continue

            height, width = image.shape[:2]

            def balloon_shape_score(item: dict[str, object]) -> float:
                box = [float(value) for value in item["bbox_xyxy"]]
                box_width = max(1.0, box[2] - box[0])
                box_height = max(1.0, box[3] - box[1])
                square_ratio = min(box_width, box_height) / max(
                    box_width, box_height
                )
                area_ratio = (box_width * box_height) / max(1.0, width * height)
                center_x = (box[0] + box[2]) * 0.5 / max(1.0, width)
                center_y = (box[1] + box[3]) * 0.5 / max(1.0, height)
                center_distance = (
                    (center_x - 0.5) ** 2 + (center_y - 0.5) ** 2
                ) ** 0.5
                confidence = float(item.get("confidence") or 0.0)
                return (
                    confidence
                    * square_ratio**2
                    * min(1.0, area_ratio / 0.025)
                    * max(0.35, 1.0 - center_distance)
                )

            candidate_diagnostics: list[dict[str, object]] = []
            for candidate in balloons:
                labelled_candidate = dict(candidate)
                worker.classify_balloon_colors(image_path, [labelled_candidate])
                candidate_diagnostics.append(
                    {
                        "bbox_xyxy": candidate.get("bbox_xyxy"),
                        "detector_confidence": round(
                            float(candidate.get("confidence") or 0.0), 4
                        ),
                        "shape_score": round(balloon_shape_score(candidate), 6),
                        "classified": labelled_candidate.get("color_name"),
                        "color_confidence": labelled_candidate.get(
                            "color_confidence"
                        ),
                        "hsv_median": labelled_candidate.get(
                            "color_hsv_median"
                        ),
                    }
                )

            detection = max(
                balloons, key=balloon_shape_score
            )
            x1, y1, x2, y2 = [
                float(value) for value in detection["bbox_xyxy"]
            ]
            margin_x = max(1.0, (x2 - x1) * 0.15)
            margin_y = max(1.0, (y2 - y1) * 0.15)
            left = max(0, min(width - 1, int(round(x1 + margin_x))))
            top = max(0, min(height - 1, int(round(y1 + margin_y))))
            right = max(left + 1, min(width, int(round(x2 - margin_x))))
            bottom = max(top + 1, min(height, int(round(y2 - margin_y))))
            crop = image[top:bottom, left:right]
            hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
            hue, saturation, value = cv2.split(hsv)
            crop_height, crop_width = crop.shape[:2]
            grid_y, grid_x = np.ogrid[:crop_height, :crop_width]
            central = (
                ((grid_x - (crop_width - 1) * 0.5) / max(1.0, crop_width * 0.5))
                ** 2
                + ((grid_y - (crop_height - 1) * 0.5) / max(1.0, crop_height * 0.5))
                ** 2
            ) <= 1.0
            chromatic = (
                central
                & (value >= 35)
                & ((saturation >= 32) | ((saturation >= 22) & (value >= 150)))
            )
            if int(np.count_nonzero(chromatic)) < 20:
                continue
            worker.classify_balloon_colors(image_path, [detection])
            h_values = hue[chromatic]
            s_values = saturation[chromatic]
            v_values = value[chromatic]
            rows.append(
                {
                    "expected": expected,
                    "name": image_path.name,
                    "detected": True,
                    "detector_confidence": round(
                        float(detection.get("confidence") or 0.0), 4
                    ),
                    "classified": detection.get("color_name"),
                    "color_confidence": detection.get("color_confidence"),
                    "candidates": candidate_diagnostics,
                    "h": [
                        percentile(h_values, 10),
                        percentile(h_values, 50),
                        percentile(h_values, 90),
                    ],
                    "s": [
                        percentile(s_values, 10),
                        percentile(s_values, 50),
                        percentile(s_values, 90),
                    ],
                    "v": [
                        percentile(v_values, 10),
                        percentile(v_values, 50),
                        percentile(v_values, 90),
                    ],
                }
            )

    summaries: dict[str, object] = {}
    for expected in args.colors:
        selected = [row for row in rows if row["expected"] == expected]
        detected = [row for row in selected if row.get("detected")]
        summaries[expected] = {
            "images": len(selected),
            "detected": len(detected),
            "classified": dict(
                Counter(str(row.get("classified")) for row in detected)
            ),
            "median_hsv": {
                channel: [
                    percentile(
                        np.asarray([row[channel][index] for row in detected]),
                        percentile_value,
                    )
                    for index, percentile_value in enumerate((10, 50, 90))
                ]
                for channel in ("h", "s", "v")
            }
            if detected
            else {},
        }
    print(json.dumps({"summary": summaries, "rows": rows}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
