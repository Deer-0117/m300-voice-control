#!/usr/bin/env python3
"""Replay audited prefix, then real ASR/LLM revision with explicit human confirmation."""
import copy,hashlib,json,math,os,runpy,shutil,sys,time,threading,secrets,base64,io,asyncio,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,TimeoutError
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from PIL import Image,ImageDraw
from openai import OpenAI
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'runtime'))
from uav_dynamic_world import DynamicWorld,PARAMETERS,HoverEvidence
from uav_static_world_sim import BALLOONS
from uav_video_feedback import detect_video_frame
from uav_model_velocity import ModelVelocityPreview,SYSTEM,validate_segment
from uav_action_feedback import summarize_effects,FEEDBACK_PROMPT,divergence_guard,target_measurement
from uav_visual_memory import select_sightings,history_hint
from uav_mission_revision import MissionRevision
from uav_revision_search import RevisionSearchPreview,validate_revised_decision
import uav_microsoft_agent as planner
import uav_voice_command as voice
ZERO=dict(x=0.,y=0.,z=0.,yaw=0.)


def main():
    base=ROOT/'local-voice-test/adaptive-model-velocity-20261018-182340'
    prior=json.loads((base/'result.json').read_text())
    out=ROOT/'local-voice-test'/('mission-interrupt-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir()
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    eh=runpy.run_path(str(ROOT/'scripts/run-enhanced-control-simulation.py'))
    vh=runpy.run_path(str(ROOT/'scripts/test-voice-deepseek-candidates.py'))
    ui=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'));ask=ui['ask']
    ask.__globals__['OUT']=out
    ask.__globals__['SYSTEM']=SYSTEM.replace('"red" or "purple" or null','"red" or "purple" or "green" or null')+FEEDBACK_PROMPT+'''
Mission may be revised. The latest confirmed_plan in the instruction overrides any previous example plan. Completed red must never be repeated. Only the uncompleted green target may be approached after revision. Preserve full plan [red,green]. Plant is inertial, command delay .15s, velocity tau .45s, max acceleration1.5m/s2, wind unchanged. Use actual measured segment effects. No instantaneous stopping. While target far, avoid ineffective extremely short pulses. If green is not visible, use search_right or search_left with ZERO x/y/z and a yaw rate up to 10 deg/s for at most 1s. Use the supplied historical green sightings and odometry-derived estimated bearing to choose search direction. These old images are visual memory, not the current scene. Reconcile them with current pose and current image; never treat them as fresh target authorization. Search right only if there is no historical evidence. This is confirmed simulation only. Never translate toward an unseen target. Once green enters view, use approach and an accurate bbox. Search overrides the earlier hold-only example; include the same velocity and duration fields.
'''
    world=DynamicWorld();mission=MissionRevision(prior['plan']);frames=[];events=[];calls=[];decision={};seq=0
    prev={k:getattr(world,k) for k in ('x','y','z','yaw')};pipeline=None;finished=False;failure=None
    sink=eh['video_sink'](out/'closed-loop.mp4',1280,720);raw=eh['video_sink'](out/'camera-input.mp4',880,480)
    pool=ThreadPoolExecutor(max_workers=1);latest=None;latest_vision=None;latest_pose=None
    def save_event(kind,**data):
        e=dict(kind=kind,frame=len(frames),time_s=len(frames)/20,revision=mission.revision,**data);events.append(e)
        (out/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
        print('EVENT '+json.dumps(e,ensure_ascii=False),flush=True)
    def blocked(reason):return dict(arguments=None,execution_allowed=False,sdk_called=False,human_confirmation='pending',reason=reason)
    def tick(c,preview,phase,label,revision=None,evidence=None):
        nonlocal prev,latest,latest_vision,latest_pose
        k=len(frames);now=10000+k*50
        if phase=='prefix_replay':
            pixels=decoder.stdout.read(880*480*3)
            if len(pixels)!=880*480*3:raise RuntimeError('prefix_video_decode_incomplete')
            im=Image.frombytes('RGB',(880,480),pixels)
        else:im=world.render()
        vision=detect_video_frame(im,now,k)
        pose,state=eh['telemetry'](world,prev,now);before=world.flight_state()
        if revision is not None and not mission.permits(revision):
            c=dict(ZERO);preview=blocked('revision_or_confirmation_block')
        if evidence:evidence.observe(im,pose,k,now,c)
        canvas=ui['compose'](world,im,{d['color_name']:d['bbox_xyxy'] for d in vision['detections']},decision,c,k/20,seq,label,mission.revision==1)
        d=ImageDraw.Draw(canvas);d.rectangle((20,15,1260,100),fill='#09131F')
        ui['text'](d,(24,20),'执行中语音打断 · 版本失效 · 人工确认后恢复',28)
        ui['text'](d,(24,65),f'任务版本 {mission.revision} / {mission.status} / '+label,18,'#8ADFD2')
        d.rectangle((20,607,1260,717),fill='#09131F')
        ui['text'](d,(24,613),f"指令 x {c['x']:+.2f} y {c['y']:+.2f} yaw {c['yaw']:+.1f} | 实速 {float(sum(v*v for v in world.v))**.5:.2f} m/s",20)
        ui['text'](d,(24,653),'旧目标：紫色 → 新目标：绿色；已完成红色不重做；持续视觉与惯性/风扰。',18)
        ui['text'](d,(24,686),'仅仿真确认 / 真实飞行未授权 / SDK 调用 0 / 早段为历史指令重放',16)
        sink.stdin.write(canvas.tobytes());raw.stdin.write(im.tobytes())
        if k%100==0:canvas.save(out/'poster.png')
        contacts=list(world.contacts);hits=world.integrate(c,.05)
        assert world.contacts==(['red','purple'] if mission.revision==1 else ['red','green'])[:len(world.contacts)]
        frames.append(dict(frame_index=k,sim_time_s=k/20,phase=phase,mission_revision=mission.revision,mission_status=mission.status,
            issued_revision=revision,pose_before=pose,pose_after={key:getattr(world,key) for key in pose},
            aircraft=state,vision=vision,plant_before=before,plant_after=world.flight_state(),
            model_call=seq,preview=preview,command=dict(c),contacts_before=contacts,contacts_this_frame=hits))
        prev=pose;latest=im;latest_vision=vision;latest_pose=pose
        if hits:save_event('contact',colors=hits)
        return hits
    def settle():
        stable=0
        for _ in range(240):
            tick(dict(ZERO),blocked('braking'),'hold','制动并稳定悬停')
            stable=stable+1 if float(sum(v*v for v in world.v))**.5<.06 and abs(world.yr)<.3 and not any(world.applied.values()) else 0
            if stable>=10:return
        raise RuntimeError('hover_not_stable')
    def held(fn,label,snapshot=False):
        settle();e=HoverEvidence(latest,latest_pose,latest_vision['frame_id'],latest_vision['target_timestamp_ms'])
        measured=summarize_effects(frames,'green') if snapshot else None
        if measured:
            for effect in measured['recent_action_effects']:
                a,b=effect['observation_frame_range']
                if frames[a]['phase']=='revised_motion':
                    effect['target']='green'
                    effect['target_before']=target_measurement(frames[a]['vision'],'green')
                    effect['target_after']=target_measurement(frames[b]['vision'],'green')
        future=pool.submit(fn,latest.copy(),copy.deepcopy(world),measured,latest_vision['target_timestamp_ms']) if snapshot else pool.submit(fn)
        while True:
            started=time.monotonic();tick(dict(ZERO),blocked('analysis_hold'),'hold',label,evidence=e)
            try:return future.result(timeout=max(.001,.05-(time.monotonic()-started))),e.receipt()
            except TimeoutError:
                if future.done():raise
    def checkpoint():
        result=dict(completed=finished,failure=failure,frames=frames,events=events,calls=calls,
          contacts=world.contacts,world_balloons=BALLOONS,dynamics_parameters=PARAMETERS,
          human_confirmation=mission.status,real_execution_allowed=False,sdk_calls=0,
          prefix_record=str(base/'result.json'),prefix_sha256=hashlib.sha256((base/'result.json').read_bytes()).hexdigest(),
          prefix_frames=prefix_end,plan=mission.plan,source_hashes=manifest,live_visual_call_budget=100)
        (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    sources=['runtime/uav_visual_memory.py','runtime/uav_revision_search.py','runtime/uav_mission_revision.py','scripts/run-interrupt-mission-simulation.py','runtime/uav_dynamic_world.py','runtime/uav_model_velocity.py','runtime/uav_action_feedback.py']
    manifest={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in sources}
    first=next(i for i,f in enumerate(prior['frames']) if f['contacts_before']==['red'] and f['preview'].get('arguments') is not None)
    prefix_end=first+5
    decoder=subprocess.Popen(['ffmpeg','-v','error','-i',str(base/'camera-input.mp4'),'-frames:v',str(prefix_end),'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
    server=None;thread=None
    try:
        for f in prior['frames'][:prefix_end]:
            seq=f['model_call'];decision=prior['calls'][seq-1]['response'] if seq else {}
            tick(f['command'],f['preview'],'prefix_replay','历史指令驱动原动力学模型',revision=1)
            assert world.flight_state()==f['plant_after']
        decoder.stdout.close();decoder.wait()
        assert world.contacts==['red'] and float(sum(v*v for v in world.v))**.5>0
        sightings=select_sightings(frames,'green')
        memory_content=[{'type':'text','text':'HISTORICAL VISUAL MEMORY: these are earlier camera images with observation timestamps and poses. Use them to search for green after the user changes the mission; not as current target detections.'}]
        for sight in sightings:
            source=frames[sight['frame_index']];camera_world=DynamicWorld()
            for key,value in source['pose_before'].items():setattr(camera_world,key,value)
            camera_world.contacts=list(source['contacts_before']);im=camera_world.render()
            name=f"memory-green-{sight['frame_index']:05d}.png";im.save(out/name)
            sight['image']=name;buf=io.BytesIO();im.save(buf,format='PNG')
            memory_content.extend([{'type':'text','text':json.dumps(sight,ensure_ascii=False)}, {'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()}}])
        memory_message={'role':'user','content':memory_content}
        (out/'visual-memory.json').write_text(json.dumps(sightings,ensure_ascii=False,indent=2)+'\n')
        old_revision=mission.revision;old_segment=copy.deepcopy(decision)
        old_remaining_ms=prior['frames'][prefix_end-1]['preview']['segment_deadline_ms']-(10000+prefix_end*50)
        assert old_remaining_ms>0
        mission.interrupt(world.contacts)
        save_event('voice_interrupt',utterance='把第二个改成绿色',old_segment_remaining_ms=old_remaining_ms,speed_mps=float(sum(v*v for v in world.v))**.5)
        assert not mission.permits(old_revision)
        tick(dict(ZERO),blocked('voice_interrupt'),'hold','语音打断 / 旧指令失效')
        save_event('old_segment_rejected',old_revision=old_revision)
        settle();save_event('hover_stable',speed_mps=float(sum(v*v for v in world.v))**.5)
        # Synthesized audio stands in for the live microphone; real local recognition.
        held(lambda:vh['synthesize']('把第二个改成绿色',out/'revision','Tingting'),'合成修改语音 / 悬停')
        shutil.copytree(base/'planner',out/'planner')
        planner.STATE_ROOT=out/'planner';planner.PLAN_DIR=planner.STATE_ROOT/'plans';planner.EVENT_LOG=planner.STATE_ROOT/'events.jsonl'
        server=ThreadingHTTPServer(('127.0.0.1',0),vh['QuietAsrHandler']);endpoint=f'http://127.0.0.1:{server.server_port}/transcribe'
        thread=threading.Thread(target=server.serve_forever,daemon=True)
        env={'UAV_WHISPER_CLI':str(ROOT/'local-asr/whisper.cpp/build/bin/whisper-cli'),'UAV_WHISPER_MODEL':str(ROOT/'local-asr/whisper.cpp/models/ggml-base.bin'),
             'UAV_VOICE_ASR_STATE_DIR':str(out/'asr'),'UAV_VOICE_ASR_ENDPOINT':endpoint,'UAV_VOICE_ASR_FALLBACK_ENDPOINT':endpoint,'UAV_VOICE_ASR_TOKEN':secrets.token_urlsafe(24),'NO_PROXY':'127.0.0.1,localhost'}
        with patch.dict(os.environ,env),patch.object(planner,'executor_observation',side_effect=AssertionError('real aircraft forbidden')),patch.object(planner,'submit_proposal',side_effect=AssertionError('real submit forbidden')):
            thread.start()
            transcript,_=held(lambda:voice.transcribe(out/'revision.pcm'),'识别修改语音 / 悬停')
            save_event('transcript',text=transcript)
            def replan():
                history=[{'command':t['normalized'],'plan':t['plan'],'status':'proposed','preview_only':False} for t in prior['voice_turns']]
                observation={'available':True,'fresh':True,'simulation_only':True,'state':{
                    'plan_id':'simulation-mission-revision-1','status':'running','current_index':1,
                    'completed_indices':[0],'updated_ts_ms':int(time.time()*1000),
                    'provenance':'verified simulator geometric contact: red; second action incomplete'}}
                context=planner.model_input(voice.normalize_transcript(transcript),history,observation)
                for attempt in range(3):
                    try:
                        candidate,response=asyncio.run(planner.interpret_with_agent(context))
                        proposal={'plan':planner.normalize_model_plan(candidate),'model_response':response,'input':json.loads(context)}
                        (out/'revision-model-result.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
                        return proposal
                    except Exception as exc:
                        if type(exc).__name__ not in ('ChatClientException','AgentError') or attempt==2:raise
            proposal,_=held(replan,'分析任务修改 / 悬停')
            request=mission.propose(proposal['plan']);save_event('candidate_ready',plan=mission.plan,completed=mission.completed,remaining=['green'])
            (out/'confirmation-request.json').write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n');checkpoint()
            print('AWAIT_CONFIRMATION '+str(out),flush=True)
            while not (out/'confirmation.json').exists():
                start=time.monotonic();tick(dict(ZERO),blocked('awaiting_human_confirmation'),'hold','等待人工确认：保留已完成红色，改为绿色')
                time.sleep(max(0,.05-(time.monotonic()-start)))
            confirmation=json.loads((out/'confirmation.json').read_text());mission.confirm(confirmation)
            save_event('human_confirmed',plan_hash=request['plan_hash'],scope='simulation_only')
            # Deliberate late-result replay: never treat this as a fresh API response.
            assert not mission.permits(old_revision)
            tick(old_segment['velocity'],blocked('stale_response_probe'),'hold','拒绝迟到的旧版本指令',old_revision)
            save_event('late_old_response_rejected',old_revision=old_revision,source='replayed previously recorded DeepSeek response',target=old_segment['target'])
            messages=[];seq=0;pipeline=RevisionSearchPreview(mission.plan,2);issued_revision=mission.revision
            with OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
                for _ in range(2000):
                    now=10000+len(frames)*50
                    if pipeline.command is None or now>=pipeline.deadline or len(world.contacts)==2:
                        seq+=1
                        if seq>100:raise RuntimeError('revised_mission_call_budget')
                        instruction=json.dumps({'confirmed_plan':['red','green'],'revision':mission.revision,'completed':world.contacts,'voice_modification':transcript,'do_not_repeat':['red'],'simulation_only':True},ensure_ascii=False)
                        def infer(im,snap,measured,stamp):
                            measured['historical_green_search_hint']=history_hint(sightings,{k:getattr(snap,k) for k in ('x','y','z','yaw')})
                            context=[memory_message,*messages[-6:]]
                            result=ask(client,context,snap,im,instruction,seq,stamp/1000-10,max_tokens=1800,thinking='disabled',measured_feedback=measured)
                            messages.extend(context[-2:])
                            result[1]['historical_images']=[s['image'] for s in sightings]
                            return result
                        (decision,call),evidence=held(infer,'分析绿色目标 / 悬停',True)
                        call['revision']=issued_revision;call['hover_evidence']=evidence;calls.append(copy.deepcopy(call))
                        if not mission.permits(issued_revision):continue
                        validate_revised_decision(decision)
                        if decision['plan']!=['red','green']:raise ValueError('stale_model_plan')
                        if world.contacts==['red','green']:
                            if decision['mode']!='done':continue
                            finished=True
                            for _ in range(40):tick(dict(ZERO),blocked('complete'),'complete','红色→绿色接触完成')
                            break
                        if decision['target']!='green':raise ValueError('wrong_revised_target')
                        if not evidence['hover_verified']:continue
                        error=divergence_guard(decision,call['request']['measured_feedback'])
                        if not error:error=pipeline.accept_model(decision,latest_vision,frame_id=latest_vision['frame_id'],image_timestamp_ms=latest_vision['target_timestamp_ms'],received_timestamp_ms=latest_vision['target_timestamp_ms'],sequence=seq)
                        calls[-1]['acceptance_error']=error
                        messages.append({'role':'user','content':json.dumps({'validation':error})})
                        if error:pipeline.close();continue
                    k=len(frames);now=10000+k*50;vision=detect_video_frame(world.render(),now,k);_,state=eh['telemetry'](world,prev,now)
                    preview=pipeline.step({'now_ms':now,'vision':vision,'aircraft':state})
                    tick(preview['arguments'] or dict(ZERO),preview,'revised_motion','已确认 / 大模型指令转向绿色',issued_revision)
                if not finished:failure='revised_task_incomplete'
    except KeyboardInterrupt:failure='interrupted'
    except Exception as exc:failure=type(exc).__name__;print('ERROR '+failure,flush=True)
    finally:
        if decoder.poll() is None:
            decoder.terminate();decoder.wait()
        if pipeline:pipeline.close()
        if thread and thread.is_alive():server.shutdown();thread.join(timeout=2)
        if server:server.server_close()
        pool.shutdown(wait=True)
        for p in (sink,raw):p.stdin.close();p.wait()
        checkpoint();print('RESULT '+str(out)+' '+str(finished),flush=True)
    return 0 if finished else 1

if __name__=='__main__':sys.exit(main())
