#!/usr/bin/env python3
"""Controlled pink-noise sweep through real ASR and candidate-only DeepSeek."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import runpy
import secrets
import sys
import threading
import time
import unicodedata
import wave
from http.server import ThreadingHTTPServer
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
import uav_microsoft_agent as planner
import uav_voice_command as voice

SEED = 20261018
TEXTS = ("先撞红色气球，再撞绿色气球", "把第二个改成紫色")
EXPECTED = (["pink", "yellow"], ["pink", "blue"])
LEVELS = (None, 20, 10, 0, -5)


def read_audio(path):
    with wave.open(str(path), "rb") as stream:
        if (stream.getnchannels(), stream.getsampwidth(), stream.getframerate()) != (1, 2, 16000):
            raise ValueError("expected mono 16-bit 16 kHz WAV")
        return np.frombuffer(stream.readframes(stream.getnframes()), dtype="<i2").astype(float) / 32768


def noisy_audio(clean, snr, seed):
    if snr is None:
        return np.rint(clean * 32768).astype("<i2").tobytes(), {"snr_db": None, "gain": 1}
    # Fixed realization per utterance; only its strength changes across levels.
    rng = np.random.default_rng(seed)
    spectrum = np.fft.rfft(rng.normal(size=len(clean)))
    bins = np.arange(len(spectrum), dtype=float)
    spectrum[0] = 0
    spectrum[1:] /= np.sqrt(bins[1:])  # power spectrum proportional to 1/f
    noise = np.fft.irfft(spectrum, n=len(clean))
    signal_rms = np.sqrt(np.mean(clean ** 2))
    noise *= signal_rms / (10 ** (snr / 20) * np.sqrt(np.mean(noise ** 2)))
    measured = float(20 * np.log10(signal_rms / np.sqrt(np.mean(noise ** 2))))
    mixed = clean + noise
    gain = min(1.0, 0.95 / np.max(np.abs(mixed)))
    mixed *= gain  # common gain keeps the requested SNR while avoiding clipping
    assert abs(measured - snr) < 0.001 and np.max(np.abs(mixed)) <= 0.951
    return np.rint(mixed * 32767).astype("<i2").tobytes(), {
        "snr_db": snr, "measured_pre_quantization_snr_db": measured,
        "gain": float(gain), "seed": seed, "rms_basis": "whole utterance including silence",
    }


def canonical_text(text):
    return "".join(c for c in voice.normalize_transcript(text).replace("二", "2")
                   if not c.isspace() and not unicodedata.category(c).startswith("P"))


def main():
    helpers = runpy.run_path(str(ROOT / "scripts/test-voice-deepseek-candidates.py"))
    runpy.run_path(str(ROOT / "scripts/test-deepseek-candidates.py"))["load_configuration"]()
    source = ROOT / "local-voice-test/20261018-150111"
    signals = [read_audio(source / f"turn-{i}.wav") for i in (1, 2)]
    output = ROOT / "local-voice-test" / ("noise-" + time.strftime("%Y%m%d-%H%M%S"))
    output.mkdir(parents=True, exist_ok=False)
    planner.STATE_ROOT = output / "planner"
    planner.PLAN_DIR = planner.STATE_ROOT / "plans"
    planner.EVENT_LOG = planner.STATE_ROOT / "events.jsonl"
    server = ThreadingHTTPServer(("127.0.0.1", 0), helpers["QuietAsrHandler"])
    endpoint = f"http://127.0.0.1:{server.server_port}/transcribe"
    environment = {
        "UAV_WHISPER_CLI": str(ROOT / "local-asr/whisper.cpp/build/bin/whisper-cli"),
        "UAV_WHISPER_MODEL": str(ROOT / "local-asr/whisper.cpp/models/ggml-base.bin"),
        "UAV_VOICE_ASR_STATE_DIR": str(output / "asr-state"),
        "UAV_VOICE_ASR_ENDPOINT": endpoint, "UAV_VOICE_ASR_FALLBACK_ENDPOINT": endpoint,
        "UAV_VOICE_ASR_TOKEN": secrets.token_urlsafe(32),
        "NO_PROXY": os.environ.get("NO_PROXY", "") + ",127.0.0.1,localhost",
    }
    report = {
        "noise": "synthetic pink noise (1/f power)", "seed": SEED,
        "source": str(source), "asr": "whisper.cpp multilingual base",
        "model": os.environ["OPENAI_CHAT_MODEL_ID"], "execution_allowed": False,
        "human_confirmation": "not performed", "aircraft_access": False,
        "conditions": [],
    }
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    with patch.dict(os.environ, environment), \
            patch.object(planner, "executor_observation", side_effect=AssertionError("aircraft access forbidden")), \
            patch.object(planner, "submit_proposal", side_effect=AssertionError("submission forbidden")), \
            patch.object(voice, "confirm", side_effect=AssertionError("confirmation forbidden")), \
            patch.object(voice, "store_plan", side_effect=AssertionError("execution plan writes forbidden")):
        thread.start()
        try:
            for level in LEVELS:
                label = "clean" if level is None else f"snr-{level}dB"
                condition = {"label": label, "snr_db": level, "turns": []}
                report["conditions"].append(condition)
                session_id = None
                for i, clean in enumerate(signals):
                    pcm, audio_metadata = noisy_audio(clean, level, SEED + i)
                    prefix = output / f"{label}-turn-{i + 1}"
                    prefix.with_suffix(".pcm").write_bytes(pcm)
                    wav = voice.pcm_to_wav(prefix.with_suffix(".pcm"))
                    prefix.with_suffix(".wav").write_bytes(wav)
                    record = {"turn": i + 1, "original_text": TEXTS[i], "audio": str(prefix.with_suffix(".wav")),
                              "audio_sha256": hashlib.sha256(wav).hexdigest(), **audio_metadata,
                              "prior_context_available": session_id is not None,
                              "execution_allowed": False, "candidate_correct": False}
                    stage = "asr"
                    try:
                        start = time.monotonic()
                        transcript = voice.transcribe(prefix.with_suffix(".pcm"))
                        record.update(asr_text=transcript, asr_seconds=round(time.monotonic() - start, 2),
                                      canonical_text_match=canonical_text(transcript) == canonical_text(TEXTS[i]))
                        print(f"{label} 第{i+1}轮 ASR: {transcript}", flush=True)
                        stage = "model"
                        start = time.monotonic()
                        proposal = planner.interpret_command(voice.normalize_transcript(transcript), session_id,
                                                             candidate_only=True)
                        session_id = proposal["session_id"]
                        colors = [a["parameters"]["color"] for a in proposal["plan"]["actions"]]
                        record.update(plan=proposal["plan"], colors=colors, session_id=session_id,
                                      proposal_id=proposal["proposal_id"], human_confirmation="pending",
                                      model_seconds=round(time.monotonic() - start, 2),
                                      candidate_correct=colors == EXPECTED[i])
                        print(f"  候选: {colors}；符合预期: {record['candidate_correct']}", flush=True)
                    except Exception as exc:
                        record.update(error_stage=stage, error_type=type(exc).__name__)
                        print(f"  {stage}失败: {type(exc).__name__}，不生成替代计划。", flush=True)
                    condition["turns"].append(record)
                    planner.atomic_write_json(output / "result.json", report)
                condition["both_plans_correct"] = all(r["candidate_correct"] for r in condition["turns"])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
    planner.atomic_write_json(output / "result.json", report)
    print(f"报告：{output / 'result.json'}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"噪声测试未完成（{type(exc).__name__}），未提交计划。", file=sys.stderr)
        raise SystemExit(1)
