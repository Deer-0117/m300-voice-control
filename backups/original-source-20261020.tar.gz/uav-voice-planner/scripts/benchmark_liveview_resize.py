#!/usr/bin/env python3
"""Validate 640-side Liveview JPEG publication against the current image path.

Run this on the original Jetson before enabling ``--max-frame-side 640``.  The
script feeds the same TensorRT engine both the source JPEG and a JPEG produced
from the decoded BGR frame by the proposed Liveview publisher.
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np


def percentile(values: list[float], point: float) -> float | None:
    return round(float(np.percentile(values, point)), 3) if values else None


def best(records: list[dict[str, Any]]) -> dict[str, Any] | None:
    return max(records, key=lambda row: float(row.get("confidence", 0.0))) if records else None


def normalized_box(record: dict[str, Any], width: int, height: int) -> list[float]:
    x1, y1, x2, y2 = (float(value) for value in record["bbox_xyxy"])
    return [x1 / width, y1 / height, x2 / width, y2 / height]


def box_iou(left: list[float], right: list[float]) -> float:
    intersection_width = max(0.0, min(left[2], right[2]) - max(left[0], right[0]))
    intersection_height = max(0.0, min(left[3], right[3]) - max(left[1], right[1]))
    intersection = intersection_width * intersection_height
    left_area = max(0.0, left[2] - left[0]) * max(0.0, left[3] - left[1])
    right_area = max(0.0, right[2] - right[0]) * max(0.0, right[3] - right[1])
    return intersection / max(left_area + right_area - intersection, 1e-7)


def collect_images(root: Path, limit: int) -> list[Path]:
    extensions = {".jpg", ".jpeg", ".png", ".bmp"}
    found = sorted(path for path in root.rglob("*") if path.is_file() and path.suffix.lower() in extensions)
    return found[:limit] if limit > 0 else found


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-root", type=Path, default=Path("/home/uav/offline_balloon_strike_test"))
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--engine", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--max-frame-side", type=int, default=640)
    parser.add_argument("--jpeg-quality", type=int, default=90)
    parser.add_argument("--frame-format", choices=("jpg", "bmp"), default="jpg")
    parser.add_argument("--decode-divisor", type=int, choices=(1, 2, 4, 8), default=4)
    parser.add_argument("--minimum-agreement", type=float, default=0.98)
    parser.add_argument("--minimum-recall", type=float, default=0.98)
    parser.add_argument("--minimum-iou", type=float, default=0.95)
    parser.add_argument("--maximum-total-p95-ms", type=float, default=120.0)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    runtime_root = args.runtime_root.resolve()
    sys.path.insert(0, str(runtime_root))
    sys.path.insert(0, str(runtime_root / "yolo_callable_module"))
    # Prefer the candidate modules staged beside this validation script while
    # falling through to the formal runtime for weights/configuration helpers.
    sys.path.insert(0, str(Path(__file__).resolve().parent))

    import yolo_infer  # type: ignore

    from balloon_liveview_decoder import publish_frame  # type: ignore
    from balloon_tensorrt import TensorRTBalloonDetector  # type: ignore

    config = yolo_infer.load_config()
    detector = TensorRTBalloonDetector(
        args.engine.resolve(), int(config["imgsz"]), float(config["conf"]), args.decode_divisor
    )
    images = collect_images(args.images.resolve(), args.limit)
    if not images:
        raise SystemExit(f"no images found below {args.images}")

    agreements = 0
    baseline_positives = 0
    resized_hits = 0
    ious: list[float] = []
    confidence_deltas: list[float] = []
    baseline_ms: list[float] = []
    publish_ms: list[float] = []
    resized_inference_ms: list[float] = []
    proposed_total_ms: list[float] = []
    rows: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []

    try:
        with tempfile.TemporaryDirectory(prefix="balloon-liveview-resize-") as temporary:
            frame_dir = Path(temporary)
            metadata = frame_dir / "latest.tsv"

            warm_frame = cv2.imread(str(images[0]), cv2.IMREAD_COLOR)
            if warm_frame is None:
                raise SystemExit(f"unable to decode warmup image: {images[0]}")
            warm_path, _, _, _ = publish_frame(
                frame_dir, metadata, 0, warm_frame, args.jpeg_quality,
                args.max_frame_side, args.frame_format,
            )
            detector.predict_records(images[0])
            detector.predict_records(warm_path)
            warm_path.unlink(missing_ok=True)

            for index, source in enumerate(images, start=1):
                try:
                    bgr = cv2.imread(str(source), cv2.IMREAD_COLOR)
                    if bgr is None or bgr.size == 0:
                        raise ValueError("cv2.imread returned no pixels")
                    source_height, source_width = bgr.shape[:2]

                    started = time.perf_counter()
                    baseline_records = detector.predict_records(source)
                    current_baseline_ms = (time.perf_counter() - started) * 1000.0

                    started = time.perf_counter()
                    resized_path, reported_publish_ms, resized_width, resized_height = publish_frame(
                        frame_dir, metadata, index, bgr, args.jpeg_quality,
                        args.max_frame_side, args.frame_format,
                    )
                    current_publish_ms = (time.perf_counter() - started) * 1000.0

                    started = time.perf_counter()
                    resized_records = detector.predict_records(resized_path)
                    current_resized_ms = (time.perf_counter() - started) * 1000.0
                    resized_path.unlink(missing_ok=True)
                except Exception as exc:
                    skipped.append({"image": str(source), "error": repr(exc)})
                    continue

                baseline_best = best(baseline_records)
                resized_best = best(resized_records)
                agreements += int(bool(baseline_best) == bool(resized_best))
                if baseline_best:
                    baseline_positives += 1
                    resized_hits += int(resized_best is not None)

                baseline_ms.append(current_baseline_ms)
                publish_ms.append(current_publish_ms)
                resized_inference_ms.append(current_resized_ms)
                proposed_total_ms.append(current_publish_ms + current_resized_ms)
                row: dict[str, Any] = {
                    "image": str(source),
                    "source_size": [source_width, source_height],
                    "resized_size": [resized_width, resized_height],
                    "baseline_detection": baseline_best is not None,
                    "resized_detection": resized_best is not None,
                    "baseline_ms": round(current_baseline_ms, 3),
                    "publish_ms": round(current_publish_ms, 3),
                    "reported_publish_ms": reported_publish_ms,
                    "resized_inference_ms": round(current_resized_ms, 3),
                    "proposed_total_ms": round(current_publish_ms + current_resized_ms, 3),
                    "resized_stages_ms": dict(detector.last_timings_ms),
                    "baseline_confidence": round(float(baseline_best["confidence"]), 6)
                    if baseline_best else None,
                    "resized_confidence": round(float(resized_best["confidence"]), 6)
                    if resized_best else None,
                }
                if baseline_best and resized_best:
                    baseline_box = normalized_box(baseline_best, source_width, source_height)
                    resized_box = normalized_box(resized_best, resized_width, resized_height)
                    current_iou = box_iou(baseline_box, resized_box)
                    confidence_delta = abs(
                        float(baseline_best["confidence"]) - float(resized_best["confidence"])
                    )
                    ious.append(current_iou)
                    confidence_deltas.append(confidence_delta)
                    row.update(
                        {
                            "normalized_iou": round(current_iou, 6),
                            "confidence_delta": round(confidence_delta, 6),
                            "baseline_bbox_norm": [round(value, 6) for value in baseline_box],
                            "resized_bbox_norm": [round(value, 6) for value in resized_box],
                        }
                    )
                rows.append(row)
    finally:
        detector.close()

    evaluated = len(rows)
    if not evaluated:
        raise SystemExit("no images were evaluated")
    agreement = agreements / evaluated
    recall = resized_hits / baseline_positives if baseline_positives else 1.0
    median_iou = float(np.median(ious)) if ious else 1.0
    total_p95 = percentile(proposed_total_ms, 95) or 0.0
    passed = (
        agreement >= args.minimum_agreement
        and recall >= args.minimum_recall
        and median_iou >= args.minimum_iou
        and total_p95 <= args.maximum_total_p95_ms
    )
    report = {
        "pass": passed,
        "images_found": len(images),
        "images_evaluated": evaluated,
        "images_skipped": len(skipped),
        "baseline_positives": baseline_positives,
        "presence_agreement": round(agreement, 6),
        "resized_recall_vs_baseline": round(recall, 6),
        "median_normalized_box_iou": round(median_iou, 6),
        "confidence_delta_p95": percentile(confidence_deltas, 95),
        "baseline_inference_ms": {"p50": percentile(baseline_ms, 50), "p95": percentile(baseline_ms, 95)},
        "publish_ms": {"p50": percentile(publish_ms, 50), "p95": percentile(publish_ms, 95)},
        "resized_inference_ms": {
            "p50": percentile(resized_inference_ms, 50),
            "p95": percentile(resized_inference_ms, 95),
        },
        "proposed_bgr_to_detection_ms": {
            "p50": percentile(proposed_total_ms, 50),
            "p95": total_p95,
        },
        "settings": {
            "max_frame_side": args.max_frame_side,
            "jpeg_quality": args.jpeg_quality,
            "frame_format": args.frame_format,
            "decode_divisor": args.decode_divisor,
        },
        "thresholds": {
            "minimum_agreement": args.minimum_agreement,
            "minimum_recall": args.minimum_recall,
            "minimum_iou": args.minimum_iou,
            "maximum_total_p95_ms": args.maximum_total_p95_ms,
        },
        "disagreements": [row for row in rows if row["baseline_detection"] != row["resized_detection"]],
        "results": rows,
        "skipped": skipped,
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
