#!/bin/sh
# Launch a command with the restricted relay proxy environment.  Secrets live
# in the root-readable env file and are never embedded in this repository.
set -eu

if [ -r /etc/uav-relay-proxy.env ]; then
    # shellcheck disable=SC1091
    . /etc/uav-relay-proxy.env
fi

export HTTP_PROXY HTTPS_PROXY ALL_PROXY NO_PROXY
export http_proxy="$HTTP_PROXY"
export https_proxy="$HTTPS_PROXY"
export all_proxy="$ALL_PROXY"
export no_proxy="$NO_PROXY"

exec "$@"
