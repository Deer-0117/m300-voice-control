#!/usr/bin/env python3
"""Expose the relay's loopback tinyproxy to code10 over the USB Ethernet link."""

from __future__ import annotations

import argparse
import os
import select
import socket
import socketserver
import threading

import paramiko


class RelayTunnel:
    def __init__(self, host: str, username: str, password: str, target_host: str, target_port: int):
        self.host = host
        self.username = username
        self.password = password
        self.target_host = target_host
        self.target_port = target_port
        self._client: paramiko.SSHClient | None = None
        self._lock = threading.Lock()

    def _connect(self) -> paramiko.Transport:
        if self._client is not None:
            transport = self._client.get_transport()
            if transport is not None and transport.is_active():
                return transport
            self._client.close()
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            self.host, username=self.username, password=self.password,
            timeout=10, banner_timeout=10, auth_timeout=10,
        )
        transport = client.get_transport()
        if transport is None:
            client.close()
            raise RuntimeError("relay SSH transport unavailable")
        transport.set_keepalive(15)
        self._client = client
        return transport

    def open(self, origin: tuple[str, int]) -> paramiko.Channel:
        with self._lock:
            transport = self._connect()
            return transport.open_channel(
                "direct-tcpip", (self.target_host, self.target_port), origin, timeout=10,
            )


class ProxyHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        try:
            channel = self.server.relay.open(self.client_address)  # type: ignore[attr-defined]
        except Exception as exc:
            print(f"open failed for {self.client_address}: {exc}", flush=True)
            return
        try:
            while True:
                readable, _, _ = select.select([self.request, channel], [], [], 30)
                if self.request in readable:
                    data = self.request.recv(65536)
                    if not data:
                        break
                    channel.sendall(data)
                if channel in readable:
                    data = channel.recv(65536)
                    if not data:
                        break
                    self.request.sendall(data)
        finally:
            channel.close()


class ThreadedProxy(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", default="192.168.55.2")
    parser.add_argument("--port", type=int, default=18889)
    parser.add_argument("--relay-host", default="10.18.2.83")
    parser.add_argument("--relay-user", default="jxf_group")
    parser.add_argument("--target-host", default="127.0.0.1")
    parser.add_argument("--target-port", type=int, default=18888)
    parser.add_argument("--password-file")
    args = parser.parse_args()
    password = os.environ.get("UAV_RELAY_PASSWORD", "")
    if not password and args.password_file:
        password = open(args.password_file, encoding="utf-8").read().strip()
    if not password:
        raise SystemExit("UAV_RELAY_PASSWORD or --password-file is required")
    relay = RelayTunnel(args.relay_host, args.relay_user, password, args.target_host, args.target_port)
    with ThreadedProxy((args.bind, args.port), ProxyHandler) as server:
        server.relay = relay  # type: ignore[attr-defined]
        print(
            f"code10 proxy listening on {args.bind}:{args.port}; "
            f"relay target {args.relay_host}->{args.target_host}:{args.target_port}",
            flush=True,
        )
        server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
