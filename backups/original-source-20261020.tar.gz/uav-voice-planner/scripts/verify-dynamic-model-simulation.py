#!/usr/bin/env python3
"""Replay all issued commands through the inertial plant and audit model provenance."""
import hashlib
import json
import math
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
from uav_dynamic_world import DynamicWorld,PARAMETERS
from uav_static_world_sim import BALLOONS


def verify(path):
    r=json.loads(path.read_text());w=DynamicWorld();events=[];motions=0;moving_holds=0;maxspeed=0.;max_zero_speed=0.;max_wind=0.
    assert r['sdk_calls']==0 and not r['execution_allowed'] and r['human_confirmation']=='pending'
    assert r['dynamics_parameters']==PARAMETERS
    assert r['world_balloons']==[list(b) for b in BALLOONS]
    for i,f in enumerate(r['frames']):
        assert f['frame_index']==i and abs(f['sim_time_s']-i/20)<1e-8
        assert f['vision']['frame_id']==i and f['vision']['target_timestamp_ms']==10000+i*50
        assert f['plant_before']==w.flight_state()
        assert all(abs(f['pose_before'][k]-getattr(w,k))<1e-10 for k in ('x','y','z','yaw'))
        c=f['command'];p=f['preview']
        assert not p['sdk_called'] and not p['execution_allowed'] and p['human_confirmation']=='pending'
        if p['arguments'] is not None:
            motions+=1;call=r['calls'][f['model_call']-1]
            assert c==call['response']['velocity']==p['arguments']
            receipt=call['stationary_revalidation'];assert receipt['hover_verified']
            start=receipt['revalidated_timestamp_ms']+50
            assert start<=10000+i*50<start+math.floor(call['response']['duration_s']*20+1e-8)*50
            assert call['acceptance_error'] is None
        else:assert all(v==0 for v in c.values())
        hits=w.integrate(c,.05)
        assert hits==f['contacts_this_frame']
        assert w.contacts==['red','purple'][:len(w.contacts)]
        assert f['plant_after']==w.flight_state()
        assert all(abs(f['pose_after'][k]-getattr(w,k))<1e-10 for k in ('x','y','z','yaw'))
        if hits:events.append(dict(time_s=(i+1)/20,colors=hits))
        if f['phase']=='hold' and f['pose_before']!=f['pose_after']:moving_holds+=1
        speed=math.sqrt(sum(v*v for v in w.v))
        maxspeed=max(maxspeed,speed)
        max_wind=max(max_wind,math.sqrt(sum(v*v for v in w.wind)))
        if not any(c.values()):max_zero_speed=max(max_zero_speed,speed)
    drifts=[];holdframes=0
    for h in r['holds']:
        start,end=h['start_frame'],h['end_frame_exclusive'];source=r['frames'][h['source_frame']]['pose_before']
        assert end-start==h['new_camera_frames']
        actual=0.
        for f in r['frames'][start:end]:
            assert f['phase']=='hold' and not any(f['command'].values())
            actual=max(actual,math.dist([source[k] for k in ('x','y','z')],[f['pose_before'][k] for k in ('x','y','z')]))
        assert abs(actual-h['max_drift_m'])<1e-9
        drifts.append(actual);holdframes+=end-start
    root=Path(__file__).resolve().parents[1]
    assert all(hashlib.sha256((root/s).read_bytes()).hexdigest()==v for s,v in r['source_hashes'].items())
    assert r['voice_turns'][0]['session_id']==r['voice_turns'][1]['session_id']
    feedback_checks=0
    if r.get('control_improvement'):
        from uav_action_feedback import summarize_effects,divergence_guard
        for call in r['calls']:
            source=call['stationary_revalidation']['original_model_source_frame']
            prefix=r['frames'][:source+1]
            contacted=prefix[-1]['contacts_before']+prefix[-1]['contacts_this_frame']
            target=['red','purple'][len(contacted)] if len(contacted)<2 else None
            assert call['request']['measured_feedback']==summarize_effects(prefix,target)
            if call.get('acceptance_error') is None and call['response'].get('mode')=='approach' and not call.get('discarded'):
                assert divergence_guard(call['response'],call['request']['measured_feedback']) is None
            feedback_checks+=1
        baseline_path=Path(__file__).resolve().parents[1]/'local-voice-test/dynamic-model-velocity-20261018-173408/result.json'
        baseline=json.loads(baseline_path.read_text())
        assert r['dynamics_parameters']==baseline['dynamics_parameters']
        assert r['source_hashes']['runtime/uav_dynamic_world.py']==baseline['source_hashes']['runtime/uav_dynamic_world.py']
        assert r['world_balloons']==baseline['world_balloons']
    result=dict(measured_feedback_reconstructed_calls=feedback_checks,verified=True,completed=r['completed'],contacts=w.contacts,contact_events=events,
                frames=len(r['frames']),real_visual_calls=len(r['calls']),model_motion_frames=motions,
                hold_frames_with_nonzero_physical_motion=moving_holds,analysis_camera_frames=holdframes,
                max_analysis_drift_m=max(drifts),peak_actual_speed_mps=maxspeed,max_speed_under_zero_command_mps=max_zero_speed,
                peak_wind_mps=max_wind,
                model_commands_unchanged=True,delayed_plant_replay_matches=True,
                world_positions_fixed=True,sdk_calls=0,human_confirmation='pending')
    (path.parent/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':verify(Path(sys.argv[1]))
