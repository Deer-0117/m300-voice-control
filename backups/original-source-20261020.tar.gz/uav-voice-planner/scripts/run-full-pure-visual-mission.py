#!/usr/bin/env python3
"""Fresh dynamics + live ASR/planning/visual API, revision confirmation; no replay/SDK."""
import base64,copy,hashlib,io,json,math,os,runpy,secrets,sys,threading,time
from pathlib import Path
from collections import deque
from concurrent.futures import ThreadPoolExecutor,TimeoutError
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from PIL import ImageDraw
from openai import OpenAI
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'runtime'))
from uav_dynamic_world import DynamicWorld,PARAMETERS,HoverEvidence
from uav_static_world_sim import BALLOONS
from uav_video_feedback import detect_video_frame
from uav_model_velocity import SYSTEM
from uav_full_mission_preview import FullMissionPreview
from uav_model_visual_consistency import check_self_consistency
from uav_pure_visual_strategy import STRATEGY,select_action_frames
from uav_pure_visual_input import feedback,frame_metadata
from uav_mission_revision import MissionRevision
from uav_planner_context import normalize_model_plan
import uav_voice_command as voice
ZERO=dict(x=0.,y=0.,z=0.,yaw=0.)

def main():
    out=ROOT/'local-voice-test'/('full-pure-visual-'+time.strftime('%Y%m%d-%H%M%S'));out.mkdir();print('OUTPUT '+str(out),flush=True)
    runpy.run_path(str(ROOT/'scripts/test-deepseek-candidates.py'))['load_configuration']()
    eh=runpy.run_path(str(ROOT/'scripts/run-enhanced-control-simulation.py'));ui=runpy.run_path(str(ROOT/'scripts/run-static-world-vision.py'))
    vh=runpy.run_path(str(ROOT/'scripts/test-voice-deepseek-candidates.py'))
    world=DynamicWorld();frames=[];events=[];calls=[];api=[];voice_turns=[];recent=deque(maxlen=48);green_history=[];messages=[]
    mission=None;pipeline=None;literal=['red','purple'];seq=0;decision={};completed=False;failure=None;purple_ticks=0
    prev={k:getattr(world,k) for k in ('x','y','z','yaw')};latest=None;vision=None;pose=None
    sink=eh['video_sink'](out/'closed-loop.mp4',1280,720);rawsink=eh['video_sink'](out/'camera-input.mp4',880,480);pool=ThreadPoolExecutor(max_workers=1)
    def save(name,obj):
        temp=out/(name+'.tmp');temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');temp.replace(out/name)
    sources=['scripts/run-full-pure-visual-mission.py','runtime/uav_full_mission_preview.py','runtime/uav_dynamic_world.py','runtime/uav_pure_visual_input.py','runtime/uav_pure_visual_strategy.py','runtime/uav_model_visual_consistency.py','runtime/uav_mission_revision.py']
    manifest={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in sources}
    def checkpoint():
        save('result.json',dict(completed=completed,failure=failure,frames=frames,calls=calls,api_calls=api,voice_turns=voice_turns,events=events,
             contacts=list(world.contacts),world_balloons=BALLOONS,dynamics_parameters=PARAMETERS,source_hashes=manifest,
             replay_frames=0,fresh_initial_state=True,real_execution_allowed=False,sdk_calls=0,visual_call_budget=100,
             plan=mission.plan if mission else None,mission_status=mission.status if mission else 'initializing'))
    def event(kind,**data):
        e=dict(kind=kind,frame=len(frames),time_s=len(frames)/20,revision=mission.revision if mission else 0,**data);events.append(e);save('events.json',events);print('EVENT '+json.dumps(e,ensure_ascii=False),flush=True)
    def blocked(reason):return dict(arguments=None,reason=reason,execution_allowed=False,sdk_called=False)
    def tick(command,preview,phase,label,issued=None,evidence=None):
        nonlocal latest,vision,pose,prev
        k=len(frames);now=10000+k*50;latest=world.render();vision=detect_video_frame(latest,now,k);pose,state=eh['telemetry'](world,prev,now)
        if issued is not None and (mission is None or not mission.permits(issued)):command=dict(ZERO);preview=blocked('revision_not_authorized')
        if k%5==0:
            buf=io.BytesIO();latest.save(buf,format='PNG');recent.append(dict(frame=k,sim_time_s=k/20,phase=phase,png=buf.getvalue(),pose=dict(pose),velocity=world.flight_state()['velocity_world_mps']))
        if k%20==0 and any(d['color_name']=='green' for d in vision['detections']):
            name=f'memory-green-{k:05d}.png';latest.save(out/name);green_history.append(dict(frame=k,sim_time_s=k/20,image=name))
        if evidence:evidence.observe(latest,pose,k,now,command)
        canvas=ui['compose'](world,latest,{d['color_name']:d['bbox_xyxy'] for d in vision['detections']},decision,command,k/20,seq,label,False)
        d=ImageDraw.Draw(canvas);d.rectangle((20,15,1260,100),fill='#09131F');ui['text'](d,(24,20),'从头完整纯视觉测试 · 全程新 API 决策',28)
        ui['text'](d,(24,65),f'任务 {" → ".join(literal)} / '+(mission.status if mission else 'initializing')+' / '+label,18)
        d.rectangle((20,607,1260,717),fill='#09131F');ui['text'](d,(24,613),f"x {command['x']:+.2f} y {command['y']:+.2f} yaw {command['yaw']:+.1f} / 模型时长 {decision.get('duration_s',0):.2f} 秒",20)
        ui['text'](d,(24,653),'历史绿色画面 / 持续视觉 / 分析期间悬停 / 惯性与风扰保持',18)
        ui['text'](d,(24,686),f'真实 API 请求 {len(api)} / 视觉响应 {len(calls)} / 回放 0 帧 / SDK 0',16)
        sink.stdin.write(canvas.tobytes());rawsink.stdin.write(latest.tobytes())
        if k%100==0:canvas.save(out/'poster.png')
        before=world.flight_state();contacts=list(world.contacts);hits=world.integrate(command,.05)
        frames.append(dict(frame_index=k,sim_time_s=k/20,phase=phase,mission_revision=mission.revision if mission else 0,mission_status=mission.status if mission else 'initializing',issued_revision=issued,
            pose_before=dict(pose),pose_after={a:getattr(world,a) for a in pose},aircraft=state,vision=vision,plant_before=before,plant_after=world.flight_state(),
            model_call=seq,preview=preview,command=dict(command),contacts_before=contacts,contacts_this_frame=hits))
        prev=pose
        if hits:event('contact',colors=hits)
        if 'purple' in world.contacts:raise RuntimeError('purple contacted before voice revision')
    def settle():
        stable=0
        for _ in range(240):
            tick(dict(ZERO),blocked('braking'),'hold','制动稳定')
            stable=stable+1 if float(sum(v*v for v in world.v))**.5<.06 and abs(world.yr)<.3 and not any(world.applied.values()) else 0
            if stable>=10:return
        raise RuntimeError('hover_not_stable')
    def held(fn,label):
        settle();e=HoverEvidence(latest,pose,vision['frame_id'],vision['target_timestamp_ms']);future=pool.submit(fn)
        while True:
            started=time.monotonic();tick(dict(ZERO),blocked('analysis_hold'),'hold',label,evidence=e)
            try:return future.result(timeout=max(.001,.05-(time.monotonic()-started))),e.receipt()
            except TimeoutError:
                if future.done():raise
    def query(client,kind,outbound):
        row=dict(number=len(api)+1,kind=kind,started_at_frame=len(frames),status='pending');api.append(row);save('api-ledger.json',api)
        sanitized=copy.deepcopy(outbound)
        for m in sanitized:
            if isinstance(m['content'],list):
                for part in m['content']:
                    if part['type']=='image_url':part['image_url']={'sha256':hashlib.sha256(base64.b64decode(part['image_url']['url'].split(',',1)[1])).hexdigest()}
        save(f'outbound-api-{row["number"]:03d}.json',sanitized)
        try:
            response=client.chat.completions.create(model=os.environ['OPENAI_CHAT_MODEL_ID'],messages=outbound,response_format={'type':'json_object'},max_tokens=1800,temperature=0,extra_body={'thinking':{'type':'disabled'}})
            row.update(status='success',response_id=response.id,model=response.model,finished_at_frame=len(frames));save('api-ledger.json',api)
            raw=response.choices[0].message.content;save(f'raw-api-{row["number"]:03d}.json',dict(content=raw,response_id=response.id));return json.loads(raw),row
        except Exception as exc:row.update(status='error',error_type=type(exc).__name__);save('api-ledger.json',api);raise
    planner_system='''You are a simulation-only voice mission planner. Return ONLY JSON {"version":2,"actions":[{"capability":"strike_balloon","parameters":{"color":"pink"}}]}. Keep ordered full task and completed steps when revising. Groups: red/orange/pink -> pink; green/yellow -> yellow; purple/blue -> blue. Do not generate movement controls. Prior task and completed simulation events are context. User revision changes only specified pending step. Never authorize real hardware.'''
    visual_system=SYSTEM.replace('offline ideal velocity-following','offline inertial').replace('"approach"|"hold"|"done"','"approach"|"search_right"|"search_left"|"hold"|"done"').replace('0.1<=duration_s<=1.0','0.1<=duration_s<=3.0').replace('Prefer 0.5-1s segments when far, 0.1-0.5s near target.','Choose effective duration from image sequence and measured progress.')+STRATEGY+'''
The instruction's active_plan and current_target override example JSON. Target must remain the current mission target even when unseen. Only done after ALL ordered contacts may use null. Initial plan is red then purple; after voice interruption a NEW confirmed plan may replace pending purple with green. Never repeat completed red.
You receive raw current and recent camera frames, HISTORICAL GREEN SIGHTINGS, measured velocity and past actions only; no local boxes, bearing, depth, position or wind estimate. Infer geometry yourself. For unseen target use pure rotation search_left (negative yaw) or search_right (positive yaw); xyz zero. Use history to search, never as current bbox. All velocities and durations are generated by you. No hardware connected. Human confirmation applies to simulation only. Dynamics: delay .15s, velocity tau .45s, acceleration1.5m/s2; camera continues during braking/analysis. Latest image LAST provides current bbox.
'''
    save('system-prompts.json',dict(planner=planner_system,visual=visual_system))
    server=ThreadingHTTPServer(('127.0.0.1',0),vh['QuietAsrHandler']);thread=threading.Thread(target=server.serve_forever,daemon=True)
    endpoint=f'http://127.0.0.1:{server.server_port}/transcribe'
    env={'UAV_WHISPER_CLI':str(ROOT/'local-asr/whisper.cpp/build/bin/whisper-cli'),'UAV_WHISPER_MODEL':str(ROOT/'local-asr/whisper.cpp/models/ggml-base.bin'),'UAV_VOICE_ASR_STATE_DIR':str(out/'asr'),'UAV_VOICE_ASR_ENDPOINT':endpoint,'UAV_VOICE_ASR_FALLBACK_ENDPOINT':endpoint,'UAV_VOICE_ASR_TOKEN':secrets.token_urlsafe(24),'NO_PROXY':'127.0.0.1,localhost'}
    def voice_plan(client,text,name):
        if not (out/(name+'.pcm')).exists():held(lambda:vh['synthesize'](text,out/name,'Tingting'),'合成任务语音')
        transcript,asre=held(lambda:voice.transcribe(out/(name+'.pcm')),'本机语音识别')
        event('transcript',text=transcript,audio=name+'.wav')
        payload=dict(command=voice.normalize_transcript(transcript),prior_task=voice_turns,completed=list(world.contacts))
        (candidate,row),he=held(lambda:query(client,'voice_planning',[{'role':'system','content':planner_system},{'role':'user','content':json.dumps(payload,ensure_ascii=False)}]),'语音任务规划 / 悬停')
        plan=normalize_model_plan(candidate);turn=dict(command=transcript,plan=plan,audio=name+'.wav',api_number=row['number'],hover_evidence=he,asr_hover_evidence=asre);voice_turns.append(turn);save('voice-turns.json',voice_turns);return plan
    try:
        with patch.dict(os.environ,env),OpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=os.environ['OPENAI_BASE_URL'],timeout=45,max_retries=0) as client:
            thread.start();event('fresh_start',initial_state=world.flight_state())
            initial=voice_plan(client,'先撞红色气球，再撞紫色气球','initial')
            assert [a['parameters']['color'] for a in initial['actions']]==['pink','blue']
            mission=MissionRevision(initial);event('initial_task_authorized',source='user explicitly requested this simulation run',plan=initial)
            held(lambda:vh['synthesize']('把第二个改成绿色',out/'revision','Tingting'),'准备本轮途中修改语音')
            pipeline=FullMissionPreview(initial,literal,1)
            for _ in range(8000):
                now=10000+len(frames)*50
                if mission.revision==1 and world.contacts==['red'] and purple_ticks>=5 and pipeline.command is not None and now<pipeline.deadline:
                    old_revision=mission.revision;old_command=dict(pipeline.command or ZERO);remaining=pipeline.deadline-now;mission.interrupt(world.contacts);pipeline.close()
                    event('voice_interrupt',utterance='把第二个改成绿色',old_segment_remaining_ms=remaining,speed_mps=float(sum(v*v for v in world.v))**.5)
                    tick(old_command,blocked('stale_command_probe'),'hold','旧运动指令失效',issued=old_revision);event('old_segment_rejected')
                    settle();event('hover_stable',speed_mps=float(sum(v*v for v in world.v))**.5)
                    revised=voice_plan(client,'把第二个改成绿色','revision');request=mission.propose(revised)
                    save('confirmation-request.json',request);event('candidate_ready',plan=revised,remaining=['green']);checkpoint();print('AWAIT_CONFIRMATION '+str(out),flush=True)
                    while not (out/'confirmation.json').exists():
                        start=time.monotonic();tick(dict(ZERO),blocked('awaiting_human_confirmation'),'hold','等待本轮绿色任务人工确认');time.sleep(max(0,.05-(time.monotonic()-start)))
                    mission.confirm(json.loads((out/'confirmation.json').read_text()));event('human_confirmed',plan_hash=request['plan_hash'],scope='simulation_only')
                    tick(old_command,blocked('stale_response_probe'),'hold','拒绝旧版本迟到指令',issued=old_revision);event('late_old_response_rejected')
                    literal=['red','green'];messages=[];pipeline=FullMissionPreview(revised,literal,2)
                remaining=[c for c in literal if c not in world.contacts]
                if remaining and pipeline.target!=remaining[0]:pipeline.close();pipeline=FullMissionPreview(mission.plan,literal,literal.index(remaining[0])+1)
                now=10000+len(frames)*50
                if pipeline.command is None or now>=pipeline.deadline or not remaining:
                    if len(calls)>=100:settle();raise RuntimeError('visual_budget_100')
                    settle();seq+=1;snap=copy.deepcopy(world);input_frame=vision['frame_id'];im=latest.copy();measure=feedback(frames)
                    refs=[];parts=[{'type':'text','text':'RECENT TIME-ORDERED CAMERA FRAMES around latest motion; no local visual measurements.'}]
                    for sample in select_action_frames(recent):
                        name=f'temporal-{seq:03d}-{sample["frame"]}.png';(out/name).write_bytes(sample['png']);refs.append({**frame_metadata(sample),'image':name})
                        parts.extend([{'type':'text','text':json.dumps(frame_metadata(sample))},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(sample['png']).decode()}}])
                    indexes=sorted(set([0,len(green_history)//2,len(green_history)-1])) if green_history else []
                    history=[green_history[i] for i in indexes];memory=[{'type':'text','text':'HISTORICAL GREEN SIGHTINGS / 历史绿色画面. Earlier observations, NOT current visibility.'}]
                    for item in history:
                        memory.extend([{'type':'text','text':json.dumps({'frame':item['frame'],'sim_time_s':item['sim_time_s']})},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode((out/item['image']).read_bytes()).decode()}}])
                    name=f'input-{seq:03d}.png';im.save(out/name)
                    payload=dict(active_plan=literal,current_target=remaining[0] if remaining else None,completed=list(world.contacts),revision=mission.revision,human_confirmed=True,simulation_only=True,sim_time_s=input_frame/20,measured_feedback=measure)
                    current={'role':'user','content':[{'type':'text','text':json.dumps(payload,ensure_ascii=False)},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode((out/name).read_bytes()).decode()}}]}
                    outbound=[{'role':'system','content':visual_system},{'role':'user','content':memory},*messages[-4:],{'role':'user','content':parts},current]
                    (decision,row),he=held(lambda:query(client,'visual_motion',outbound),'真实视觉 API 分析 / 悬停')
                    call=dict(request=payload,response=decision,response_id=row['response_id'],api_number=row['number'],revision=mission.revision,hover_evidence=he,input_frame=input_frame,image=name,temporal_images=refs,historical_images=history)
                    calls.append(call);messages.extend([current,{'role':'assistant','content':json.dumps(decision,ensure_ascii=False)}]);save(f'call-{seq:03d}.json',call)
                    print('DECISION '+json.dumps({'call':seq,**decision},ensure_ascii=False),flush=True)
                    if not remaining:
                        if decision.get('mode')=='done' and decision.get('plan')==literal and not any(decision.get('velocity',ZERO).values()):
                            completed=True;settle()
                            for _ in range(40):tick(dict(ZERO),blocked('complete'),'complete','红色→绿色任务完成')
                            break
                        messages.append({'role':'user','content':'Contact events show all targets completed. Return done with zero motion.'});continue
                    error=check_self_consistency(decision)
                    if not he['hover_verified']:error='analysis_hover_not_verified'
                    if not error:error=pipeline.accept_model(decision,vision,frame_id=vision['frame_id'],image_timestamp_ms=vision['target_timestamp_ms'],received_timestamp_ms=vision['target_timestamp_ms'],sequence=seq)
                    call['acceptance_error']=error;save(f'call-{seq:03d}.json',call)
                    messages.append({'role':'user','content':'Rejected: '+error if error else 'Action accepted for simulation only.'})
                    if error:pipeline.close();continue
                now=10000+len(frames)*50;v=detect_video_frame(world.render(),now,len(frames));_,state=eh['telemetry'](world,prev,now)
                preview=pipeline.step({'now_ms':now,'vision':v,'aircraft':state});command=preview['arguments'] or dict(ZERO)
                tick(command,preview,'revised_motion','模型短时运动',issued=mission.revision)
                if mission.revision==1 and pipeline.target=='purple' and command['x']>0:purple_ticks+=1
            if not completed:failure='not_completed'
    except KeyboardInterrupt:failure='interrupted'
    except Exception as exc:failure=type(exc).__name__;print('ERROR '+failure,flush=True)
    finally:
        if pipeline:pipeline.close()
        pool.shutdown(wait=True)
        if thread.is_alive():server.shutdown();thread.join(timeout=2)
        server.server_close()
        for p in (sink,rawsink):p.stdin.close();p.wait()
        save('visual-memory.json',green_history);checkpoint();print('RESULT '+json.dumps({'output':str(out),'completed':completed,'contacts':world.contacts,'api_requests':len(api),'visual_responses':len(calls),'failure':failure}),flush=True)
if __name__=='__main__':main()
