<#
.SYNOPSIS
Stages and optionally deploys the Python runtime and service files to code10.
.DESCRIPTION
Without -Apply the script prints a deployment plan only. With -Apply it checks
the remote hostname, creates a timestamped device backup, copies the selected
runtime overlay, and optionally installs/restarts services. Credentials are
provided by SSH configuration and are never written into the repository.
#>
[CmdletBinding()]
param(
    [string]$HostName = '192.168.55.1',
    [string]$UserName = 'uav',
    [string]$ExpectedRemoteHostName = 'code10',
    [string]$RuntimeRoot = '/home/uav/offline_balloon_strike_test',
    [switch]$InstallServices,
    [switch]$RestartMainService,
    [switch]$Apply
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$remote = "${UserName}@${HostName}"
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$remoteStage = "/tmp/uav-runtime-overlay-$stamp"
$backupRoot = "$RuntimeRoot/backups/repo_runtime_$stamp"

$runtimeFiles = @(
    'balloon_yolo_worker.py',
    'balloon_tensorrt.py',
    'balloon_tracker_worker.py',
    'balloon_liveview_decoder.py',
    'uav_capabilities.py',
    'uav_natural_language.py',
    'stage_pink_yellow_test.py',
    'uav_voice_command.py',
    'uav_planner_context.py',
    'uav_planner_knowledge.md',
    'detect_latest_photo.py',
    'wait_for_psdk_link.sh'
)

$runtimeExecutableFiles = @(
    'wait_for_psdk_link.sh'
)

$systemScriptFiles = @(
    'uav-log-maintenance.sh'
)

$serviceFiles = @(
    'psdk-balloon.service',
    'balloon-yolo-worker.service',
    'balloon-tracker-worker.service',
    'balloon-liveview-decoder.service',
    'uav-natural-language.service',
    'uav-log-maintenance.service',
    'uav-log-maintenance.timer'
)

Write-Host "Target: $remote"
Write-Host "Required remote hostname: $ExpectedRemoteHostName"
Write-Host "Runtime root: $RuntimeRoot"
Write-Host 'Runtime files:'
$runtimeFiles | ForEach-Object { Write-Host "  runtime/$_ -> $RuntimeRoot/$_" }
$systemScriptFiles | ForEach-Object {
    Write-Host "  scripts/$_ -> /usr/local/sbin/$($_ -replace '\.sh$', '')"
}
if ($InstallServices) {
    Write-Host 'Systemd units:'
    $serviceFiles | ForEach-Object { Write-Host "  systemd/$_ -> /etc/systemd/system/$_" }
}

if (-not $Apply) {
    Write-Host 'Dry plan only. Re-run with -Apply after confirming the aircraft is secured.'
    exit 0
}

$actualRemoteHostName = ((ssh $remote 'hostname') -join "`n").Trim()
if ($LASTEXITCODE -ne 0 -or $actualRemoteHostName -ne $ExpectedRemoteHostName) {
    throw "Refusing deployment: connected host '$actualRemoteHostName' is not expected host '$ExpectedRemoteHostName'."
}

$show = ssh $remote "systemctl show psdk-balloon.service -p ActiveState -p Environment --no-pager"
$showText = $show -join "`n"
if ($LASTEXITCODE -ne 0 -or $showText -notmatch 'ActiveState=active' -or $showText -notmatch 'BALLOON_NO_FLIGHT=1') {
    throw 'Refusing deployment: effective systemd state must be active with BALLOON_NO_FLIGHT=1.'
}

ssh $remote "mkdir -p '$remoteStage'"
if ($LASTEXITCODE -ne 0) { throw 'Failed to create remote staging directory.' }

foreach ($name in $runtimeFiles) {
    $local = Join-Path $repoRoot "runtime/$name"
    if (-not (Test-Path -LiteralPath $local)) { throw "Missing local file: $local" }
    scp $local "${remote}:$remoteStage/$name"
    if ($LASTEXITCODE -ne 0) { throw "Upload failed: runtime/$name" }
}

foreach ($name in $systemScriptFiles) {
    $local = Join-Path $repoRoot "scripts/$name"
    if (-not (Test-Path -LiteralPath $local)) { throw "Missing local file: $local" }
    scp $local "${remote}:$remoteStage/$name"
    if ($LASTEXITCODE -ne 0) { throw "Upload failed: scripts/$name" }
}

if ($InstallServices) {
    foreach ($name in $serviceFiles) {
        $local = Join-Path $repoRoot "systemd/$name"
        if (-not (Test-Path -LiteralPath $local)) { throw "Missing local file: $local" }
        scp $local "${remote}:$remoteStage/$name"
        if ($LASTEXITCODE -ne 0) { throw "Upload failed: systemd/$name" }
    }
}

ssh -t $remote "sudo mkdir -p '$backupRoot' '$RuntimeRoot'"
if ($LASTEXITCODE -ne 0) { throw 'Failed to create runtime backup directory.' }

foreach ($name in $runtimeFiles) {
    $target = "$RuntimeRoot/$name"
    $mode = if ($runtimeExecutableFiles -contains $name) { '0755' } else { '0644' }
    ssh -t $remote "if sudo test -e '$target'; then sudo cp '$target' '$backupRoot/$name'; fi; sudo install -m $mode '$remoteStage/$name' '$target'"
    if ($LASTEXITCODE -ne 0) { throw "Remote install failed: $target" }
}

foreach ($name in $systemScriptFiles) {
    $targetName = $name -replace '\.sh$', ''
    $target = "/usr/local/sbin/$targetName"
    ssh -t $remote "if sudo test -e '$target'; then sudo cp '$target' '$backupRoot/$targetName'; fi; sudo install -m 0755 '$remoteStage/$name' '$target'"
    if ($LASTEXITCODE -ne 0) { throw "Remote install failed: $target" }
}

if ($InstallServices) {
    foreach ($name in $serviceFiles) {
        $target = "/etc/systemd/system/$name"
        ssh -t $remote "if sudo test -e '$target'; then sudo cp '$target' '$backupRoot/$name'; fi; sudo install -m 0644 '$remoteStage/$name' '$target'"
        if ($LASTEXITCODE -ne 0) { throw "Remote install failed: $target" }
    }
    ssh -t $remote 'sudo systemctl daemon-reload'
    if ($LASTEXITCODE -ne 0) { throw 'systemd daemon-reload failed.' }
    ssh -t $remote 'sudo systemctl enable psdk-balloon.service balloon-yolo-worker.service balloon-liveview-decoder.service balloon-tracker-worker.service uav-natural-language.service uav-log-maintenance.timer'
    if ($LASTEXITCODE -ne 0) { throw 'Failed to enable the complete balloon service set.' }
} else {
    ssh $remote 'systemctl cat balloon-tracker-worker.service >/dev/null'
    if ($LASTEXITCODE -ne 0) {
        throw 'Tracker service is not installed. Re-run with -InstallServices -Apply.'
    }
    ssh $remote 'systemctl cat uav-natural-language.service >/dev/null'
    if ($LASTEXITCODE -ne 0) {
        throw 'Natural-language service is not installed. Re-run with -InstallServices -Apply.'
    }
}

ssh -t $remote "sudo systemctl restart balloon-yolo-worker.service balloon-liveview-decoder.service balloon-tracker-worker.service uav-natural-language.service"
if ($LASTEXITCODE -ne 0) { throw 'Service restart failed.' }

if ($RestartMainService) {
    ssh -t $remote 'sudo systemctl restart psdk-balloon.service'
    if ($LASTEXITCODE -ne 0) { throw 'Main PSDK service restart failed.' }
}

$final = ssh $remote "systemctl show psdk-balloon.service -p ActiveState -p MainPID -p Environment --no-pager; systemctl is-active balloon-yolo-worker.service balloon-liveview-decoder.service balloon-tracker-worker.service uav-natural-language.service"
$finalText = $final -join "`n"
if ($LASTEXITCODE -ne 0 -or $finalText -notmatch 'ActiveState=active' -or $finalText -notmatch 'BALLOON_NO_FLIGHT=1') {
    throw 'Final verification failed; inspect the five service logs and restore the timestamped backup if required.'
}

Write-Host $finalText
Write-Host "Runtime deployment completed. Backup: $backupRoot"
