#!/usr/bin/env python3
"""Post-run comparison. Detector-derived metrics stay offline, never go to API."""
import json,runpy,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
audit=runpy.run_path(str(ROOT/'scripts/verify-pure-visual-input.py'))['verify']

def metrics(path):
    audit(path);r=json.loads((path/'result.json').read_text());start=r['comparison_checkpoint_frame'];previous=False;losses=[]
    motion={f['model_call'] for f in r['frames'][start:] if f['phase']=='revised_motion' and f['preview'].get('arguments') is not None}
    for f in r['frames'][start:]:
        visible=any(d['color_name']=='green' for d in f['vision']['detections'])
        if previous and not visible and 'green' not in f['contacts_before']:losses.append(f['sim_time_s'])
        previous=visible
    small=[i for i in motion if 0<r['calls'][i-1]['response']['velocity']['x']<=.15 and r['calls'][i-1]['response']['duration_s']<=.5]
    m=json.loads((path/'adaptive-verification.json').read_text());m.update(target_loss_events_before_contact=losses,small_forward_decisions=small,small_forward_definition='executed model segment: 0 < x <= 0.15 m/s and requested duration <= 0.5 s')
    return r,m

if __name__=='__main__':
    paths=[Path(p).resolve() for p in sys.argv[1:]];assert len(paths)==2
    (a,ma),(b,mb)=[metrics(p) for p in paths];cut=a['comparison_checkpoint_frame']
    assert cut==b['comparison_checkpoint_frame'] and a['frames'][:cut]==b['frames'][:cut]
    assert a['dynamics_parameters']==b['dynamics_parameters'] and a['world_balloons']==b['world_balloons']
    for key in ('runtime/uav_dynamic_world.py','runtime/uav_adaptive_segment.py','runtime/uav_pure_visual_input.py'):
        assert a['source_hashes'][key]==b['source_hashes'][key]
    for p in paths[0].glob('memory-*.png'):
        assert p.read_bytes()==(paths[1]/p.name).read_bytes()
    report=dict(same_initial_checkpoint_dynamics_monitors_and_historical_images=True,baseline=ma,improved=mb,
                api_response_reduction_percent=(1-mb['real_visual_responses']/ma['real_visual_responses'])*100,
                caveat='Single actual API trial per strategy. Latency and trajectories differ; not a statistical success-rate claim. Red/voice revision prefix is replayed, green control is new real API.')
    (paths[1]/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
