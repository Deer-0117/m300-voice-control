#!/bin/sh
# Synchronize code10 from code12 through a forced-command SSH key.  TLS clients
# depend on a sane clock, while the restricted key is intentionally unable to
# open a shell or execute arbitrary commands.
set -eu

attempts=${UAV_CODE12_TIME_SYNC_ATTEMPTS:-45}
retry_delay=${UAV_CODE12_TIME_SYNC_RETRY_DELAY_SEC:-5}
attempt=1

while [ "$attempt" -le "$attempts" ]; do
  epoch=$(
    /usr/bin/ssh \
      -o BatchMode=yes \
      -o ConnectionAttempts=1 \
      -o ConnectTimeout=3 \
      -o ServerAliveInterval=2 \
      -o ServerAliveCountMax=1 \
      -o StrictHostKeyChecking=yes \
      -o UserKnownHostsFile=/home/uav/.ssh/known_hosts_code12_time \
      -i /home/uav/.ssh/code10_code12_time_ed25519 \
      uav@192.168.168.222 2>/dev/null || true
  )

  case "$epoch" in
    ''|*[!0-9]*) valid=0 ;;
    *)
      if [ "$epoch" -ge 1700000000 ]; then
        valid=1
      else
        valid=0
      fi
      ;;
  esac

  if [ "$valid" -eq 1 ]; then
    /usr/bin/date -u -s "@$epoch" >/dev/null
    echo "code10 clock synchronized from code12 on attempt $attempt"
    exit 0
  fi

  if [ "$attempt" -lt "$attempts" ]; then
    echo "code12 time source unavailable; retrying ($attempt/$attempts)" >&2
    /usr/bin/sleep "$retry_delay"
  fi
  attempt=$((attempt + 1))
done

echo "code12 time source remained unavailable after $attempts attempts" >&2
exit 1
