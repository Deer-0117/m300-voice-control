#!/usr/bin/env bash
# Install a last-sorting systemd safety override and verify the effective
# service environment.  This script disables aircraft joystick output only;
# the gimbal can still move and therefore still requires a clear work area.
set -euo pipefail

SERVICE="psdk-balloon.service"
DROPIN_DIR="/etc/systemd/system/${SERVICE}.d"
ARCHIVE_DIR="/etc/systemd/system/${SERVICE}.d.disabled-no-flight-$(date +%Y%m%d_%H%M%S)"
DROPIN="${DROPIN_DIR}/zzzzzzzzzzzzzzzzzzzzzzzzzzzz-final-safety.conf"

sudo mkdir -p "$DROPIN_DIR"

# A later-sorting historical real-flight drop-in would override a newly
# written safety value. Move every active *.conf that explicitly requests
# real flight out of the drop-in directory before restarting the service.
while IFS= read -r unsafe_file; do
    [ -n "$unsafe_file" ] || continue
    sudo mkdir -p "$ARCHIVE_DIR"
    sudo mv "$unsafe_file" "$ARCHIVE_DIR/"
done < <(sudo grep -Il '^Environment=BALLOON_NO_FLIGHT=0$' "$DROPIN_DIR"/*.conf 2>/dev/null || true)

printf '%s\n' \
    '[Service]' \
    '# Final safety override; project camera-exposure control is also disabled.' \
    'Environment=BALLOON_NO_FLIGHT=1' \
    'Environment=BALLOON_AUTO_EXPOSURE=0' |
    sudo tee "$DROPIN" >/dev/null
sudo systemctl daemon-reload
sudo systemctl restart "$SERVICE"

state="$(systemctl show "$SERVICE" -p ActiveState --value)"
main_pid="$(systemctl show "$SERVICE" -p MainPID --value)"
environment="$(systemctl show "$SERVICE" -p Environment --value)"
printf 'ActiveState=%s\nMainPID=%s\nEnvironment=%s\n' "$state" "$main_pid" "$environment"

if [[ "$state" != "active" || "$main_pid" == "0" || "$environment" != *"BALLOON_NO_FLIGHT=1"* ]]; then
  echo "ERROR: no-flight safety verification failed" >&2
  exit 1
fi

process_environment="$(sudo cat "/proc/${main_pid}/environ" | tr '\0' '\n')"
if ! grep -qx 'BALLOON_NO_FLIGHT=1' <<<"$process_environment"; then
  echo "ERROR: running process does not contain BALLOON_NO_FLIGHT=1" >&2
  exit 1
fi

echo "SAFE: systemd and running process both contain BALLOON_NO_FLIGHT=1"

