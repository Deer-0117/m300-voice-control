<#
.SYNOPSIS
Stages and optionally deploys the C/PSDK source overlay to the target UAV.
.DESCRIPTION
The default mode is read-only planning. -Apply performs host checks, preserves
the overwritten remote files in a timestamped backup, rebuilds the PSDK sample,
and leaves validation evidence in the command output.
#>
[CmdletBinding()]
param(
    [string]$HostName = '192.168.55.1',
    [string]$UserName = 'uav',
    [string]$ExpectedRemoteHostName = 'code10',
    [string]$SdkRoot = '/home/uav/yanshou_uav/uavs_psdk/psdk_dji_3.9.2_cpp_json',
    [switch]$Apply
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$remote = "${UserName}@${HostName}"
$buildDir = "$SdkRoot/samples/sample_c++/platform/linux/manifold2/build_cpp_json_minimal_c_linux"
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$remoteStage = "/tmp/uav-control-overlay-$stamp"

$files = @(
    @{ Local = 'src/target_chase/target_chase.c'; Remote = 'samples/sample_c/module_sample/target_chase/target_chase.c' },
    @{ Local = 'src/target_chase/target_chase.h'; Remote = 'samples/sample_c/module_sample/target_chase/target_chase.h' },
    @{ Local = 'src/target_chase/dji_target_chase_task.c'; Remote = 'samples/sample_c/module_sample/target_chase/dji_target_chase_task.c' },
    @{ Local = 'src/target_chase/dji_target_chase_task.h'; Remote = 'samples/sample_c/module_sample/target_chase/dji_target_chase_task.h' },
    @{ Local = 'src/balloon_widget/balloon_photo_detector.c'; Remote = 'samples/sample_c/module_sample/balloon_widget/balloon_photo_detector.c' },
    @{ Local = 'src/balloon_widget/balloon_photo_detector.h'; Remote = 'samples/sample_c/module_sample/balloon_widget/balloon_photo_detector.h' },
    @{ Local = 'src/balloon_widget/psdk_balloon_widget.c'; Remote = 'samples/sample_c/module_sample/balloon_widget/psdk_balloon_widget.c' },
    @{ Local = 'src/balloon_widget/psdk_balloon_widget.h'; Remote = 'samples/sample_c/module_sample/balloon_widget/psdk_balloon_widget.h' },
    @{ Local = 'src/balloon_widget/widget_file/cn_big_screen/widget_config.json'; Remote = 'samples/sample_c/module_sample/balloon_widget/widget_file/cn_big_screen/widget_config.json'; Stage = 'widget_config_cn.json' },
    @{ Local = 'src/balloon_widget/widget_file/en_big_screen/widget_config.json'; Remote = 'samples/sample_c/module_sample/balloon_widget/widget_file/en_big_screen/widget_config.json'; Stage = 'widget_config_en.json' }
)

Write-Host "Target: $remote"
Write-Host "SDK root: $SdkRoot"
Write-Host 'Files:'
$files | ForEach-Object { Write-Host "  $($_.Local) -> $($_.Remote)" }

if (-not $Apply) {
    Write-Host 'Dry plan only. Re-run with -Apply after confirming the aircraft is secured.'
    exit 0
}

$actualRemoteHostName = ((ssh $remote 'hostname') -join "`n").Trim()
if ($LASTEXITCODE -ne 0 -or $actualRemoteHostName -ne $ExpectedRemoteHostName) {
    throw "Refusing deployment: connected host '$actualRemoteHostName' is not expected host '$ExpectedRemoteHostName'."
}

$show = ssh $remote "systemctl show psdk-balloon.service -p ActiveState -p Environment --no-pager"
$showText = $show -join "`n"
if ($LASTEXITCODE -ne 0 -or $showText -notmatch 'ActiveState=active' -or $showText -notmatch 'BALLOON_NO_FLIGHT=1') {
    throw 'Refusing deployment: effective systemd state must be active with BALLOON_NO_FLIGHT=1.'
}

ssh $remote "mkdir -p '$remoteStage' '$SdkRoot/backups/repo_deploy_$stamp'"
if ($LASTEXITCODE -ne 0) { throw 'Failed to create remote staging/backup directories.' }

foreach ($item in $files) {
    $local = Join-Path $repoRoot $item.Local
    if (-not (Test-Path -LiteralPath $local)) { throw "Missing local file: $local" }
    $remoteName = if ($item.Stage) { $item.Stage } else { [IO.Path]::GetFileName($item.Remote) }
    scp $local "${remote}:$remoteStage/$remoteName"
    if ($LASTEXITCODE -ne 0) { throw "Upload failed: $($item.Local)" }
}

foreach ($item in $files) {
    $remoteName = if ($item.Stage) { $item.Stage } else { [IO.Path]::GetFileName($item.Remote) }
    $target = "$SdkRoot/$($item.Remote)"
    ssh -t $remote "sudo cp '$target' '$SdkRoot/backups/repo_deploy_$stamp/$remoteName' && sudo install -m 0644 '$remoteStage/$remoteName' '$target'"
    if ($LASTEXITCODE -ne 0) { throw "Remote install failed: $($item.Remote)" }
}

ssh -t $remote "sudo cmake --build '$buildDir' --clean-first -j2"
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Restore files from the timestamped backup before continuing.' }

ssh -t $remote "sudo systemctl restart psdk-balloon.service && systemctl show psdk-balloon.service -p ActiveState -p MainPID -p Environment --no-pager"
if ($LASTEXITCODE -ne 0) { throw 'Service restart or final verification failed.' }

Write-Host "Deployment completed. Backup: $SdkRoot/backups/repo_deploy_$stamp"
