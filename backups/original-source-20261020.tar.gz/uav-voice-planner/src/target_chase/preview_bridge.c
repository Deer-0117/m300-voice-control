/* Offline-only bridge. Links only the platform-independent controller, no PSDK. */
#include "target_chase.h"
#include <stdlib.h>

void *Preview_Create(float width, float height, float hfov, float vfov)
{
    T_TargetChaseController *c = calloc(1, sizeof(*c));
    T_TargetChaseConfig cfg = TargetChase_DefaultConfig(width, height, hfov, vfov);
    if (c) TargetChase_Init(c, &cfg);
    return c;
}
void Preview_Destroy(void *p) { free(p); }
/* v: altitude, velocity NEU[3], attitude RPY[3], angular velocity[3], boresight[2], box[4]. */
int Preview_Step(void *p, const float *v, unsigned long long now,
                 unsigned long long state_ts, unsigned long long target_ts, float *out)
{
    T_TargetChaseController *c = p;
    T_TargetChaseAircraftState s = {0};
    T_TargetChaseCommand command = {0};
    s.altitude_agl_m = v[0];
    for (int i = 0; i < 3; ++i) {
        s.velocity_neu_mps[i] = v[1+i];
        s.attitude_deg[i] = v[4+i];
        s.angular_rate_radps[i] = v[7+i];
    }
    s.in_air = true; s.velocity_healthy = true; s.timestamp_ms = state_ts;
    TargetChase_UpdateAircraftState(c, &s);
    TargetChase_SetCameraBoresight(c, v[10], v[11]);
    TargetChase_UpdateTargetBox(c, v[12], v[13], v[14], v[15], target_ts);
    /* Hypothetical permission is validated by caller; never obtains aircraft permission. */
    if (!c->manual_trigger_enabled) TargetChase_SetManualTrigger(c, true, now);
    if (!c->has_authority) TargetChase_SetAuthority(c, true, now);
    int ok = TargetChase_Step(c, now, &command);
    out[0] = command.x_mps; out[1] = command.y_mps;
    out[2] = command.z_mps; out[3] = command.yaw_rate_degps;
    return ok && command.should_send;
}
