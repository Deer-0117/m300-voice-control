/*
 * DJI Pilot Widget bridge for offline balloon strike tests.
 *
 * Integration point:
 *   Call BalloonWidget_StartService(...) after PSDK platform/application
 *   initialization. The function registers four Widget buttons and an optional
 *   UI config directory.
 *
 * This module does not call flight-control APIs. The flight-test buttons write
 * local state files and the network button performs a bounded asynchronous TCP
 * probe to the configured gateway board.
 */

#include "psdk_balloon_widget.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#include "dji_error.h"
#include "dji_logger.h"
#include "dji_widget.h"
#include "balloon_widget/balloon_photo_detector.h"
#include "widget/test_widget_speaker.h"

#define BALLOON_WIDGET_PREPARE_INDEX        0
#define BALLOON_WIDGET_START_INDEX          1
#define BALLOON_WIDGET_STOP_INDEX           2
#define BALLOON_WIDGET_PREPARE_CONFIG_INDEX 3
#define BALLOON_WIDGET_START_CONFIG_INDEX   4
#define BALLOON_WIDGET_STOP_CONFIG_INDEX    5
#define BALLOON_WIDGET_NETWORK_INDEX        6
#define BALLOON_WIDGET_NETWORK_CONFIG_INDEX 7
#define BALLOON_WIDGET_VOICE_CONFIRM_INDEX  8
#define BALLOON_WIDGET_VOICE_CANCEL_INDEX   9
#define BALLOON_WIDGET_VOICE_CONFIRM_CONFIG_INDEX 10
#define BALLOON_WIDGET_VOICE_CANCEL_CONFIG_INDEX  11
#define BALLOON_WIDGET_PINK_YELLOW_INDEX    12
#define BALLOON_WIDGET_PINK_YELLOW_CONFIG_INDEX 13
#define BALLOON_WIDGET_COUNT                14
#define BALLOON_WIDGET_PATH_SIZE     256
#define BALLOON_NETWORK_DEFAULT_HOST "192.168.168.222"
#define BALLOON_NETWORK_DEFAULT_PORT 22U
#define BALLOON_NETWORK_DEFAULT_TIMEOUT_MS 2000
#define BALLOON_NETWORK_MIN_TIMEOUT_MS 200
#define BALLOON_NETWORK_MAX_TIMEOUT_MS 10000
#define BALLOON_LATEST_TARGET_FILE "/home/uav/offline_balloon_strike_test/latest_target.tsv"
#define BALLOON_LATEST_PHOTO_FILE "/tmp/balloon_latest_photo.txt"
#define BALLOON_DETECTION_REQUEST_FILE "/home/uav/offline_balloon_strike_test/latest_detection_request.tsv"
#define BALLOON_DETECTION_REQUEST_TMP_FILE "/home/uav/offline_balloon_strike_test/latest_detection_request.tsv.tmp"
#define BALLOON_NL_STOP_FILE "/tmp/balloon_nl_stop.request"
#define BALLOON_NL_PLAN_FILE "/home/uav/offline_balloon_strike_test/nl_task_plan.json"
#define BALLOON_NL_STATE_FILE "/home/uav/offline_balloon_strike_test/nl_task_state.json"
#define BALLOON_VOICE_PCM_DEFAULT "/home/uav/yanshou_uav/uavs_psdk/psdk_dji_3.9.2_cpp_json/samples/sample_c++/platform/linux/manifold2/build_cpp_json_minimal_c_linux/bin/test_audio.pcm"
#define BALLOON_VOICE_HELPER "/home/uav/offline_balloon_strike_test/uav_voice_command.py"
#define BALLOON_VOICE_PYTHON "/home/uav/offline_balloon_strike_test/yolo_env/bin/python"
#define BALLOON_VOICE_MESSAGE_FILE "/tmp/balloon_voice_message.txt"
#define BALLOON_PINK_YELLOW_HELPER "/home/uav/offline_balloon_strike_test/stage_pink_yellow_test.py"
#define BALLOON_PINK_YELLOW_MESSAGE_FILE "/tmp/balloon_pink_yellow_test.log"

static char s_armedFilePath[BALLOON_WIDGET_PATH_SIZE] = "/tmp/balloon_strike.armed";
static char s_triggerFilePath[BALLOON_WIDGET_PATH_SIZE] = "/tmp/balloon_strike.trigger";
static char s_stopFilePath[BALLOON_WIDGET_PATH_SIZE] = "/tmp/balloon_strike.stop";
static int32_t s_widgetValue[BALLOON_WIDGET_COUNT] = {0};
static bool s_isArmed = false;
static bool s_networkTestRunning = false;
static pthread_mutex_t s_networkTestMutex = PTHREAD_MUTEX_INITIALIZER;
static bool s_voiceCommandRunning = false;
static pthread_mutex_t s_voiceCommandMutex = PTHREAD_MUTEX_INITIALIZER;
static bool s_pinkYellowTaskRunning = false;
static bool s_pinkYellowTaskCancelled = false;
static bool s_pinkYellowPlanSelected = false;
static bool s_pinkYellowPlanReady = false;
static pthread_mutex_t s_pinkYellowTaskMutex = PTHREAD_MUTEX_INITIALIZER;

static T_DjiReturnCode BalloonWidget_SetValue(E_DjiWidgetType widgetType, uint32_t index, int32_t value, void *userData);
static T_DjiReturnCode BalloonWidget_GetValue(E_DjiWidgetType widgetType, uint32_t index, int32_t *value, void *userData);
static void SafeCopyPath(char *dst, size_t dstSize, const char *src);

static void BalloonWidget_ResetButtonValues(void)
{
    uint32_t index;

    for (index = 0; index < BALLOON_WIDGET_COUNT; ++index) {
        s_widgetValue[index] = DJI_WIDGET_BUTTON_STATE_RELEASE_UP;
    }
}

static const T_DjiWidgetHandlerListItem s_widgetHandlerList[] = {
    {BALLOON_WIDGET_PREPARE_INDEX,        DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_START_INDEX,          DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_STOP_INDEX,           DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_PREPARE_CONFIG_INDEX, DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_START_CONFIG_INDEX,   DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_STOP_CONFIG_INDEX,    DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_NETWORK_INDEX,        DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_NETWORK_CONFIG_INDEX, DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_VOICE_CONFIRM_INDEX,  DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_VOICE_CANCEL_INDEX,   DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_VOICE_CONFIRM_CONFIG_INDEX, DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_VOICE_CANCEL_CONFIG_INDEX,  DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_PINK_YELLOW_INDEX, DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
    {BALLOON_WIDGET_PINK_YELLOW_CONFIG_INDEX, DJI_WIDGET_TYPE_BUTTON, BalloonWidget_SetValue, BalloonWidget_GetValue, NULL},
};

typedef enum {
    BALLOON_VOICE_RECOGNIZE = 0,
    BALLOON_VOICE_CONFIRM,
    BALLOON_VOICE_CANCEL,
} E_BalloonVoiceAction;

typedef struct {
    E_BalloonVoiceAction action;
    char pcmPath[BALLOON_WIDGET_PATH_SIZE];
} T_BalloonVoiceTask;

typedef enum {
    BALLOON_NETWORK_RESULT_SUCCESS = 0,
    BALLOON_NETWORK_RESULT_FAILED,
    BALLOON_NETWORK_RESULT_EXCEPTION,
} E_BalloonNetworkResult;

static const char *BalloonWidget_ModeText(void)
{
    const char *value = getenv("BALLOON_NO_FLIGHT");

    if (value == NULL || value[0] == '\0' ||
        strcmp(value, "0") == 0 ||
        strcmp(value, "false") == 0 ||
        strcmp(value, "FALSE") == 0 ||
        strcmp(value, "off") == 0 ||
        strcmp(value, "OFF") == 0) {
        return "FLIGHT";
    }

    return "NO_FLIGHT";
}

static void BalloonWidget_ShowStep(const char *step, const char *detail)
{
    char message[256];

    snprintf(message, sizeof(message),
             "Balloon step: %s | mode=%s | %s",
             step == NULL ? "unknown" : step,
             BalloonWidget_ModeText(),
             detail == NULL ? "" : detail);
    DjiWidgetFloatingWindow_ShowMessage(message);
}

static void BalloonWidget_ShowNetworkResult(E_BalloonNetworkResult result)
{
    switch (result) {
        case BALLOON_NETWORK_RESULT_SUCCESS:
            DjiWidgetFloatingWindow_ShowMessage("联网：连接成功");
            break;
        case BALLOON_NETWORK_RESULT_FAILED:
            DjiWidgetFloatingWindow_ShowMessage("联网：连接失败");
            break;
        default:
            DjiWidgetFloatingWindow_ShowMessage("联网：连接异常");
            break;
    }
}

static uint16_t BalloonWidget_NetworkPort(void)
{
    const char *value = getenv("BALLOON_NETWORK_TEST_PORT");
    char *end = NULL;
    unsigned long port;

    if (value == NULL || value[0] == '\0') {
        return BALLOON_NETWORK_DEFAULT_PORT;
    }
    errno = 0;
    port = strtoul(value, &end, 10);
    if (errno != 0 || end == value || *end != '\0' || port == 0 || port > 65535UL) {
        return 0;
    }
    return (uint16_t) port;
}

static int BalloonWidget_NetworkTimeoutMs(void)
{
    const char *value = getenv("BALLOON_NETWORK_TEST_TIMEOUT_MS");
    char *end = NULL;
    long timeoutMs;

    if (value == NULL || value[0] == '\0') {
        return BALLOON_NETWORK_DEFAULT_TIMEOUT_MS;
    }
    errno = 0;
    timeoutMs = strtol(value, &end, 10);
    if (errno != 0 || end == value || *end != '\0' ||
        timeoutMs < BALLOON_NETWORK_MIN_TIMEOUT_MS ||
        timeoutMs > BALLOON_NETWORK_MAX_TIMEOUT_MS) {
        return -1;
    }
    return (int) timeoutMs;
}

static bool BalloonWidget_IsExpectedConnectFailure(int errorCode)
{
    return errorCode == ECONNREFUSED ||
           errorCode == ETIMEDOUT ||
           errorCode == ENETUNREACH ||
           errorCode == EHOSTUNREACH ||
           errorCode == ENETDOWN ||
           errorCode == EHOSTDOWN;
}

static E_BalloonNetworkResult BalloonWidget_ProbeNetwork(const char *host,
                                                         uint16_t port,
                                                         int timeoutMs,
                                                         int *detailError)
{
    struct sockaddr_in address;
    struct pollfd pollFd;
    int socketFd = -1;
    int flags;
    int pollResult;
    int socketError = 0;
    socklen_t socketErrorSize = sizeof(socketError);
    E_BalloonNetworkResult result = BALLOON_NETWORK_RESULT_EXCEPTION;

    *detailError = 0;
    if (host == NULL || host[0] == '\0' || port == 0 || timeoutMs < 0) {
        return BALLOON_NETWORK_RESULT_EXCEPTION;
    }

    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    if (inet_pton(AF_INET, host, &address.sin_addr) != 1) {
        return BALLOON_NETWORK_RESULT_EXCEPTION;
    }

    socketFd = socket(AF_INET, SOCK_STREAM, 0);
    if (socketFd < 0) {
        *detailError = errno;
        return BALLOON_NETWORK_RESULT_EXCEPTION;
    }
    flags = fcntl(socketFd, F_GETFL, 0);
    if (flags < 0 || fcntl(socketFd, F_SETFL, flags | O_NONBLOCK) < 0) {
        *detailError = errno;
        close(socketFd);
        return BALLOON_NETWORK_RESULT_EXCEPTION;
    }

    if (connect(socketFd, (struct sockaddr *) &address, sizeof(address)) == 0) {
        result = BALLOON_NETWORK_RESULT_SUCCESS;
        goto out;
    }
    if (errno != EINPROGRESS) {
        *detailError = errno;
        result = BalloonWidget_IsExpectedConnectFailure(errno) ?
                 BALLOON_NETWORK_RESULT_FAILED : BALLOON_NETWORK_RESULT_EXCEPTION;
        goto out;
    }

    pollFd.fd = socketFd;
    pollFd.events = POLLOUT;
    pollFd.revents = 0;
    do {
        pollResult = poll(&pollFd, 1, timeoutMs);
    } while (pollResult < 0 && errno == EINTR);
    if (pollResult == 0) {
        *detailError = ETIMEDOUT;
        result = BALLOON_NETWORK_RESULT_FAILED;
        goto out;
    }
    if (pollResult < 0 ||
        getsockopt(socketFd, SOL_SOCKET, SO_ERROR, &socketError, &socketErrorSize) < 0) {
        *detailError = errno;
        result = BALLOON_NETWORK_RESULT_EXCEPTION;
        goto out;
    }
    if (socketError == 0) {
        result = BALLOON_NETWORK_RESULT_SUCCESS;
    } else {
        *detailError = socketError;
        result = BalloonWidget_IsExpectedConnectFailure(socketError) ?
                 BALLOON_NETWORK_RESULT_FAILED : BALLOON_NETWORK_RESULT_EXCEPTION;
    }

out:
    close(socketFd);
    return result;
}

static void *BalloonWidget_NetworkTestTask(void *arg)
{
    const char *configuredHost = getenv("BALLOON_NETWORK_TEST_HOST");
    const char *host = configuredHost == NULL || configuredHost[0] == '\0' ?
                       BALLOON_NETWORK_DEFAULT_HOST : configuredHost;
    uint16_t port = BalloonWidget_NetworkPort();
    int timeoutMs = BalloonWidget_NetworkTimeoutMs();
    int detailError = 0;
    E_BalloonNetworkResult result;

    (void) arg;
    result = BalloonWidget_ProbeNetwork(host, port, timeoutMs, &detailError);
    USER_LOG_INFO("Balloon network probe host=%s port=%u timeout_ms=%d result=%d errno=%d",
                  host, port, timeoutMs, result, detailError);
    BalloonWidget_ShowNetworkResult(result);

    pthread_mutex_lock(&s_networkTestMutex);
    s_networkTestRunning = false;
    pthread_mutex_unlock(&s_networkTestMutex);
    return NULL;
}

static T_DjiReturnCode BalloonWidget_StartNetworkTest(void)
{
    pthread_t thread;
    pthread_attr_t attributes;
    int threadResult;

    pthread_mutex_lock(&s_networkTestMutex);
    if (s_networkTestRunning) {
        pthread_mutex_unlock(&s_networkTestMutex);
        USER_LOG_WARN("Balloon network probe rejected: a probe is already running.");
        BalloonWidget_ShowNetworkResult(BALLOON_NETWORK_RESULT_EXCEPTION);
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }
    s_networkTestRunning = true;
    pthread_mutex_unlock(&s_networkTestMutex);

    if (pthread_attr_init(&attributes) != 0) {
        threadResult = -1;
    } else {
        (void) pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED);
        threadResult = pthread_create(&thread, &attributes, BalloonWidget_NetworkTestTask, NULL);
        (void) pthread_attr_destroy(&attributes);
    }
    if (threadResult != 0) {
        pthread_mutex_lock(&s_networkTestMutex);
        s_networkTestRunning = false;
        pthread_mutex_unlock(&s_networkTestMutex);
        USER_LOG_ERROR("Balloon network probe thread creation failed: %d", threadResult);
        BalloonWidget_ShowNetworkResult(BALLOON_NETWORK_RESULT_EXCEPTION);
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }

    DjiWidgetFloatingWindow_ShowMessage("联网：正在连接");
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static void BalloonWidget_ShowVoiceMessage(const char *fallback)
{
    FILE *stream;
    char message[512] = {0};
    size_t length;

    stream = fopen(BALLOON_VOICE_MESSAGE_FILE, "rb");
    if (stream != NULL) {
        length = fread(message, 1, sizeof(message) - 1, stream);
        fclose(stream);
        while (length > 0 && (message[length - 1] == '\n' || message[length - 1] == '\r')) {
            message[--length] = '\0';
        }
    }
    DjiWidgetFloatingWindow_ShowMessage(message[0] == '\0' ? fallback : message);
}

static void *BalloonWidget_VoiceCommandTask(void *arg)
{
    T_BalloonVoiceTask *task = (T_BalloonVoiceTask *) arg;
    char command[768];
    int result;

    if (task->action == BALLOON_VOICE_RECOGNIZE) {
        snprintf(command, sizeof(command), "%s %s --pcm-file %s",
                 BALLOON_VOICE_PYTHON, BALLOON_VOICE_HELPER, task->pcmPath);
    } else if (task->action == BALLOON_VOICE_CONFIRM) {
        snprintf(command, sizeof(command), "%s %s --confirm",
                 BALLOON_VOICE_PYTHON, BALLOON_VOICE_HELPER);
    } else {
        snprintf(command, sizeof(command), "%s %s --cancel",
                 BALLOON_VOICE_PYTHON, BALLOON_VOICE_HELPER);
    }
    USER_LOG_INFO("Balloon voice task started: action=%d", task->action);
    result = system(command);
    USER_LOG_INFO("Balloon voice task finished: action=%d result=%d", task->action, result);
    BalloonWidget_ShowVoiceMessage(result == 0 ? "语音：处理完成" : "语音：处理失败");
    free(task);

    pthread_mutex_lock(&s_voiceCommandMutex);
    s_voiceCommandRunning = false;
    pthread_mutex_unlock(&s_voiceCommandMutex);
    return NULL;
}

static T_DjiReturnCode BalloonWidget_StartVoiceTask(E_BalloonVoiceAction action, const char *pcmPath)
{
    pthread_t thread;
    pthread_attr_t attributes;
    T_BalloonVoiceTask *task;
    int threadResult;

    pthread_mutex_lock(&s_voiceCommandMutex);
    if (s_voiceCommandRunning) {
        pthread_mutex_unlock(&s_voiceCommandMutex);
        DjiWidgetFloatingWindow_ShowMessage("语音：上一条命令仍在处理中");
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }
    s_voiceCommandRunning = true;
    pthread_mutex_unlock(&s_voiceCommandMutex);

    task = calloc(1, sizeof(*task));
    if (task == NULL) {
        threadResult = -1;
    } else {
        task->action = action;
        if (pcmPath != NULL) {
            SafeCopyPath(task->pcmPath, sizeof(task->pcmPath), pcmPath);
        }
        if (pthread_attr_init(&attributes) != 0) {
            threadResult = -1;
        } else {
            (void) pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED);
            threadResult = pthread_create(&thread, &attributes, BalloonWidget_VoiceCommandTask, task);
            (void) pthread_attr_destroy(&attributes);
        }
    }
    if (threadResult != 0) {
        free(task);
        pthread_mutex_lock(&s_voiceCommandMutex);
        s_voiceCommandRunning = false;
        pthread_mutex_unlock(&s_voiceCommandMutex);
        DjiWidgetFloatingWindow_ShowMessage("语音：处理线程启动失败");
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    DjiWidgetFloatingWindow_ShowMessage(action == BALLOON_VOICE_RECOGNIZE ?
                                        "语音：正在识别" : "语音：正在处理");
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static void *BalloonWidget_VoiceWatchTask(void *arg)
{
    struct stat current;
    time_t lastSeconds = 0;
    long lastNanoseconds = 0;
    off_t lastSize = 0;
    int stableCount = 0;

    (void) arg;
    if (stat(BALLOON_VOICE_PCM_DEFAULT, &current) == 0) {
        lastSeconds = current.st_mtim.tv_sec;
        lastNanoseconds = current.st_mtim.tv_nsec;
        lastSize = current.st_size;
    }
    while (1) {
        usleep(100000);
        if (stat(BALLOON_VOICE_PCM_DEFAULT, &current) != 0 || current.st_size <= 0) {
            stableCount = 0;
            continue;
        }
        if (current.st_mtim.tv_sec == lastSeconds &&
            current.st_mtim.tv_nsec == lastNanoseconds && current.st_size == lastSize) {
            if (stableCount > 0 && ++stableCount >= 4) {
                stableCount = 0;
                (void) BalloonWidget_StartVoiceTask(BALLOON_VOICE_RECOGNIZE,
                                                     BALLOON_VOICE_PCM_DEFAULT);
            }
            continue;
        }
        lastSeconds = current.st_mtim.tv_sec;
        lastNanoseconds = current.st_mtim.tv_nsec;
        lastSize = current.st_size;
        stableCount = 1;
    }
    return NULL;
}

static T_DjiReturnCode BalloonWidget_StartVoiceWatch(void)
{
    pthread_t thread;
    pthread_attr_t attributes;
    int result;

    if (pthread_attr_init(&attributes) != 0) {
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    (void) pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED);
    result = pthread_create(&thread, &attributes, BalloonWidget_VoiceWatchTask, NULL);
    (void) pthread_attr_destroy(&attributes);
    if (result != 0) {
        USER_LOG_ERROR("Balloon voice watcher creation failed: %d", result);
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    USER_LOG_INFO("Balloon voice watcher started: %s", BALLOON_VOICE_PCM_DEFAULT);
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static void BalloonWidget_CancelPinkYellowTask(void)
{
    pthread_mutex_lock(&s_pinkYellowTaskMutex);
    if (s_pinkYellowTaskRunning) {
        s_pinkYellowTaskCancelled = true;
    }
    s_pinkYellowPlanSelected = false;
    s_pinkYellowPlanReady = false;
    pthread_mutex_unlock(&s_pinkYellowTaskMutex);
}

static void *BalloonWidget_PinkYellowTask(void *arg)
{
    char command[768];
    int result;
    bool cancelled;

    (void) arg;
    snprintf(command, sizeof(command), "%s %s > %s 2>&1",
             BALLOON_VOICE_PYTHON,
             BALLOON_PINK_YELLOW_HELPER,
             BALLOON_PINK_YELLOW_MESSAGE_FILE);
    USER_LOG_INFO("Balloon pink-yellow test script started.");
    result = system(command);

    pthread_mutex_lock(&s_pinkYellowTaskMutex);
    cancelled = s_pinkYellowTaskCancelled;
    s_pinkYellowTaskRunning = false;
    s_pinkYellowTaskCancelled = false;
    s_pinkYellowPlanReady = !cancelled && result == 0;
    pthread_mutex_unlock(&s_pinkYellowTaskMutex);

    if (cancelled) {
        remove(BALLOON_NL_PLAN_FILE);
        remove(BALLOON_NL_STATE_FILE);
        USER_LOG_INFO("Balloon pink-yellow test script result discarded after Prepare/Stop.");
        return NULL;
    }

    USER_LOG_INFO("Balloon pink-yellow test script finished: result=%d", result);
    DjiWidgetFloatingWindow_ShowMessage(
        result == 0
            ? "粉黄脚本：计划已就绪，请按开始"
            : "粉黄脚本：启动失败，请检查日志");
    return NULL;
}

static T_DjiReturnCode BalloonWidget_StartPinkYellowTask(void)
{
    pthread_t thread;
    pthread_attr_t attributes;
    int result;

    if (!s_isArmed) {
        DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：请先按准备");
        return DJI_ERROR_SYSTEM_MODULE_CODE_NONSUPPORT_IN_CURRENT_STATE;
    }
    if (BalloonPhotoDetector_IsRunning()) {
        DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：飞行任务运行或停止中，禁止改计划");
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }

    pthread_mutex_lock(&s_pinkYellowTaskMutex);
    if (s_pinkYellowTaskRunning) {
        pthread_mutex_unlock(&s_pinkYellowTaskMutex);
        DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：正在处理中");
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }
    if (s_pinkYellowPlanSelected && s_pinkYellowPlanReady) {
        pthread_mutex_unlock(&s_pinkYellowTaskMutex);
        DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：计划已就绪，请按开始");
        return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
    }
    s_pinkYellowTaskRunning = true;
    s_pinkYellowTaskCancelled = false;
    s_pinkYellowPlanSelected = true;
    s_pinkYellowPlanReady = false;
    pthread_mutex_unlock(&s_pinkYellowTaskMutex);

    if (pthread_attr_init(&attributes) != 0) {
        result = -1;
    } else {
        (void) pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED);
        result = pthread_create(&thread, &attributes, BalloonWidget_PinkYellowTask, NULL);
        (void) pthread_attr_destroy(&attributes);
    }
    if (result != 0) {
        pthread_mutex_lock(&s_pinkYellowTaskMutex);
        s_pinkYellowTaskRunning = false;
        s_pinkYellowTaskCancelled = false;
        s_pinkYellowPlanReady = false;
        pthread_mutex_unlock(&s_pinkYellowTaskMutex);
        DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：线程启动失败");
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }

    DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：正在写入计划");
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static void SafeCopyPath(char *dst, size_t dstSize, const char *src)
{
    if (src == NULL || src[0] == '\0') {
        return;
    }
    memset(dst, 0, dstSize);
    strncpy(dst, src, dstSize - 1);
}

static bool WriteStateFile(const char *path, const char *state)
{
    FILE *fp = fopen(path, "w");
    if (fp == NULL) {
        USER_LOG_ERROR("Balloon widget failed to write file: %s", path);
        return false;
    }
    fprintf(fp, "state=%s\n", state);
    fclose(fp);
    USER_LOG_INFO("Balloon widget wrote %s: %s", state, path);
    return true;
}

static void RemoveFileIfExists(const char *path)
{
    remove(path);
}

static void ClearTriggerFiles(void)
{
    RemoveFileIfExists(s_triggerFilePath);
    RemoveFileIfExists(s_armedFilePath);
    RemoveFileIfExists(s_stopFilePath);
    RemoveFileIfExists(BALLOON_LATEST_TARGET_FILE);
    RemoveFileIfExists(BALLOON_LATEST_PHOTO_FILE);
    RemoveFileIfExists(BALLOON_DETECTION_REQUEST_FILE);
    RemoveFileIfExists(BALLOON_DETECTION_REQUEST_TMP_FILE);
    RemoveFileIfExists(BALLOON_NL_STOP_FILE);
    RemoveFileIfExists(BALLOON_NL_PLAN_FILE);
    RemoveFileIfExists(BALLOON_NL_STATE_FILE);
    USER_LOG_INFO("Balloon widget cleared trigger files.");
}

static bool BuildSiblingLanguagePath(const char *configDirPath,
                                     const char *fromDirName,
                                     const char *toDirName,
                                     char *outPath,
                                     size_t outPathSize)
{
    size_t configPathLen;
    size_t fromDirLen;
    size_t baseLen;

    if (configDirPath == NULL || fromDirName == NULL || toDirName == NULL || outPath == NULL) {
        return false;
    }

    configPathLen = strlen(configDirPath);
    fromDirLen = strlen(fromDirName);
    if (configPathLen < fromDirLen ||
        strcmp(configDirPath + configPathLen - fromDirLen, fromDirName) != 0) {
        return false;
    }

    baseLen = configPathLen - fromDirLen;
    if (baseLen + strlen(toDirName) + 1 > outPathSize) {
        return false;
    }

    memset(outPath, 0, outPathSize);
    strncpy(outPath, configDirPath, baseLen);
    strncat(outPath, toDirName, outPathSize - strlen(outPath) - 1);
    return true;
}

static T_DjiReturnCode RegisterWidgetUiConfig(const char *widgetConfigDirPath)
{
    T_DjiReturnCode code;
    char cnPath[BALLOON_WIDGET_PATH_SIZE] = {0};
    char enPath[BALLOON_WIDGET_PATH_SIZE] = {0};
    bool hasCnPath = false;
    bool hasEnPath = false;

    if (widgetConfigDirPath == NULL || widgetConfigDirPath[0] == '\0') {
        return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
    }

    code = DjiWidget_RegDefaultUiConfigByDirPath(widgetConfigDirPath);
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("DjiWidget_RegDefaultUiConfigByDirPath failed: 0x%08llX", code);
        return code;
    }

    if (BuildSiblingLanguagePath(widgetConfigDirPath, "cn_big_screen", "cn_big_screen",
                                 cnPath, sizeof(cnPath))) {
        hasCnPath = true;
        BuildSiblingLanguagePath(widgetConfigDirPath, "cn_big_screen", "en_big_screen",
                                 enPath, sizeof(enPath));
        hasEnPath = true;
    } else if (BuildSiblingLanguagePath(widgetConfigDirPath, "en_big_screen", "cn_big_screen",
                                        cnPath, sizeof(cnPath))) {
        hasCnPath = true;
        BuildSiblingLanguagePath(widgetConfigDirPath, "en_big_screen", "en_big_screen",
                                 enPath, sizeof(enPath));
        hasEnPath = true;
    }

    if (hasCnPath) {
        code = DjiWidget_RegUiConfigByDirPath(DJI_MOBILE_APP_LANGUAGE_CHINESE,
                                              DJI_MOBILE_APP_SCREEN_TYPE_BIG_SCREEN,
                                              cnPath);
        if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
            USER_LOG_ERROR("DjiWidget_RegUiConfigByDirPath Chinese failed: 0x%08llX", code);
            return code;
        }
        USER_LOG_INFO("Balloon widget Chinese UI path: %s", cnPath);
    }

    if (hasEnPath) {
        code = DjiWidget_RegUiConfigByDirPath(DJI_MOBILE_APP_LANGUAGE_ENGLISH,
                                              DJI_MOBILE_APP_SCREEN_TYPE_BIG_SCREEN,
                                              enPath);
        if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
            USER_LOG_ERROR("DjiWidget_RegUiConfigByDirPath English failed: 0x%08llX", code);
            return code;
        }
        USER_LOG_INFO("Balloon widget English UI path: %s", enPath);
    }

    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static T_DjiReturnCode BalloonWidget_Prepare(void)
{
    if (BalloonPhotoDetector_IsRunning()) {
        BalloonWidget_ShowStep("prepare rejected", "flight task is running or stopping; press Stop and wait");
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }
    BalloonWidget_CancelPinkYellowTask();
    ClearTriggerFiles();
    if (!WriteStateFile(s_armedFilePath, "armed")) {
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }
    s_isArmed = true;
    BalloonWidget_ShowStep("prepared", "trigger files cleared; press Start");
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static T_DjiReturnCode BalloonWidget_Start(void)
{
    T_DjiReturnCode returnCode;
    bool pinkYellowPlanSelected;
    bool pinkYellowPlanReady;

    if (!s_isArmed) {
        BalloonWidget_ShowStep("start rejected", "press Prepare before Start");
        return DJI_ERROR_SYSTEM_MODULE_CODE_NONSUPPORT;
    }
    if (BalloonPhotoDetector_IsRunning()) {
        BalloonWidget_ShowStep("start rejected", "previous flight task is still running or stopping");
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }
    pthread_mutex_lock(&s_pinkYellowTaskMutex);
    pinkYellowPlanSelected = s_pinkYellowPlanSelected;
    pinkYellowPlanReady = s_pinkYellowPlanReady;
    pthread_mutex_unlock(&s_pinkYellowTaskMutex);
    if (pinkYellowPlanSelected && !pinkYellowPlanReady) {
        DjiWidgetFloatingWindow_ShowMessage("粉黄脚本：计划尚未就绪，禁止开始");
        return DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
    }
    RemoveFileIfExists(s_stopFilePath);
    if (!WriteStateFile(s_triggerFilePath, "triggered")) {
        BalloonWidget_ShowStep("start failed", "cannot write trigger file");
        return DJI_ERROR_SYSTEM_MODULE_CODE_UNKNOWN;
    }

    returnCode = BalloonPhotoDetector_Start();
    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("Balloon photo detector start failed: 0x%08llX", (unsigned long long) returnCode);
        BalloonWidget_ShowStep("start failed", "trigger created; photo detector failed");
        return returnCode;
    }

    BalloonWidget_ShowStep("started", "waiting camera init, photo capture, YOLO, authority request");
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static T_DjiReturnCode BalloonWidget_Stop(void)
{
    BalloonWidget_CancelPinkYellowTask();
    (void) BalloonPhotoDetector_Stop();
    ClearTriggerFiles();
    s_isArmed = false;
    BalloonWidget_ResetButtonValues();
    BalloonWidget_ShowStep("stop requested", "releasing resources; controls remain ready for the next Prepare");
    USER_LOG_INFO("Balloon widget remains registered after stop; all button states reset.");
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

static T_DjiReturnCode BalloonWidget_SetValue(E_DjiWidgetType widgetType, uint32_t index, int32_t value, void *userData)
{
    T_DjiReturnCode code;

    (void) userData;
    if (widgetType != DJI_WIDGET_TYPE_BUTTON || index >= BALLOON_WIDGET_COUNT) {
        return DJI_ERROR_SYSTEM_MODULE_CODE_NONSUPPORT;
    }
    s_widgetValue[index] = value;
    if (value != DJI_WIDGET_BUTTON_STATE_PRESS_DOWN) {
        return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
    }

    switch (index) {
        case BALLOON_WIDGET_PREPARE_INDEX:
        case BALLOON_WIDGET_PREPARE_CONFIG_INDEX:
            code = BalloonWidget_Prepare();
            break;
        case BALLOON_WIDGET_START_INDEX:
        case BALLOON_WIDGET_START_CONFIG_INDEX:
            code = BalloonWidget_Start();
            break;
        case BALLOON_WIDGET_STOP_INDEX:
        case BALLOON_WIDGET_STOP_CONFIG_INDEX:
            code = BalloonWidget_Stop();
            break;
        case BALLOON_WIDGET_NETWORK_INDEX:
        case BALLOON_WIDGET_NETWORK_CONFIG_INDEX:
            code = BalloonWidget_StartNetworkTest();
            break;
        case BALLOON_WIDGET_VOICE_CONFIRM_INDEX:
        case BALLOON_WIDGET_VOICE_CONFIRM_CONFIG_INDEX:
            if (!s_isArmed) {
                DjiWidgetFloatingWindow_ShowMessage("语音：请先按准备再确认计划");
                code = DJI_ERROR_SYSTEM_MODULE_CODE_NONSUPPORT_IN_CURRENT_STATE;
            } else if (BalloonPhotoDetector_IsRunning()) {
                DjiWidgetFloatingWindow_ShowMessage("语音：飞行任务运行或停止中，禁止改计划");
                code = DJI_ERROR_SYSTEM_MODULE_CODE_BUSY;
            } else {
                code = BalloonWidget_StartVoiceTask(BALLOON_VOICE_CONFIRM, NULL);
            }
            break;
        case BALLOON_WIDGET_VOICE_CANCEL_INDEX:
        case BALLOON_WIDGET_VOICE_CANCEL_CONFIG_INDEX:
            code = BalloonWidget_StartVoiceTask(BALLOON_VOICE_CANCEL, NULL);
            break;
        case BALLOON_WIDGET_PINK_YELLOW_INDEX:
        case BALLOON_WIDGET_PINK_YELLOW_CONFIG_INDEX:
            code = BalloonWidget_StartPinkYellowTask();
            break;
        default:
            code = DJI_ERROR_SYSTEM_MODULE_CODE_NONSUPPORT;
            break;
    }

    /* Buttons represent commands, not persistent state.  Reset each command
     * after handling so DJI Pilot never observes a stale pressed button when
     * the operator starts the next run. */
    s_widgetValue[index] = DJI_WIDGET_BUTTON_STATE_RELEASE_UP;
    return code;
}

static T_DjiReturnCode BalloonWidget_GetValue(E_DjiWidgetType widgetType, uint32_t index, int32_t *value, void *userData)
{
    (void) widgetType;
    (void) userData;
    if (value == NULL || index >= BALLOON_WIDGET_COUNT) {
        return DJI_ERROR_SYSTEM_MODULE_CODE_NONSUPPORT;
    }
    *value = s_widgetValue[index];
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}

T_DjiReturnCode BalloonWidget_StartService(const char *widgetConfigDirPath,
                                           const char *armedFilePath,
                                           const char *triggerFilePath,
                                           const char *stopFilePath)
{
    T_DjiReturnCode code;

    SafeCopyPath(s_armedFilePath, sizeof(s_armedFilePath), armedFilePath);
    SafeCopyPath(s_triggerFilePath, sizeof(s_triggerFilePath), triggerFilePath);
    SafeCopyPath(s_stopFilePath, sizeof(s_stopFilePath), stopFilePath);
    BalloonWidget_ResetButtonValues();

    code = DjiWidget_Init();
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("DjiWidget_Init failed: 0x%08llX", code);
        return code;
    }

    code = DjiTest_WidgetSpeakerStartService();
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("DjiTest_WidgetSpeakerStartService failed: 0x%08llX", code);
        return code;
    }

    code = RegisterWidgetUiConfig(widgetConfigDirPath);
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        return code;
    }

    code = DjiWidget_RegHandlerList(s_widgetHandlerList, BALLOON_WIDGET_COUNT);
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("DjiWidget_RegHandlerList failed: 0x%08llX", code);
        return code;
    }

    code = BalloonWidget_StartVoiceWatch();
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_WARN("Voice command watcher did not start: 0x%08llX", code);
    }

    code = BalloonPhotoDetector_StartAutoExposure();
    if (code != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_WARN("Automatic exposure watchdog did not start: 0x%08llX", code);
    }

    USER_LOG_INFO("Balloon widget started. armed=%s trigger=%s stop=%s",
                  s_armedFilePath, s_triggerFilePath, s_stopFilePath);
    return DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS;
}
