/*
 * Balloon strike Widget bridge.
 *
 * This module adds four DJI Pilot Widget buttons:
 *   0 - Prepare balloon test
 *   1 - Start balloon test
 *   2 - Stop balloon test
 *   6 - Test the TCP connection to the network gateway board
 *
 * The flight-test buttons create/remove local files. The network button only
 * performs an asynchronous TCP reachability probe. None controls flight.
 */

#ifndef PSDK_BALLOON_WIDGET_H
#define PSDK_BALLOON_WIDGET_H

#include "dji_typedef.h"

#ifdef __cplusplus
extern "C" {
#endif

T_DjiReturnCode BalloonWidget_StartService(const char *widgetConfigDirPath,
                                           const char *armedFilePath,
                                           const char *triggerFilePath,
                                           const char *stopFilePath);

#ifdef __cplusplus
}
#endif

#endif
