#ifndef BALLOON_PHOTO_DETECTOR_H
#define BALLOON_PHOTO_DETECTOR_H

#include <stdbool.h>

#include "dji_typedef.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Start the camera/live-view, detector orchestration, and target-chase worker
 * tasks. The DJI platform and the modules used by this component must already
 * be initialized by the caller.
 *
 * Static tests and first deployments must set BALLOON_NO_FLIGHT=1 in the
 * service's effective environment before this function is called.
 */
T_DjiReturnCode BalloonPhotoDetector_Start(void);

/*
 * Start the independent native program-auto exposure watchdog when enabled by
 * BALLOON_AUTO_EXPOSURE=1. Unsupported camera firmware is reported through
 * camera_diag.jsonl without preventing the Widget or flight-control service
 * from starting.
 */
T_DjiReturnCode BalloonPhotoDetector_StartAutoExposure(void);

/*
 * Request both detector and target-chase workers to stop. Worker shutdown is
 * asynchronous; use BalloonPhotoDetector_IsRunning() to observe completion.
 */
T_DjiReturnCode BalloonPhotoDetector_Stop(void);

/* Return true while the detector worker is active or shutting down. */
bool BalloonPhotoDetector_IsRunning(void);

#ifdef __cplusplus
}
#endif

#endif /* BALLOON_PHOTO_DETECTOR_H */
